#!/usr/bin/env python3
"""Generate a deterministic, reward-free MOPD connectivity dataset."""

import argparse
import json
from pathlib import Path


PROMPTS = {
    "math": [
        "Compute 37 + 58. Give a concise explanation.",
        "If 3x + 5 = 20, solve for x.",
        "A rectangle has sides 7 and 9. What is its area?",
        "What is the derivative of x^3 + 2x?",
    ],
    "code": [
        "Write a Python function that returns the maximum element of a non-empty list.",
        "Explain the difference between a stack and a queue in two sentences.",
        "Write a Python expression that reverses the string s.",
        "Give the time complexity of binary search and state its precondition.",
    ],
    "general": [
        "Name the largest ocean on Earth and answer in one sentence.",
        "Explain why plants need sunlight in one short paragraph.",
        "List three common states of matter.",
        "What is the purpose of a table of contents?",
    ],
}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--num-samples", type=int, default=192)
    parser.add_argument(
        "--domains",
        nargs="+",
        default=list(PROMPTS),
        help="Domains to alternate and write to metadata.mopd_domains.",
    )
    args = parser.parse_args()

    if args.num_samples < 1:
        raise ValueError("--num-samples must be positive")
    unknown = sorted(set(args.domains) - set(PROMPTS))
    if unknown:
        raise ValueError(f"unknown smoke domains: {unknown}")
    if not args.domains:
        raise ValueError("--domains must not be empty")

    domains = args.domains
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8") as output:
        for index in range(args.num_samples):
            domain = domains[index % len(domains)]
            candidates = PROMPTS[domain]
            prompt = candidates[(index // len(domains)) % len(candidates)]
            row = {
                "prompt": f"[smoke-{index:04d}] {prompt}",
                "metadata": {
                    "domain": domain,
                    "mopd_domains": [domain],
                    "smoke_test": True,
                    "sample_id": index,
                },
            }
            output.write(json.dumps(row, ensure_ascii=False) + "\n")

    print(f"wrote {args.num_samples} samples to {args.output}")


if __name__ == "__main__":
    main()
