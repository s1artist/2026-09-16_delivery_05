#!/usr/bin/env python3
"""Validate a 20-step in-process Megatron MOPD top-k run from its Ray log."""

import argparse
import json
import math
import re
import sys
from pathlib import Path


FLOAT = r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?"


def metric_values(text: str, key: str) -> list[float]:
    pattern = re.compile(rf"['\"](?:train/)?{re.escape(key)}['\"]\s*:\s*({FLOAT})")
    return [float(value) for value in pattern.findall(text)]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--log", required=True, type=Path)
    parser.add_argument("--min-steps", type=int, default=20)
    parser.add_argument("--domains", nargs="+", default=["math", "code", "general"])
    parser.add_argument("--phase", choices=["identity", "learning"], default="learning")
    parser.add_argument("--identity-kl-tolerance", type=float, default=1e-3)
    parser.add_argument("--negative-kl-tolerance", type=float, default=1e-3)
    parser.add_argument("--learning-min-grad-norm", type=float, default=1e-8)
    parser.add_argument(
        "--require-routing",
        action="store_true",
        help="Require per-domain mopd_selected_frac metrics on every step.",
    )
    parser.add_argument("--routing-min-frac", type=float, default=0.25)
    parser.add_argument("--routing-max-frac", type=float, default=0.75)
    args = parser.parse_args()

    if not 0 <= args.routing_min_frac <= args.routing_max_frac <= 1:
        parser.error("routing fractions must satisfy 0 <= min <= max <= 1")

    text = args.log.read_text(encoding="utf-8", errors="replace")
    # Do not turn the standard watchdog-vs-HCCL timeout configuration warning
    # into a fatal result when a caller validates the unfiltered log directly.
    fatal_text = "\n".join(
        line
        for line in text.splitlines()
        if not (
            "ProcessGroupHCCL" in line
            and "watchdog timeout" in line
            and "less than or equal to HCCL execution timeout" in line
        )
    )
    fatal_patterns = {
        "python_traceback": re.compile(r"Traceback \(most recent call last\)"),
        "runtime_error": re.compile(r"\b(?:RuntimeError|AssertionError|OutOfMemoryError)\b"),
        "hccl_failure": re.compile(r"(?i)HCCL.*(?:error|failed|timeout)"),
        "ray_job_failed": re.compile(r"(?i)(?:job status|status:).*failed"),
    }
    fatal_hits = {name: len(pattern.findall(fatal_text)) for name, pattern in fatal_patterns.items()}
    failures = [f"fatal pattern {name} appeared {count} time(s)" for name, count in fatal_hits.items() if count]

    loaded_domains = sorted(
        set(re.findall(r"\[MOPD\] loaded in-process Megatron teacher domain=([^\s]+)", text))
    )
    missing_domains = sorted(set(args.domains) - set(loaded_domains))
    if missing_domains:
        failures.append(f"teacher load markers missing for: {missing_domains}")

    completed_steps = sorted(
        {
            int(value)
            for value in re.findall(
                r"\[MOPD\]\[top_k\] optimizer step complete rollout_id=(\d+)", text
            )
        }
    )
    payload_steps = sorted(
        {
            int(value)
            for value in re.findall(
                r"\[MOPD\]\[top_k\] exact-tail payload ready rollout_id=(\d+)", text
            )
        }
    )
    if len(completed_steps) < args.min_steps:
        failures.append(f"only {len(completed_steps)} completed top_k steps; need {args.min_steps}")
    if len(payload_steps) < args.min_steps:
        failures.append(f"only {len(payload_steps)} exact-tail Teacher payloads; need {args.min_steps}")

    base_kl = metric_values(text, "mopd_topk_kl")
    per_domain_kl = {domain: metric_values(text, f"mopd_topk_kl/{domain}") for domain in args.domains}
    for domain, values in per_domain_kl.items():
        if len(values) < args.min_steps:
            failures.append(f"only {len(values)} mopd_topk_kl/{domain} observations; need {args.min_steps}")
        elif not all(math.isfinite(value) for value in values):
            failures.append(f"non-finite top-k KL for domain {domain}")
        elif min(values) < -args.negative_kl_tolerance:
            failures.append(
                f"top-k KL for {domain} fell below -{args.negative_kl_tolerance:g}: {min(values):.6g}"
            )
    if len(base_kl) < args.min_steps:
        failures.append(f"only {len(base_kl)} mopd_topk_kl observations; need {args.min_steps}")
    elif not all(math.isfinite(value) for value in base_kl):
        failures.append("non-finite aggregate top-k KL")

    is_means = metric_values(text, "mopd_is_weight_mean")
    is_nonzero = metric_values(text, "mopd_is_nonzero_frac")
    rollout_diffs = metric_values(text, "train_rollout_logprob_abs_diff")
    grad_norms = metric_values(text, "grad_norm")
    if len(is_means) < args.min_steps or not all(math.isfinite(value) for value in is_means):
        failures.append("missing or non-finite MOPD IS-weight means")
    elif not any(abs(value - 1.0) > 1e-7 for value in is_means):
        failures.append("IS-weight means are exactly neutral; rollout_log_probs path was not demonstrated")
    if len(is_nonzero) < args.min_steps or not all(math.isfinite(value) and value > 0 for value in is_nonzero):
        failures.append("MOPD IS weights were missing, non-finite, or all rejected")
    if len(rollout_diffs) < args.min_steps or not any(value > 1e-8 for value in rollout_diffs):
        failures.append("rollout-vs-Megatron log-prob mismatch was not observed")
    finite_grads = [value for value in grad_norms if math.isfinite(value)]
    if len(finite_grads) < args.min_steps:
        failures.append(f"only {len(finite_grads)} finite grad_norm observations; need {args.min_steps}")

    selected_frac = {
        domain: metric_values(text, f"mopd_selected_frac/{domain}") for domain in args.domains
    }
    if args.require_routing:
        for domain, values in selected_frac.items():
            if len(values) < args.min_steps:
                failures.append(
                    f"only {len(values)} mopd_selected_frac/{domain} observations; need {args.min_steps}"
                )
                continue
            if not all(
                math.isfinite(value)
                and args.routing_min_frac <= value <= args.routing_max_frac
                for value in values
            ):
                failures.append(
                    f"routing fraction for {domain} left "
                    f"[{args.routing_min_frac}, {args.routing_max_frac}]"
                )

    all_domain_values = [value for values in per_domain_kl.values() for value in values]
    if args.phase == "identity" and all_domain_values:
        maximum = max(abs(value) for value in all_domain_values)
        if maximum > args.identity_kl_tolerance:
            failures.append(
                f"identity top-k KL max abs {maximum:.6g} exceeds {args.identity_kl_tolerance:.6g}"
            )
    if args.phase == "learning":
        if all_domain_values and max(abs(value) for value in all_domain_values) <= 1e-8:
            failures.append("learning top-k KL metrics are all effectively zero")
        if finite_grads and max(abs(value) for value in finite_grads) <= args.learning_min_grad_norm:
            failures.append("learning phase has no non-zero gradient norm")

    def stats(values: list[float]):
        return None if not values else {"count": len(values), "min": min(values), "max": max(values)}

    result = {
        "status": "PASS" if not failures else "FAIL",
        "phase": args.phase,
        "log": str(args.log),
        "required_steps": args.min_steps,
        "completed_steps": completed_steps,
        "exact_tail_payload_steps": payload_steps,
        "loaded_domains": loaded_domains,
        "topk_kl": stats(base_kl),
        "topk_kl_by_domain": {domain: stats(values) for domain, values in per_domain_kl.items()},
        "is_weight_mean": stats(is_means),
        "is_nonzero_frac": stats(is_nonzero),
        "rollout_logprob_abs_diff": stats(rollout_diffs),
        "grad_norm": stats(finite_grads),
        "selected_frac_by_domain": {
            domain: stats(values) for domain, values in selected_frac.items()
        },
        "fatal_hits": fatal_hits,
        "failures": failures,
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if not failures else 1


if __name__ == "__main__":
    sys.exit(main())
