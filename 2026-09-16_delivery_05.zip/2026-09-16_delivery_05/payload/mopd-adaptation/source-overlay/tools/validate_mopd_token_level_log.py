#!/usr/bin/env python3
"""Turn a token-level MOPD Ray log into an explicit PASS/FAIL result."""

import argparse
import json
import math
import re
import sys
from pathlib import Path


FLOAT = r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?"
FATAL_PATTERNS = {
    "python_traceback": re.compile(r"Traceback \(most recent call last\)"),
    "runtime_error": re.compile(r"\b(?:RuntimeError|AssertionError|OutOfMemoryError)\b"),
    "hccl_failure": re.compile(r"(?i)(?:HCCL).*(?:error|failed|timeout)"),
    "ray_job_failed": re.compile(r"(?i)(?:job status|status:).*failed"),
}


def _metric_values(text: str, key: str) -> list[float]:
    pattern = re.compile(rf"['\"](?:train/)?{re.escape(key)}['\"]\s*:\s*({FLOAT})")
    return [float(value) for value in pattern.findall(text)]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--log", required=True, type=Path)
    parser.add_argument("--min-steps", type=int, default=20)
    parser.add_argument("--domains", nargs="+", default=["math", "code", "general"])
    parser.add_argument("--phase", choices=["connectivity", "identity", "learning"], default="connectivity")
    parser.add_argument("--identity-kl-tolerance", type=float, default=1e-5)
    parser.add_argument("--learning-min-grad-norm", type=float, default=1e-8)
    args = parser.parse_args()

    text = args.log.read_text(encoding="utf-8", errors="replace")
    failures = []

    fatal_hits = {name: len(pattern.findall(text)) for name, pattern in FATAL_PATTERNS.items()}
    for name, count in fatal_hits.items():
        if count:
            failures.append(f"fatal pattern {name} appeared {count} time(s)")

    loaded_domains = sorted(
        set(re.findall(r"\[MOPD\] loaded in-process Megatron teacher domain=([^\s]+)", text))
    )
    missing_loaded = sorted(set(args.domains) - set(loaded_domains))
    if missing_loaded:
        failures.append(f"teacher load markers missing for: {missing_loaded}")

    step_ids = sorted(
        {
            int(value)
            for value in re.findall(
                r"\[MOPD\]\[token_level\] optimizer step complete rollout_id=(\d+)", text
            )
        }
    )
    if len(step_ids) < args.min_steps:
        failures.append(f"only {len(step_ids)} unique completed MOPD steps; need {args.min_steps}")

    reverse_kl = {}
    reverse_kl_abs = {}
    for domain in args.domains:
        values = _metric_values(text, f"mopd_reverse_kl/{domain}")
        absolute_values = _metric_values(text, f"mopd_reverse_kl_abs/{domain}")
        reverse_kl[domain] = values
        reverse_kl_abs[domain] = absolute_values
        if not values:
            failures.append(f"no train/mopd_reverse_kl/{domain} metric found")
        elif not all(math.isfinite(value) for value in values):
            failures.append(f"non-finite reverse-KL metric for {domain}")
        if not absolute_values:
            failures.append(f"no train/mopd_reverse_kl_abs/{domain} metric found")
        elif not all(math.isfinite(value) and value >= 0 for value in absolute_values):
            failures.append(f"non-finite absolute reverse-KL metric for {domain}")

    is_nonzero = _metric_values(text, "mopd_is_nonzero_frac")
    if not is_nonzero:
        failures.append("no train/mopd_is_nonzero_frac metric found")
    elif not all(math.isfinite(value) and value > 0 for value in is_nonzero):
        failures.append("MOPD importance weights were non-finite or all rejected")

    grad_norms = _metric_values(text, "grad_norm")
    finite_grad_norms = [value for value in grad_norms if math.isfinite(value)]
    if not finite_grad_norms:
        failures.append("no finite train/grad_norm metric found")

    all_kl_values = [value for values in reverse_kl.values() for value in values]
    all_absolute_kl_values = [value for values in reverse_kl_abs.values() for value in values]
    if args.phase == "identity" and all_absolute_kl_values:
        maximum = max(all_absolute_kl_values)
        if maximum > args.identity_kl_tolerance:
            failures.append(
                f"identity-checkpoint reverse KL max {maximum:.6g} exceeds {args.identity_kl_tolerance:.6g}"
            )
    if args.phase == "learning" and finite_grad_norms:
        if max(abs(value) for value in finite_grad_norms) <= args.learning_min_grad_norm:
            failures.append("learning phase has no non-zero gradient norm")
        if all_absolute_kl_values and max(all_absolute_kl_values) <= 1e-8:
            failures.append("learning phase reverse-KL metrics are all effectively zero")

    result = {
        "status": "PASS" if not failures else "FAIL",
        "phase": args.phase,
        "log": str(args.log),
        "required_steps": args.min_steps,
        "completed_step_count": len(step_ids),
        "completed_step_range": [step_ids[0], step_ids[-1]] if step_ids else None,
        "loaded_domains": loaded_domains,
        "reverse_kl_observations": {domain: len(values) for domain, values in reverse_kl.items()},
        "reverse_kl_abs_observations": {domain: len(values) for domain, values in reverse_kl_abs.items()},
        "is_nonzero_observations": len(is_nonzero),
        "finite_grad_norm_observations": len(finite_grad_norms),
        "fatal_hits": fatal_hits,
        "failures": failures,
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if not failures else 1


if __name__ == "__main__":
    sys.exit(main())
