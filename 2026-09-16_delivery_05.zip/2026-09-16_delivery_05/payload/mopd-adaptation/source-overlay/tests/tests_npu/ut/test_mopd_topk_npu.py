"""Single-NPU operator and autograd smoke tests for MOPD top-k KL."""

import pytest

torch = pytest.importorskip("torch")
pytest.importorskip("torch_npu")

from slime.utils.ppo_utils import vocab_parallel_topk_reverse_kl


@pytest.mark.skipif(not torch.npu.is_available(), reason="requires an Ascend NPU")
def test_topk_identity_and_learning_backward_on_npu():
    torch.npu.set_device(0)
    device = torch.device("npu:0")
    torch.manual_seed(23)

    teacher = torch.randn(8, 256, device=device)
    topk_values, topk_indices = teacher.topk(32, dim=-1)
    teacher_log_sum_exp = torch.logsumexp(teacher, dim=-1)

    identity_student = teacher.clone().requires_grad_(True)
    identity_kl = vocab_parallel_topk_reverse_kl(
        identity_student,
        topk_values,
        topk_indices,
        vocab_size=256,
        process_group=None,
        teacher_log_sum_exp=teacher_log_sum_exp,
    )
    identity_kl.mean().backward()
    torch.npu.synchronize()
    assert torch.isfinite(identity_kl).all()
    assert identity_kl.abs().max().item() < 1e-4
    assert torch.isfinite(identity_student.grad).all()

    learning_student = torch.randn(8, 256, device=device, requires_grad=True)
    learning_loss = vocab_parallel_topk_reverse_kl(
        learning_student,
        topk_values,
        topk_indices,
        vocab_size=256,
        process_group=None,
        teacher_log_sum_exp=teacher_log_sum_exp,
    ).mean()
    learning_loss.backward()
    torch.npu.synchronize()
    assert torch.isfinite(learning_loss)
    assert torch.isfinite(learning_student.grad).all()
    assert learning_student.grad.abs().max().item() > 0
