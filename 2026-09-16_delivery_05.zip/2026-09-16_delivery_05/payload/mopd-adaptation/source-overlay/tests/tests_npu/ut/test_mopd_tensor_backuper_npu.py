"""NPU smoke test for the multi-tag host weight backup used by Megatron MOPD."""

import pytest

torch = pytest.importorskip("torch")
pytest.importorskip("torch_npu")

# Importing the adaptor installs the image's CUDA/NCCL compatibility redirects.
# TensorBackuper intentionally uses torch.cuda.synchronize(), just like the rest
# of slime-ascend's Megatron backend.
pytest.importorskip("megatron_adaptor")

from slime.utils.tensor_backper import TensorBackuper


@pytest.mark.skipif(not torch.npu.is_available(), reason="requires an Ascend NPU")
def test_three_teacher_tags_restore_exactly_on_npu():
    torch.npu.set_device(0)
    parameter = torch.arange(16, dtype=torch.float32, device="npu:0")
    backuper = TensorBackuper.create(lambda: [("weight", parameter)], single_tag=None)

    expected = {}
    for tag, offset in [
        ("actor", 0.0),
        ("mopd_teacher_math", 10.0),
        ("mopd_teacher_code", 20.0),
        ("mopd_teacher_general", 30.0),
    ]:
        parameter.copy_(torch.arange(16, dtype=torch.float32, device="npu:0") + offset)
        expected[tag] = parameter.clone()
        backuper.backup(tag)

    for tag in expected:
        parameter.fill_(-1)
        backuper.restore(tag)
        assert torch.equal(parameter, expected[tag]), f"failed to restore tag {tag}"
