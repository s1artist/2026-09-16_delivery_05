"""CPU unit coverage for phase-1 token-level MOPD."""

import asyncio
from argparse import Namespace

import pytest

torch = pytest.importorskip("torch")

from slime.backends.megatron_utils.data import DataIterator
from slime.backends.megatron_utils.loss import apply_mopd_to_advantages
from slime.ray.rollout import resolve_mopd_domains
from slime.rollout.rm_hub import async_rm


def _args(**overrides):
    defaults = {
        "mopd_alpha": 0.0,
        "mopd_eps_low": 0.2,
        "mopd_eps_high": 5.0,
        "mopd_sampling_logprobs_key": "log_probs",
    }
    defaults.update(overrides)
    return Namespace(**defaults)


def test_three_teachers_are_averaged_equally():
    student = [torch.tensor([-2.0, -3.0])]
    rollout_data = {
        "log_probs": [torch.tensor([-2.0, -3.0])],
        "mopd_teacher_log_probs": {
            "math": [torch.tensor([-1.0, -2.0])],
            "code": [torch.tensor([0.0, -1.0])],
            "general": [torch.tensor([-3.0, -4.0])],
        },
    }
    base_advantages = [torch.tensor([9.0, 9.0])]

    apply_mopd_to_advantages(_args(), rollout_data, base_advantages, student)

    # Mean of teacher-student deltas: ([1,1] + [2,2] + [-1,-1]) / 3.
    expected = torch.full((2,), 2.0 / 3.0)
    assert torch.allclose(rollout_data["mopd_advantages"][0], expected)
    assert torch.equal(rollout_data["mopd_is_weights"][0], torch.ones(2))
    assert set(rollout_data["mopd_reverse_kl"]) == {"math", "code", "general"}


def test_alpha_adds_task_reward_advantage():
    student = [torch.tensor([-2.0, -2.0])]
    rollout_data = {
        "log_probs": [torch.tensor([-2.0, -2.0])],
        "mopd_teacher_log_probs": {
            "math": [torch.tensor([-1.0, -1.0])],
            "code": [torch.tensor([-1.0, -1.0])],
            "general": [torch.tensor([-1.0, -1.0])],
        },
    }
    base_advantages = [torch.tensor([2.0, 4.0])]

    apply_mopd_to_advantages(_args(mopd_alpha=0.5), rollout_data, base_advantages, student)

    assert torch.allclose(rollout_data["mopd_advantages"][0], torch.tensor([2.0, 3.0]))


def test_per_sample_domain_routing_selects_only_requested_teacher():
    student = [torch.tensor([-2.0]), torch.tensor([-2.0])]
    rollout_data = {
        "log_probs": [torch.tensor([-2.0]), torch.tensor([-2.0])],
        "mopd_domains": [["math"], ["code"]],
        "mopd_teacher_log_probs": {
            "math": [torch.tensor([-1.0]), torch.tensor([8.0])],
            "code": [torch.tensor([9.0]), torch.tensor([-4.0])],
        },
    }

    apply_mopd_to_advantages(
        _args(),
        rollout_data,
        [torch.zeros(1), torch.zeros(1)],
        student,
    )

    assert torch.equal(rollout_data["mopd_advantages"][0], torch.tensor([1.0]))
    assert torch.equal(rollout_data["mopd_advantages"][1], torch.tensor([-2.0]))
    # Non-selected domains are represented by zero only for stable metric keys;
    # they do not contribute to the aggregated advantage.
    assert torch.equal(rollout_data["mopd_reverse_kl"]["code"][0], torch.zeros(1))
    assert torch.equal(rollout_data["mopd_reverse_kl"]["math"][1], torch.zeros(1))


def test_invalid_empty_domain_route_fails_fast():
    rollout_data = {
        "log_probs": [torch.zeros(1)],
        "mopd_domains": [[]],
        "mopd_teacher_log_probs": {"math": [torch.zeros(1)]},
    }
    with pytest.raises(ValueError, match="non-empty list"):
        apply_mopd_to_advantages(_args(), rollout_data, [torch.zeros(1)], [torch.zeros(1)])


def test_importance_sampling_rejects_out_of_range_weights():
    student = [torch.tensor([-5.0, 2.0, 0.0])]
    rollout_data = {
        "log_probs": [torch.zeros(3)],
        "mopd_teacher_log_probs": {
            "math": [torch.zeros(3)],
            "code": [torch.zeros(3)],
            "general": [torch.zeros(3)],
        },
    }

    apply_mopd_to_advantages(
        _args(mopd_eps_low=0.5, mopd_eps_high=2.0),
        rollout_data,
        [torch.zeros(3)],
        student,
    )

    assert torch.equal(rollout_data["mopd_is_weights"][0], torch.tensor([0.0, 0.0, 1.0]))


def test_rollout_log_probs_falls_back_to_training_log_probs():
    student = [torch.tensor([-1.0])]
    rollout_data = {
        "log_probs": [torch.tensor([-1.0])],
        "mopd_teacher_log_probs": {
            "math": [torch.tensor([-0.5])],
            "code": [torch.tensor([-0.5])],
            "general": [torch.tensor([-0.5])],
        },
    }

    apply_mopd_to_advantages(
        _args(mopd_sampling_logprobs_key="rollout_log_probs"),
        rollout_data,
        [torch.zeros(1)],
        student,
    )

    assert torch.equal(rollout_data["mopd_is_weights"][0], torch.ones(1))


def test_shape_mismatch_fails_fast():
    rollout_data = {
        "log_probs": [torch.zeros(2)],
        "mopd_teacher_log_probs": {"math": [torch.zeros(3)]},
    }
    with pytest.raises(ValueError, match="tensor-shape mismatch"):
        apply_mopd_to_advantages(_args(), rollout_data, [torch.zeros(2)], [torch.zeros(2)])


def test_data_iterator_preserves_domain_mapping():
    iterator = DataIterator(
        {
            "mopd_reverse_kl": {
                "math": ["m0", "m1", "m2"],
                "code": ["c0", "c1", "c2"],
            }
        },
        micro_batch_indices=[[2, 0]],
    )

    batch = iterator.get_next(["mopd_reverse_kl"])

    assert batch["mopd_reverse_kl"] == {"math": ["m2", "m0"], "code": ["c2", "c0"]}


def test_domain_route_normalization_and_validation():
    configured = ["math", "code"]
    assert resolve_mopd_domains(None, configured) == configured
    assert resolve_mopd_domains("code", configured) == ["code"]
    assert resolve_mopd_domains(["code", "math", "code"], configured) == configured
    with pytest.raises(ValueError, match="unknown domains"):
        resolve_mopd_domains(["general"], configured)
    with pytest.raises(ValueError, match="selected no Teacher"):
        resolve_mopd_domains([], configured)


def test_zero_reward_for_pure_distillation():
    args = Namespace(custom_rm_path=None, rm_type="zero")
    sample = Namespace(metadata={}, response="ignored", label=None)
    assert asyncio.run(async_rm(args, sample)) == 0.0
