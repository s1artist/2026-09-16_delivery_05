"""CPU unit coverage for PR-2051 MOPD top-k reverse KL."""

from argparse import Namespace

import pytest

torch = pytest.importorskip("torch")

from slime.backends.megatron_utils import loss as loss_module
from slime.backends.megatron_utils.data import should_skip_rollout_log_key
from slime.backends.megatron_utils.cp_utils import get_sum_of_sample_mean, slice_log_prob_with_cp
from slime.backends.megatron_utils.loss import apply_mopd_topk_to_loss
from slime.utils.ppo_utils import vocab_parallel_topk_reverse_kl


def _topk_teacher(logits: torch.Tensor, k: int):
    values, indices = logits.topk(k, dim=-1)
    return values, indices, torch.logsumexp(logits, dim=-1)


def test_topk_identity_uses_exact_tail_mass():
    torch.manual_seed(7)
    teacher = torch.randn(5, 64)
    student = teacher.clone().requires_grad_(True)
    values, indices, log_sum_exp = _topk_teacher(teacher, k=16)

    kl = vocab_parallel_topk_reverse_kl(
        student,
        values,
        indices,
        vocab_size=64,
        process_group=None,
        teacher_log_sum_exp=log_sum_exp,
    )

    assert torch.isfinite(kl).all()
    assert kl.abs().max().item() < 1e-5
    kl.mean().backward()
    assert student.grad is not None
    assert torch.isfinite(student.grad).all()


def test_topk_memory_efficient_student_normalizer_matches_dense_reference():
    torch.manual_seed(101)
    teacher = torch.randn(7, 96, dtype=torch.float64)
    student = torch.randn(7, 96, dtype=torch.float64, requires_grad=True)
    reference_student = student.detach().clone().requires_grad_(True)
    values, indices, teacher_lse = _topk_teacher(teacher, k=24)

    actual = vocab_parallel_topk_reverse_kl(
        student,
        values,
        indices,
        vocab_size=96,
        process_group=None,
        teacher_log_sum_exp=teacher_lse,
    )

    reference_log_probs = torch.log_softmax(reference_student, dim=-1)
    reference_probs = reference_log_probs.exp()
    student_topk_probs = reference_probs.gather(-1, indices)
    student_topk_log_probs = reference_log_probs.gather(-1, indices)
    teacher_topk_log_probs = values - teacher_lse.unsqueeze(-1)
    student_tail = (1.0 - student_topk_probs.sum(dim=-1)).clamp_min(0.0)
    teacher_tail = (1.0 - teacher_topk_log_probs.exp().sum(dim=-1)).clamp_min(0.0)
    expected = (
        student_topk_probs * (student_topk_log_probs - teacher_topk_log_probs)
    ).sum(dim=-1) + student_tail * (student_tail.log() - teacher_tail.log())

    torch.testing.assert_close(actual, expected, rtol=1e-10, atol=1e-10)
    actual.sum().backward()
    expected.sum().backward()
    torch.testing.assert_close(student.grad, reference_student.grad, rtol=1e-9, atol=1e-10)


def test_topk_learning_loss_is_finite_and_backpropagates():
    torch.manual_seed(11)
    teacher = torch.randn(6, 80)
    student = torch.randn(6, 80, requires_grad=True)
    values, indices, log_sum_exp = _topk_teacher(teacher, k=20)

    loss = vocab_parallel_topk_reverse_kl(
        student,
        values,
        indices,
        vocab_size=80,
        process_group=None,
        teacher_log_sum_exp=log_sum_exp,
    ).mean()
    loss.backward()

    assert torch.isfinite(loss)
    assert loss.item() >= -1e-6
    assert student.grad is not None
    assert torch.isfinite(student.grad).all()
    assert student.grad.abs().max().item() > 0


def test_topk_empty_cp_response_shard_keeps_backward_connected():
    """Short tail responses may be empty on non-tail zigzag CP ranks."""
    student = torch.empty((0, 64), requires_grad=True)
    teacher_values = torch.empty((0, 16))
    teacher_indices = torch.empty((0, 16), dtype=torch.long)
    teacher_lse = torch.empty((0,))

    kl = vocab_parallel_topk_reverse_kl(
        student,
        teacher_values,
        teacher_indices,
        vocab_size=64,
        process_group=None,
        teacher_log_sum_exp=teacher_lse,
    )

    assert kl.shape == (0,)
    kl.sum().backward()
    assert student.grad is not None
    assert student.grad.shape == student.shape


def test_topk_cp_local_loss_matches_cp1_with_full_response_masks(monkeypatch):
    """CP-local KL/log-probs must be reduced with the full response mask."""
    torch.manual_seed(29)
    total_length = 12
    response_length = 8
    full_mask = torch.tensor([1.0, 0.0, 1.0, 1.0, 1.0, 0.0, 1.0, 1.0])
    student_full = torch.randn(response_length, 24, requires_grad=True)
    teacher_full = torch.randn(response_length, 24)
    teacher_values, teacher_indices, teacher_lse = _topk_teacher(teacher_full, k=6)
    args = Namespace(
        mopd_sampling_logprobs_key="rollout_log_probs",
        mopd_eps_low=0.2,
        mopd_eps_high=5.0,
        vocab_size=24,
    )

    monkeypatch.setattr(loss_module.mpu, "get_tensor_model_parallel_group", lambda: None)
    monkeypatch.setattr(loss_module.mpu, "get_context_parallel_world_size", lambda: 1)
    monkeypatch.setattr(loss_module.mpu, "get_context_parallel_rank", lambda: 0)
    cp1_reducer = get_sum_of_sample_mean(
        [total_length], [response_length], [full_mask]
    )
    cp1_loss, cp1_metrics = apply_mopd_topk_to_loss(
        args=args,
        batch={"rollout_log_probs": [torch.zeros(response_length)], "mopd_domains": [["math"]]},
        student_logits_per_sample=[student_full],
        teacher_topk_logits_per_domain={"math": [teacher_values]},
        teacher_topk_indices_per_domain={"math": [teacher_indices]},
        teacher_topk_log_sum_exp_per_domain={"math": [teacher_lse]},
        loss_masks=[full_mask],
        sum_of_sample_mean=cp1_reducer,
        current_log_probs=[torch.zeros(response_length)],
    )
    cp1_loss.backward()
    cp1_grad = student_full.grad.detach().clone()

    # For total=12,response=8,CP=2 zigzag response positions are rank0=[6,7]
    # and rank1=[0,1,2,3,4,5]. Their reducer contributions must sum to CP1.
    rank_indices = ([6, 7], [0, 1, 2, 3, 4, 5])
    cp_losses = []
    cp_metric_sums = []
    cp_selected_sums = []
    cp_grads = []
    for rank, indices in enumerate(rank_indices):
        monkeypatch.setattr(loss_module.mpu, "get_context_parallel_world_size", lambda: 2)
        monkeypatch.setattr(loss_module.mpu, "get_context_parallel_rank", lambda rank=rank: rank)
        index = torch.tensor(indices, dtype=torch.long)
        student_local = student_full.detach().index_select(0, index).clone().requires_grad_(True)
        reducer = get_sum_of_sample_mean(
            [total_length], [response_length], [full_mask]
        )
        local_loss, local_metrics = apply_mopd_topk_to_loss(
            args=args,
            batch={
                "rollout_log_probs": [torch.zeros(len(indices))],
                "mopd_domains": [["math"]],
            },
            student_logits_per_sample=[student_local],
            teacher_topk_logits_per_domain={"math": [teacher_values.index_select(0, index)]},
            teacher_topk_indices_per_domain={"math": [teacher_indices.index_select(0, index)]},
            teacher_topk_log_sum_exp_per_domain={"math": [teacher_lse.index_select(0, index)]},
            # Masks deliberately stay global under CP.
            loss_masks=[full_mask],
            sum_of_sample_mean=reducer,
            current_log_probs=[torch.zeros(len(indices))],
        )
        local_loss.backward()
        cp_losses.append(local_loss.detach())
        cp_metric_sums.append(local_metrics["mopd_topk_kl"])
        cp_selected_sums.append(local_metrics["mopd_selected_frac/math"])
        cp_grads.append((index, student_local.grad.detach().clone()))

    assert torch.allclose(sum(cp_losses), cp1_loss.detach(), atol=1e-6, rtol=1e-5)
    assert torch.allclose(sum(cp_metric_sums), cp1_metrics["mopd_topk_kl"], atol=1e-6, rtol=1e-5)
    assert torch.allclose(
        sum(cp_selected_sums), cp1_metrics["mopd_selected_frac/math"], atol=1e-6, rtol=1e-5
    )
    for index, local_grad in cp_grads:
        assert torch.allclose(local_grad, cp1_grad.index_select(0, index), atol=1e-6, rtol=1e-5)


def test_130496_token_cp4_response_partition_and_reducer_match_cp1(monkeypatch):
    """Exercise the observed 97,728+32,768 zigzag partition exactly."""
    total_length = 130496
    response_length = 32768
    full_values = torch.linspace(0.0, 1.0, response_length)
    full_mask = torch.ones(response_length)
    full_mask[::7] = 0

    monkeypatch.setattr(loss_module.mpu, "get_context_parallel_world_size", lambda: 1)
    monkeypatch.setattr(loss_module.mpu, "get_context_parallel_rank", lambda: 0)
    expected = get_sum_of_sample_mean(
        [total_length], [response_length], [full_mask]
    )(full_values)

    contributions = []
    local_lengths = []
    for rank in range(4):
        monkeypatch.setattr(loss_module.mpu, "get_context_parallel_world_size", lambda: 4)
        monkeypatch.setattr(loss_module.mpu, "get_context_parallel_rank", lambda rank=rank: rank)
        local_values = slice_log_prob_with_cp(
            full_values, total_length, response_length
        )
        local_lengths.append(local_values.numel())
        reducer = get_sum_of_sample_mean(
            [total_length], [response_length], [full_mask]
        )
        contributions.append(reducer(local_values))

    assert local_lengths == [16311, 16312, 145, 0]
    assert sum(local_lengths) == response_length
    assert torch.allclose(sum(contributions), expected, atol=1e-6, rtol=1e-6)


def test_topk_apply_handles_fully_empty_cp_response_rank(monkeypatch):
    """The complete loss path, not only the KL primitive, must keep backward alive."""
    monkeypatch.setattr(loss_module.mpu, "get_tensor_model_parallel_group", lambda: None)
    monkeypatch.setattr(loss_module.mpu, "get_context_parallel_world_size", lambda: 4)
    monkeypatch.setattr(loss_module.mpu, "get_context_parallel_rank", lambda: 1)
    student = torch.empty((0, 16), requires_grad=True)
    full_mask = torch.ones(2)
    reducer = get_sum_of_sample_mean([100], [2], [full_mask])
    loss, metrics = apply_mopd_topk_to_loss(
        args=Namespace(
            mopd_sampling_logprobs_key="rollout_log_probs",
            mopd_eps_low=0.2,
            mopd_eps_high=5.0,
            vocab_size=16,
        ),
        batch={"rollout_log_probs": [torch.empty(0)], "mopd_domains": [["math"]]},
        student_logits_per_sample=[student],
        teacher_topk_logits_per_domain={"math": [torch.empty((0, 4))]},
        teacher_topk_indices_per_domain={"math": [torch.empty((0, 4), dtype=torch.long)]},
        teacher_topk_log_sum_exp_per_domain={"math": [torch.empty(0)]},
        loss_masks=[full_mask],
        sum_of_sample_mean=reducer,
        current_log_probs=[torch.empty(0)],
    )
    loss.backward()
    assert loss.item() == pytest.approx(0.0)
    assert metrics["mopd_topk_kl"].item() == pytest.approx(0.0)
    assert student.grad is not None
    assert student.grad.shape == student.shape


def test_topk_per_sample_domain_routing(monkeypatch):
    monkeypatch.setattr(loss_module.mpu, "get_tensor_model_parallel_group", lambda: None)
    students = [
        torch.tensor([[1.0, 0.0, -1.0]], requires_grad=True),
        torch.tensor([[-1.0, 0.0, 1.0]], requires_grad=True),
    ]
    math_logits = [students[0].detach().clone(), torch.tensor([[30.0, -30.0, 0.0]])]
    code_logits = [torch.tensor([[-30.0, 30.0, 0.0]]), students[1].detach().clone()]
    teacher_values = {}
    teacher_indices = {}
    teacher_lse = {}
    for domain, tensors in {"math": math_logits, "code": code_logits}.items():
        values, indices, lse = zip(*[_topk_teacher(tensor, k=2) for tensor in tensors])
        teacher_values[domain] = list(values)
        teacher_indices[domain] = list(indices)
        teacher_lse[domain] = list(lse)

    args = Namespace(
        mopd_sampling_logprobs_key="rollout_log_probs",
        mopd_eps_low=0.2,
        mopd_eps_high=5.0,
        vocab_size=3,
    )
    loss, metrics = apply_mopd_topk_to_loss(
        args=args,
        batch={
            "rollout_log_probs": [torch.zeros(1), torch.zeros(1)],
            "mopd_domains": [["math"], ["code"]],
        },
        student_logits_per_sample=students,
        teacher_topk_logits_per_domain=teacher_values,
        teacher_topk_indices_per_domain=teacher_indices,
        teacher_topk_log_sum_exp_per_domain=teacher_lse,
        loss_masks=[torch.ones(1), torch.ones(1)],
        sum_of_sample_mean=lambda tensor: tensor.sum(),
        current_log_probs=[torch.zeros(1), torch.zeros(1)],
    )

    assert loss.abs().item() < 1e-5
    assert metrics["mopd_selected_frac/math"].item() == 1
    assert metrics["mopd_selected_frac/code"].item() == 1
    assert metrics["mopd_topk_kl/math"].abs().item() < 1e-5
    assert metrics["mopd_topk_kl/code"].abs().item() < 1e-5


def test_mopd_categorical_and_topk_payloads_are_not_aggregated_as_rollout_metrics():
    assert should_skip_rollout_log_key("mopd_domains")
    assert should_skip_rollout_log_key("mopd_teacher_math_topk_logits")
    assert should_skip_rollout_log_key("mopd_teacher_code_topk_indices")
    assert should_skip_rollout_log_key("mopd_teacher_math_topk_log_sum_exp")
    assert not should_skip_rollout_log_key("rewards")


def test_uniform_tail_fallback_is_not_used_by_identity_acceptance():
    """Demonstrate why the log_sum_exp field must survive the data pipeline."""
    torch.manual_seed(19)
    logits = torch.randn(3, 128)
    values, indices, log_sum_exp = _topk_teacher(logits, k=8)

    exact = vocab_parallel_topk_reverse_kl(
        logits,
        values,
        indices,
        vocab_size=128,
        process_group=None,
        teacher_log_sum_exp=log_sum_exp,
    )
    fallback = vocab_parallel_topk_reverse_kl(
        logits,
        values,
        indices,
        vocab_size=128,
        process_group=None,
    )

    assert exact.abs().max().item() < 1e-5
    assert fallback.abs().max().item() > exact.abs().max().item() + 1e-4
