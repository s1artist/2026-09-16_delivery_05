"""CPU unit coverage for PR-2051 MOPD full-vocabulary reverse KL."""

from argparse import Namespace

import pytest

torch = pytest.importorskip("torch")

from slime.backends.megatron_utils import loss as loss_module
from slime.backends.megatron_utils.cp_utils import get_sum_of_sample_mean
from slime.backends.megatron_utils.loss import apply_mopd_full_vocab_to_loss
from slime.utils.ppo_utils import vocab_parallel_reverse_kl


def _args(**overrides):
    defaults = {
        "mopd_eps_low": 0.2,
        "mopd_eps_high": 5.0,
        "mopd_sampling_logprobs_key": "rollout_log_probs",
    }
    defaults.update(overrides)
    return Namespace(**defaults)


def _mean(tensor):
    return tensor.mean()


def test_full_vocab_identity_is_zero_and_backpropagates():
    torch.manual_seed(31)
    teacher = torch.randn(5, 64)
    student = teacher.clone().requires_grad_(True)

    kl = vocab_parallel_reverse_kl(student, teacher, process_group=None)
    kl.mean().backward()

    assert torch.isfinite(kl).all()
    assert kl.abs().max().item() < 1e-6
    assert student.grad is not None
    assert torch.isfinite(student.grad).all()
    assert student.grad.abs().max().item() < 1e-6


def test_full_vocab_matches_torch_reference_and_has_gradient():
    torch.manual_seed(37)
    student = torch.randn(6, 80, requires_grad=True)
    teacher = torch.randn(6, 80)

    actual = vocab_parallel_reverse_kl(student, teacher, process_group=None)
    student_log_probs = torch.log_softmax(student, dim=-1)
    expected = (
        student_log_probs.exp()
        * (student_log_probs - torch.log_softmax(teacher, dim=-1))
    ).sum(dim=-1)

    assert torch.allclose(actual, expected, atol=1e-6, rtol=1e-5)
    actual.mean().backward()
    assert torch.isfinite(student.grad).all()
    assert student.grad.abs().max().item() > 0


def test_full_vocab_three_teacher_loss_and_metrics(monkeypatch):
    monkeypatch.setattr(loss_module.mpu, "get_tensor_model_parallel_group", lambda: None)
    student = torch.tensor([[1.0, 0.0, -1.0], [0.5, -0.5, 0.0]], requires_grad=True)
    teachers = {
        "math": [student.detach().clone()],
        "code": [torch.zeros_like(student)],
        "general": [torch.full_like(student, 0.25)],
    }
    current_lp = [torch.zeros(2)]
    sampling_lp = [torch.zeros(2)]

    loss, metrics = apply_mopd_full_vocab_to_loss(
        args=_args(),
        batch={"rollout_log_probs": sampling_lp},
        student_logits_per_sample=[student],
        teacher_logits_per_domain=teachers,
        loss_masks=[torch.ones(2)],
        sum_of_sample_mean=_mean,
        current_log_probs=current_lp,
    )

    expected_domains = {
        domain: vocab_parallel_reverse_kl(student, values[0], None)
        for domain, values in teachers.items()
    }
    expected = torch.stack(list(expected_domains.values())).mean(dim=0).mean()
    assert torch.allclose(loss, expected)
    assert set(metrics) == {
        "mopd_fv_kl",
        "mopd_is_weight_mean",
        "mopd_is_nonzero_frac",
        "mopd_fv_kl/math",
        "mopd_fv_kl/code",
        "mopd_fv_kl/general",
        "mopd_selected_frac/math",
        "mopd_selected_frac/code",
        "mopd_selected_frac/general",
    }
    assert metrics["mopd_is_weight_mean"].item() == pytest.approx(1.0)
    assert metrics["mopd_is_nonzero_frac"].item() == pytest.approx(1.0)
    loss.backward()
    assert torch.isfinite(student.grad).all()


def test_full_vocab_cp_local_loss_matches_cp1_with_full_response_masks(monkeypatch):
    torch.manual_seed(41)
    total_length = 12
    response_length = 8
    full_mask = torch.tensor([1.0, 0.0, 1.0, 1.0, 1.0, 0.0, 1.0, 1.0])
    student_full = torch.randn(response_length, 20, requires_grad=True)
    teacher_full = torch.randn(response_length, 20)

    monkeypatch.setattr(loss_module.mpu, "get_tensor_model_parallel_group", lambda: None)
    monkeypatch.setattr(loss_module.mpu, "get_context_parallel_world_size", lambda: 1)
    monkeypatch.setattr(loss_module.mpu, "get_context_parallel_rank", lambda: 0)
    cp1_reducer = get_sum_of_sample_mean(
        [total_length], [response_length], [full_mask]
    )
    cp1_loss, cp1_metrics = apply_mopd_full_vocab_to_loss(
        args=_args(),
        batch={"rollout_log_probs": [torch.zeros(response_length)], "mopd_domains": [["math"]]},
        student_logits_per_sample=[student_full],
        teacher_logits_per_domain={"math": [teacher_full]},
        loss_masks=[full_mask],
        sum_of_sample_mean=cp1_reducer,
        current_log_probs=[torch.zeros(response_length)],
    )
    cp1_loss.backward()
    cp1_grad = student_full.grad.detach().clone()

    rank_indices = ([6, 7], [0, 1, 2, 3, 4, 5])
    cp_losses = []
    cp_metric_sums = []
    cp_grads = []
    for rank, indices in enumerate(rank_indices):
        monkeypatch.setattr(loss_module.mpu, "get_context_parallel_world_size", lambda: 2)
        monkeypatch.setattr(loss_module.mpu, "get_context_parallel_rank", lambda rank=rank: rank)
        index = torch.tensor(indices, dtype=torch.long)
        student_local = student_full.detach().index_select(0, index).clone().requires_grad_(True)
        reducer = get_sum_of_sample_mean(
            [total_length], [response_length], [full_mask]
        )
        local_loss, local_metrics = apply_mopd_full_vocab_to_loss(
            args=_args(),
            batch={
                "rollout_log_probs": [torch.zeros(len(indices))],
                "mopd_domains": [["math"]],
            },
            student_logits_per_sample=[student_local],
            teacher_logits_per_domain={"math": [teacher_full.index_select(0, index)]},
            loss_masks=[full_mask],
            sum_of_sample_mean=reducer,
            current_log_probs=[torch.zeros(len(indices))],
        )
        local_loss.backward()
        cp_losses.append(local_loss.detach())
        cp_metric_sums.append(local_metrics["mopd_fv_kl"])
        cp_grads.append((index, student_local.grad.detach().clone()))

    assert torch.allclose(sum(cp_losses), cp1_loss.detach(), atol=1e-6, rtol=1e-5)
    assert torch.allclose(sum(cp_metric_sums), cp1_metrics["mopd_fv_kl"], atol=1e-6, rtol=1e-5)
    for index, local_grad in cp_grads:
        assert torch.allclose(local_grad, cp1_grad.index_select(0, index), atol=1e-6, rtol=1e-5)


def test_full_vocab_apply_handles_fully_empty_cp_response_rank(monkeypatch):
    monkeypatch.setattr(loss_module.mpu, "get_tensor_model_parallel_group", lambda: None)
    monkeypatch.setattr(loss_module.mpu, "get_context_parallel_world_size", lambda: 4)
    monkeypatch.setattr(loss_module.mpu, "get_context_parallel_rank", lambda: 1)
    student = torch.empty((0, 16), requires_grad=True)
    full_mask = torch.ones(2)
    reducer = get_sum_of_sample_mean([100], [2], [full_mask])
    loss, metrics = apply_mopd_full_vocab_to_loss(
        args=_args(),
        batch={"rollout_log_probs": [torch.empty(0)], "mopd_domains": [["math"]]},
        student_logits_per_sample=[student],
        teacher_logits_per_domain={"math": [torch.empty((0, 16))]},
        loss_masks=[full_mask],
        sum_of_sample_mean=reducer,
        current_log_probs=[torch.empty(0)],
    )
    loss.backward()
    assert loss.item() == pytest.approx(0.0)
    assert metrics["mopd_fv_kl"].item() == pytest.approx(0.0)
    assert student.grad is not None
    assert student.grad.shape == student.shape


def test_full_vocab_routes_each_sample_to_one_teacher(monkeypatch):
    monkeypatch.setattr(loss_module.mpu, "get_tensor_model_parallel_group", lambda: None)
    students = [
        torch.tensor([[1.0, 0.0]], requires_grad=True),
        torch.tensor([[0.0, 1.0]], requires_grad=True),
    ]
    math_teacher = [students[0].detach().clone(), torch.tensor([[20.0, -20.0]])]
    code_teacher = [torch.tensor([[-20.0, 20.0]]), students[1].detach().clone()]

    loss, metrics = apply_mopd_full_vocab_to_loss(
        args=_args(),
        batch={
            "rollout_log_probs": [torch.zeros(1), torch.zeros(1)],
            "mopd_domains": [["math"], ["code"]],
        },
        student_logits_per_sample=students,
        teacher_logits_per_domain={"math": math_teacher, "code": code_teacher},
        loss_masks=[torch.ones(1), torch.ones(1)],
        sum_of_sample_mean=lambda tensor: tensor.sum(),
        current_log_probs=[torch.zeros(1), torch.zeros(1)],
    )

    assert loss.abs().item() < 1e-6
    assert metrics["mopd_selected_frac/math"].item() == 1
    assert metrics["mopd_selected_frac/code"].item() == 1
    assert metrics["mopd_fv_kl/math"].abs().item() < 1e-6
    assert metrics["mopd_fv_kl/code"].abs().item() < 1e-6


def test_full_vocab_importance_sampling_rejects_outliers(monkeypatch):
    monkeypatch.setattr(loss_module.mpu, "get_tensor_model_parallel_group", lambda: None)
    student = torch.randn(3, 8, requires_grad=True)
    teacher = torch.randn(3, 8)

    _, metrics = apply_mopd_full_vocab_to_loss(
        args=_args(mopd_eps_low=0.5, mopd_eps_high=2.0),
        batch={"rollout_log_probs": [torch.zeros(3)]},
        student_logits_per_sample=[student],
        teacher_logits_per_domain={"math": [teacher]},
        loss_masks=[torch.ones(3)],
        sum_of_sample_mean=_mean,
        current_log_probs=[torch.tensor([-5.0, 2.0, 0.0])],
    )

    assert metrics["mopd_is_nonzero_frac"].item() == pytest.approx(1.0 / 3.0)


def test_full_vocab_shape_mismatch_fails_fast():
    with pytest.raises(ValueError, match="shape mismatch"):
        vocab_parallel_reverse_kl(
            torch.randn(2, 8),
            torch.randn(2, 7),
            process_group=None,
        )
