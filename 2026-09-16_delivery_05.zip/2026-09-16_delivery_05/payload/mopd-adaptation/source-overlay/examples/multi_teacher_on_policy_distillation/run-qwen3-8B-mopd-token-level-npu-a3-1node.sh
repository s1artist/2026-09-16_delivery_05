#!/bin/bash

# Phase-1 MOPD validation on one 910C server:
#   8 logical NPUs for Megatron training + 4 logical NPUs for SGLang rollout.
#   Three in-process Megatron teachers are stored in host memory and forwarded
#   sequentially on the actor allocation.

set -euo pipefail

SLIME_ROOT="${SLIME_ROOT:-/workspace/slime-ascend}"
ASCEND_SET_ENV="${ASCEND_SET_ENV:-/usr/local/Ascend/ascend-toolkit/set_env.sh}"
VISIBLE_DEVICES="${VISIBLE_DEVICES:-0,1,2,3,4,5,6,7,8,9,10,11}"
EXPERIMENT_ROOT="${EXPERIMENT_ROOT:-/hpfs/huawei/songchunjiang/experiments}"
SMOKE_DATA_ROOT="${SMOKE_DATA_ROOT:-/hpfs/huawei/songchunjiang/datasets/mopd-smoke}"

HF_CHECKPOINT="${HF_CHECKPOINT:-/hpfs/huawei/songchunjiang/weights_hf/Qwen3-8B}"
STUDENT_LOAD="${STUDENT_LOAD:-/hpfs/huawei/songchunjiang/models/qwen3-8b-mopd/student}"
TEACHER_MATH_LOAD="${TEACHER_MATH_LOAD:-${STUDENT_LOAD}}"
TEACHER_CODE_LOAD="${TEACHER_CODE_LOAD:-${STUDENT_LOAD}}"
TEACHER_GENERAL_LOAD="${TEACHER_GENERAL_LOAD:-${STUDENT_LOAD}}"

MOPD_VALIDATION_PHASE="${MOPD_VALIDATION_PHASE:-identity}"
NUM_ROLLOUT="${NUM_ROLLOUT:-20}"
ROLLOUT_BATCH_SIZE="${ROLLOUT_BATCH_SIZE:-8}"
ROLLOUT_MAX_RESPONSE_LEN="${ROLLOUT_MAX_RESPONSE_LEN:-1024}"

IFS=',' read -r -a _visible_device_array <<< "${VISIBLE_DEVICES}"
if [[ "${#_visible_device_array[@]}" -ne 12 ]]; then
    echo "VISIBLE_DEVICES must contain exactly 12 logical devices for the 8+4 layout; got ${VISIBLE_DEVICES}" >&2
    exit 2
fi
if [[ "${MOPD_VALIDATION_PHASE}" != "identity" && "${MOPD_VALIDATION_PHASE}" != "learning" ]]; then
    echo "MOPD_VALIDATION_PHASE must be identity or learning" >&2
    exit 2
fi
if [[ "${MOPD_VALIDATION_PHASE}" == "identity" ]]; then
    if [[ "${TEACHER_MATH_LOAD}" != "${STUDENT_LOAD}" || \
          "${TEACHER_CODE_LOAD}" != "${STUDENT_LOAD}" || \
          "${TEACHER_GENERAL_LOAD}" != "${STUDENT_LOAD}" ]]; then
        echo "identity phase requires Student and all three Teachers to use the same checkpoint" >&2
        exit 2
    fi
else
    if [[ "${TEACHER_MATH_LOAD}" == "${STUDENT_LOAD}" && \
          "${TEACHER_CODE_LOAD}" == "${STUDENT_LOAD}" && \
          "${TEACHER_GENERAL_LOAD}" == "${STUDENT_LOAD}" ]]; then
        echo "learning phase requires at least one Teacher checkpoint different from Student" >&2
        exit 2
    fi
fi

cd "${SLIME_ROOT}"
source "${ASCEND_SET_ENV}"
source "${SLIME_ROOT}/scripts/models/qwen3-8B.sh"

timestamp="$(date '+%Y%m%d_%H%M%S')"
experiment_dir="${EXPERIMENT_ROOT}/Qwen3-8B-MOPD-token-level/${MOPD_VALIDATION_PHASE}/${timestamp}"
dataset_path="${SMOKE_DATA_ROOT}/Qwen3-8B-MOPD-token-level/${MOPD_VALIDATION_PHASE}/${timestamp}/mopd-smoke-192.jsonl"
train_log="${experiment_dir}/train.log"
save_path="${experiment_dir}/checkpoint"
mkdir -p "${experiment_dir}" "$(dirname "${dataset_path}")"
cp -a "$(readlink -f "$0")" "${experiment_dir}/"

python3 "${SLIME_ROOT}/tools/generate_mopd_smoke_data.py" \
    --output "${dataset_path}" \
    --num-samples 192

for checkpoint in \
    "${STUDENT_LOAD}" \
    "${TEACHER_MATH_LOAD}" \
    "${TEACHER_CODE_LOAD}" \
    "${TEACHER_GENERAL_LOAD}"
do
    if [[ ! -d "${checkpoint}" ]]; then
        echo "checkpoint directory not found: ${checkpoint}" >&2
        exit 2
    fi
done

ray stop --force || true
pkill -9 -f "${SLIME_ROOT}/train.py" || true
sleep 3

cleanup() {
    if [[ "${KEEP_RAY_AFTER_RUN:-0}" != "1" ]]; then
        ray stop --force || true
    fi
}
trap cleanup EXIT

ulimit -n 65535 || true
unset http_proxy https_proxy HTTP_PROXY HTTPS_PROXY || true

export PYTHONUNBUFFERED=1
export MASTER_ADDR="${MASTER_ADDR:-127.0.0.1}"
export ASCEND_RT_VISIBLE_DEVICES="${VISIBLE_DEVICES}"
export RAY_EXPERIMENTAL_NOSET_ASCEND_RT_VISIBLE_DEVICES=1
export HCCL_HOST_SOCKET_PORT_RANGE="${HCCL_HOST_SOCKET_PORT_RANGE:-60000-60050}"
export HCCL_NPU_SOCKET_PORT_RANGE="${HCCL_NPU_SOCKET_PORT_RANGE:-61000-61050}"
export HYDRA_FULL_ERROR=1
export PYTORCH_NPU_ALLOC_CONF="${PYTORCH_NPU_ALLOC_CONF:-expandable_segments:True}"

MOPD_TEACHERS_JSON='[{"name":"math_teacher","domain":"math"},{"name":"code_teacher","domain":"code"},{"name":"general_teacher","domain":"general"}]'

CKPT_ARGS=(
    --hf-checkpoint "${HF_CHECKPOINT}"
    --load "${STUDENT_LOAD}"
    --save "${save_path}"
    --save-interval 20
)

ROLLOUT_ARGS=(
    --prompt-data "${dataset_path}"
    --input-key prompt
    --apply-chat-template
    --rollout-shuffle
    --start-rollout-id 0
    --num-rollout "${NUM_ROLLOUT}"
    --rollout-batch-size "${ROLLOUT_BATCH_SIZE}"
    --n-samples-per-prompt 1
    --rollout-max-response-len "${ROLLOUT_MAX_RESPONSE_LEN}"
    --rollout-temperature 1.0
    --global-batch-size "${ROLLOUT_BATCH_SIZE}"
    --balance-data
)

MOPD_ARGS=(
    --advantage-estimator grpo
    --use-mopd
    --mopd-teacher-mode megatron
    --mopd-distill-type token_level
    --mopd-teachers "${MOPD_TEACHERS_JSON}"
    --mopd-teacher-loads \
        "${TEACHER_MATH_LOAD}" \
        "${TEACHER_CODE_LOAD}" \
        "${TEACHER_GENERAL_LOAD}"
    --mopd-alpha 0.0
    --mopd-eps-low 0.2
    --mopd-eps-high 5.0
    --mopd-sampling-logprobs-key log_probs
    --rm-type zero
    --entropy-coef 0.0
)

OPTIMIZER_ARGS=(
    --optimizer adam
    --lr 1e-6
    --lr-decay-style constant
    --weight-decay 0.1
    --adam-beta1 0.9
    --adam-beta2 0.98
)

PERF_ARGS=(
    --tensor-model-parallel-size 4
    --sequence-parallel
    --pipeline-model-parallel-size 1
    --context-parallel-size 1
    --expert-model-parallel-size 1
    --expert-tensor-parallel-size 1
    --recompute-granularity full
    --recompute-method uniform
    --recompute-num-layers 1
    --no-gradient-accumulation-fusion
    --use-dynamic-batch-size
    --max-tokens-per-gpu 2048
)

SGLANG_ARGS=(
    --rollout-num-gpus 4
    --rollout-num-gpus-per-engine 1
    --sglang-device npu
    --sglang-mem-fraction-static 0.7
)

MISC_ARGS=(
    --attention-dropout 0.0
    --hidden-dropout 0.0
    --accumulate-allreduce-grads-in-fp32
    --attention-softmax-in-fp32
    --attention-backend flash
    --use-flash-attn
)

ray start \
    --head \
    --node-ip-address "${MASTER_ADDR}" \
    --num-gpus 12 \
    --disable-usage-stats \
    --dashboard-host=0.0.0.0 \
    --dashboard-port=8264

RUNTIME_ENV_JSON='{
    "env_vars": {
        "PYTHONPATH": "/workspace/slime-ascend:/workspace/MegatronAdaptor:/workspace/Megatron-Bridge/src:/workspace/Megatron-LM:/workspace/sglang/python",
        "CUDA_DEVICE_MAX_CONNECTIONS": "1",
        "PYTHONUNBUFFERED": "1",
        "RAY_EXPERIMENTAL_NOSET_ASCEND_RT_VISIBLE_DEVICES": "1"
    }
}'

echo "experiment_dir=${experiment_dir}"
echo "validation_phase=${MOPD_VALIDATION_PHASE}"
echo "student=${STUDENT_LOAD}"
echo "teachers=${TEACHER_MATH_LOAD},${TEACHER_CODE_LOAD},${TEACHER_GENERAL_LOAD}"

ray job submit \
    --address="http://127.0.0.1:8264" \
    --runtime-env-json="${RUNTIME_ENV_JSON}" \
    -- \
    python3 "${SLIME_ROOT}/train.py" \
    --actor-num-nodes 1 \
    --actor-num-gpus-per-node 8 \
    "${MODEL_ARGS[@]}" \
    "${CKPT_ARGS[@]}" \
    "${ROLLOUT_ARGS[@]}" \
    "${MOPD_ARGS[@]}" \
    "${OPTIMIZER_ARGS[@]}" \
    "${PERF_ARGS[@]}" \
    "${SGLANG_ARGS[@]}" \
    "${MISC_ARGS[@]}" \
    2>&1 | tee "${train_log}"

if [[ ! -f "${save_path}/latest_checkpointed_iteration.txt" ]]; then
    echo "20-step run completed without a Megatron checkpoint marker under ${save_path}" >&2
    exit 1
fi

python3 "${SLIME_ROOT}/tools/validate_mopd_token_level_log.py" \
    --log "${train_log}" \
    --min-steps "${NUM_ROLLOUT}" \
    --phase "${MOPD_VALIDATION_PHASE}" \
    --domains math code general \
    | tee "${experiment_dir}/validation.json"

echo "MOPD token-level ${MOPD_VALIDATION_PHASE} validation passed: ${experiment_dir}"
