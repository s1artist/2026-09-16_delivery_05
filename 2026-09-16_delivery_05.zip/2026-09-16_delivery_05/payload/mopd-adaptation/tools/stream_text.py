"""Display one native SGLang SSE stream and retain its raw events on disk.

Only transport/presentation checks; no repetition or answer-quality classification.
"""
import argparse
import gzip
import hashlib
import json
import sys
from pathlib import Path

LOGPROB_ARRAYS = ("output_token_logprobs", "output_top_logprobs", "output_token_ids_logprobs")


def safe_terminal(text):
    return "".join(c if c in "\n\t" or (ord(c) >= 32 and not 127 <= ord(c) < 160)
                   else "\\u%04x" % ord(c) for c in text)


class TextStream:
    def __init__(self, incremental, output):
        self.incremental = incremental
        self.output = output
        self.text = ""
        self.last = None
        self.last_payload = None
        self.ids = []
        self.probs = {}
        self.count = 0
        self.done = False
        self.request_id = None
        self.display_error = None

    def accept(self, payload):
        if self.done:
            raise ValueError("[DONE] 后仍收到 data 事件")
        if payload == "[DONE]":
            self.done = True
            return
        obj = json.loads(payload)
        if not isinstance(obj, dict) or "error" in obj:
            raise ValueError("服务端错误事件: " + payload[:500])
        if not isinstance(obj.get("text"), str) or not isinstance(obj.get("meta_info"), dict):
            raise ValueError("需要包含 text 和 meta_info 的单条原生生成事件")
        rid = obj["meta_info"].get("id")
        if self.request_id is not None and rid is not None and rid != self.request_id:
            raise ValueError("收到多个请求的事件；此查看器只处理单请求")
        if rid is not None:
            self.request_id = rid
        self.count += 1
        self.last, self.last_payload = obj, payload
        current = obj["text"]
        if self.incremental:
            delta = current
            self.text += delta
            self.ids.extend(obj.get("output_ids", []))
            for key in LOGPROB_ARRAYS:
                if key in obj["meta_info"]:
                    self.probs.setdefault(key, []).extend(obj["meta_info"][key])
        else:
            if not current.startswith(self.text):
                self.display_error = "累计 text 改写了此前前缀；停止追加打屏，原始事件和最终文本仍保存"
            delta = current[len(self.text):] if self.display_error is None else ""
            self.text = current
        if delta and self.display_error is None:
            self.output.write(safe_terminal(delta))
            self.output.flush()

    def result(self):
        if self.last is None:
            return None
        if not self.incremental:
            return self.last
        result = {**self.last, "text": self.text, "meta_info": {**self.last["meta_info"], **self.probs}}
        if "output_ids" in self.last:
            result["output_ids"] = self.ids
        result["_stream_review"] = {
            "derived_from_incremental_events": True,
            "event_count": self.count,
            "note": "text/output_ids/logprob 数组按事件拼接；其他字段取最后事件；原始事件另存",
        }
        return result


def consume(source, raw_archive, state):
    data_lines, error = [], None
    raw_hash = hashlib.sha256()
    for raw in source:
        raw_archive.write(raw)
        raw_hash.update(raw)
        if error is not None:
            continue  # Drain the HTTP body so error evidence is still retained.
        try:
            line = raw.decode("utf-8").rstrip("\r\n")
            if not line:
                if data_lines:
                    payload = "\n".join(data_lines)
                    data_lines = []
                    state.accept(payload)
            elif line.startswith("data:"):
                value = line[5:]
                data_lines.append(value[1:] if value.startswith(" ") else value)
            elif line.startswith((":", "event:", "id:", "retry:")):
                continue
            else:
                raise ValueError("收到非 SSE 行，请查看 HTTP 响应头及原始事件: " + line[:200])
        except (ValueError, TypeError, KeyError) as exc:
            error = str(exc)
    if data_lines and error is None:
        error = "EOF 前最后一个 SSE 事件没有完整空行结束"
    if not state.done and error is None:
        error = "未收到 [DONE]，不能将断流当作正常结束"
    return raw_hash.hexdigest(), error


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--server-info", required=True)
    parser.add_argument("--out", required=True)
    args = parser.parse_args()
    info_bytes = Path(args.server_info).read_bytes()
    info = json.loads(info_bytes)
    incremental = info.get("incremental_streaming_output")
    if type(incremental) is not bool:
        raise ValueError("server_info 没有明确流模式；不能猜测")
    root = Path(args.out)
    root.mkdir()  # Never overwrite a previous attempt, including failures.
    state = TextStream(incremental, sys.stdout)
    with gzip.open(root / "events.sse.gz", "xb", compresslevel=1) as raw:
        try:
            raw_hash, error = consume(sys.stdin.buffer, raw, state)
        except KeyboardInterrupt:
            raw_hash, error = None, "本地收到中断；保留已收到的事件，不将中断当成模型长度停止"
        except OSError as exc:
            raw_hash, error = None, "本地读写失败: " + str(exc)
    result = state.result()
    if result is not None:
        if incremental:
            (root / "response.json").write_text(json.dumps(result, ensure_ascii=False) + "\n", encoding="utf-8")
        else:
            (root / "response.json").write_text(state.last_payload, encoding="utf-8")
        (root / "response.txt").write_text(state.text, encoding="utf-8")
        (root / "last-event.json").write_text(state.last_payload, encoding="utf-8")
    meta = state.last["meta_info"] if state.last else {}
    finish = meta.get("finish_reason")
    status = {
        "stream_text_mode": "delta" if incremental else "cumulative",
        "server_info_sha256": hashlib.sha256(info_bytes).hexdigest(),
        "raw_sse_sha256": raw_hash,
        "raw_archive_bytes": (root / "events.sse.gz").stat().st_size,
        "data_event_count": state.count,
        "request_id": state.request_id,
        "parsed_done": state.done,
        "stream_error": error,
        "display_error": state.display_error,
        "finish_reason": finish,
        "prompt_tokens": meta.get("prompt_tokens"),
        "completion_tokens": meta.get("completion_tokens"),
        "response_chars": len(state.text),
        "response_text_sha256": hashlib.sha256(state.text.encode("utf-8")).hexdigest(),
        "content_completion": "requires_review",
    }
    (root / "stream-status.json").write_text(json.dumps(status, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print("\n[流式查看器] " + json.dumps(status, ensure_ascii=False), file=sys.stderr, flush=True)
    return 0 if state.done and finish is not None and not error and not state.display_error else 2


if __name__ == "__main__":
    sys.exit(main())
