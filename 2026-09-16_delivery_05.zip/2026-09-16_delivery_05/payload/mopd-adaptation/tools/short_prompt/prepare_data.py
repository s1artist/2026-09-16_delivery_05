"""Convert pinned GSM8K/MBPP training data into a balanced MOPD JSONL.

Only data conversion, token lengths and provenance. Never submits a job or calls a model.
"""
from __future__ import annotations

import argparse
import collections
import json
import math
from pathlib import Path
import random
import sys

from inputs import (assert_materials_unchanged, file_info, load_tokenizer, material_info,
                    render_input, save_tokenizer_info, sha256, template_kwargs,
                    token_hash, write_json)


def rows(path):
    with Path(path).open(encoding="utf-8") as stream:
        for line, text in enumerate(stream, 1):
            if text.strip():
                item = json.loads(text)
                if not isinstance(item, dict):
                    raise ValueError(f"{path}:{line}: 需要 JSON 对象")
                yield line, item


def verify_sources(root):
    root = Path(root).resolve(strict=True)
    manifest = json.loads((root / "SOURCES.json").read_text(encoding="utf-8"))
    if manifest.get("schema") != "short-prompt-sources/v1":
        raise ValueError("原始数据来源清单 schema 不符")
    seen = set()
    for entry in manifest["files"]:
        name = entry["path"]
        if Path(name).name != name or name in seen:
            raise ValueError("来源清单需要唯一的同目录文件名")
        seen.add(name)
        actual = file_info(root / name)
        if any(actual[key] != entry[key] for key in ("sha256", "bytes")):
            raise ValueError(f"原始材料与固定来源清单不一致: {name}")
    if not {"gsm8k-train.jsonl", "mbpp.jsonl"}.issubset(seen):
        raise ValueError("缺少官方 GSM8K/MBPP 原始文件")
    return manifest


def text_field(row, key):
    value = row.get(key)
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"缺少非空字符串字段 {key}")
    return value


def source_examples(root):
    examples = []
    for line, row in rows(Path(root) / "gsm8k-train.jsonl"):
        question, answer = text_field(row, "question"), text_field(row, "answer")
        if "####" not in answer or not answer.rsplit("####", 1)[1].strip():
            raise ValueError(f"GSM8K 第 {line} 行缺少参考最终答案")
        examples.append({"source_id": f"gsm8k:train:line-{line}", "domain": "math",
                         "source": "gsm8k", "source_line": line,
                         "prompt": question + "\n\nGive the final numeric answer on the last line.",
                         "label": answer.rsplit("####", 1)[1].strip(), "original": row})
    mbpp_ids = set()
    for line, row in rows(Path(root) / "mbpp.jsonl"):
        task_id = row.get("task_id")
        if type(task_id) is not int or task_id in mbpp_ids:
            raise ValueError(f"MBPP 第 {line} 行 task_id 缺失或重复")
        mbpp_ids.add(task_id)
        if not 601 <= task_id <= 974:
            continue
        description, code = text_field(row, "text"), text_field(row, "code")
        tests = row.get("test_list")
        setup = row.get("test_setup_code", "")
        if (not isinstance(tests, list) or len(tests) != 3 or
                not all(isinstance(test, str) and test.strip() for test in tests) or
                not isinstance(setup, str)):
            raise ValueError(f"MBPP {task_id} 测试字段不符合原始版本结构")
        prompt = description + "\n\nWrite Python code that passes these tests:\n"
        prompt += (setup + "\n") if setup else ""
        prompt += "\n".join(tests) + "\n\nReturn the Python solution."
        examples.append({"source_id": f"mbpp:train:{task_id}", "domain": "code",
                         "source": "mbpp", "source_line": line, "prompt": prompt,
                         "label": code, "original": row})
    if not set(range(601, 975)).issubset(mbpp_ids):
        raise ValueError("MBPP 文件不包含完整的官方训练 ID 601–974；不能用评测集替代")
    return examples


def lengths(values):
    values = sorted(values)
    if not values:
        return {"count": 0}
    return {"count": len(values), "min": values[0],
            "p50": values[math.ceil(len(values) * 0.5) - 1],
            "p95": values[math.ceil(len(values) * 0.95) - 1], "max": values[-1]}


def prepare(examples, tokenizer, kwargs, max_prompt, max_response, context, num_rollouts, seed):
    if any(type(value) is not int or value <= 0 for value in
           (max_prompt, max_response, context, num_rollouts)):
        raise ValueError("长度和 rollout 数必须为正整数")
    if max_prompt + max_response > context:
        raise ValueError("本实验要求输入上限＋输出上限不超过总上下文")
    kwargs = template_kwargs(kwargs)
    pools = {"math": [], "code": []}
    measurements = []
    for example in examples:
        measured = {}
        chosen_ids = None
        for thinking in (True, False):
            _, ids, _ = render_input(tokenizer, example["prompt"], {"enable_thinking": thinking})
            measured["thinking_on" if thinking else "thinking_off"] = len(ids)
            if thinking == kwargs["enable_thinking"]:
                chosen_ids = ids
        eligible = max(measured.values()) <= max_prompt
        measurements.append({"source_id": example["source_id"], "domain": example["domain"],
                             **measured, "included_in_pool": eligible,
                             "exclusion_reason": None if eligible else "input_over_limit_in_either_mode"})
        if eligible:
            metadata = {key: example[key] for key in ("source_id", "source", "source_line", "domain")}
            metadata.update(split="train", mopd_domains=[example["domain"]],
                            prompt_sha256=sha256(example["prompt"].encode("utf-8")),
                            input_token_sha256=token_hash(chosen_ids),
                            native_prompt_tokens_with_telechat_template=len(chosen_ids),
                            max_response_tokens_with_context_budget=min(max_response, context-len(chosen_ids)),
                            template_kwargs=kwargs)
            pools[example["domain"]].append({"prompt": example["prompt"], "label": example["label"],
                                             "metadata": metadata})
    per_domain = num_rollouts * 4
    if len(pools["math"]) < per_domain or not pools["code"]:
        raise ValueError(f"合格数学题 {len(pools['math'])} 道（需 {per_domain}），"
                         f"合格 code 题 {len(pools['code'])} 道；无法按计划组批")
    for pool in pools.values():
        random.Random(seed).shuffle(pool)
    records = []
    occurrences = collections.Counter()
    for rollout in range(num_rollouts):
        for domain in ("math", "code"):
            pool = pools[domain]
            for within_domain in range(4):
                source = pool[(rollout * 4 + within_domain) % len(pool)]
                sid = source["metadata"]["source_id"]
                occurrences[sid] += 1
                metadata = {**source["metadata"], "planned_rollout": rollout,
                            "record_index": len(records), "source_occurrence": occurrences[sid]}
                records.append({**source, "metadata": metadata})
    return records, measurements


def write_jsonl(path, values):
    with Path(path).open("x", encoding="utf-8") as stream:
        for value in values:
            stream.write(json.dumps(value, ensure_ascii=False, allow_nan=False) + "\n")


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--raw-dir", required=True)
    parser.add_argument("--tokenizer", required=True)
    parser.add_argument("--out", required=True, help="尚不存在的新输出目录")
    parser.add_argument("--template-kwargs", required=True, type=template_kwargs)
    parser.add_argument("--max-prompt-tokens", type=int, required=True)
    parser.add_argument("--max-response-tokens", type=int, required=True)
    parser.add_argument("--context-tokens", type=int, required=True)
    parser.add_argument("--num-rollouts", type=int, default=300)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args(argv)
    sources = verify_sources(args.raw_dir)
    examples = source_examples(args.raw_dir)
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=False)
    materials = material_info(args.tokenizer)
    tokenizer = load_tokenizer(args.tokenizer, out / "tokenizer-cache")
    save_tokenizer_info(tokenizer, args.tokenizer, out, materials)
    records, measurements = prepare(examples, tokenizer, args.template_kwargs, args.max_prompt_tokens,
                                    args.max_response_tokens, args.context_tokens, args.num_rollouts, args.seed)
    selected = {record["metadata"]["source_id"] for record in records}
    write_jsonl(out / "train.jsonl", records)
    write_jsonl(out / "references.jsonl", ({"source_id": e["source_id"], "source_line": e["source_line"],
                                          "original": e["original"]} for e in examples if e["source_id"] in selected))
    write_jsonl(out / "lengths.jsonl", measurements)
    write_json(out / "first_batch.json", [record["metadata"] for record in records[:8]])
    counts = {domain: {"generations": sum(r["metadata"]["domain"] == domain for r in records),
                       "unique_questions": len({r["metadata"]["source_id"] for r in records
                                                if r["metadata"]["domain"] == domain})}
              for domain in ("math", "code")}
    stats = {domain: {mode: lengths([m[mode] for m in measurements if m["domain"] == domain])
                      for mode in ("thinking_on", "thinking_off")} for domain in ("math", "code")}
    assert_materials_unchanged(args.tokenizer, materials)
    verify_sources(args.raw_dir)
    manifest = {"schema": "short-prompt-data/v1", "complete": True, "settings": vars(args),
                "records": len(records), "counts": counts, "source_pool_lengths": stats,
                "excluded": [m for m in measurements if not m["included_in_pool"]],
                "sources": sources, "converter": file_info(__file__),
                "input_helpers": file_info(Path(__file__).with_name("inputs.py")),
                "files": {name: file_info(out / name) for name in
                          ("train.jsonl", "references.jsonl", "lengths.jsonl", "first_batch.json",
                           "tokenizer-info.json", "loaded_template.jinja")},
                "semantic_review": "not_performed", "npu_validation": "not_run"}
    write_json(out / "manifest.json", manifest)
    print(json.dumps({"out": str(out.resolve()), "records": len(records), "counts": counts,
                      "source_pool_lengths": stats, "excluded_count": len(manifest["excluded"]),
                      "manifest_sha256": file_info(out / "manifest.json")["sha256"]}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    try:
        main()
    except (ValueError, OSError, ImportError) as error:
        print(f"数据准备失败: {error}", file=sys.stderr)
        raise SystemExit(2)
