"""Shared input rendering and provenance; no inference, downloads or CLI."""
from __future__ import annotations

import hashlib
import importlib
import json
import os
from pathlib import Path


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def token_hash(ids):
    # Same representation as rollout_review.sample_data.token_hash.
    return sha256("".join(f"{token}\n" for token in ids).encode("ascii"))


def file_info(path):
    path = Path(path).resolve(strict=True)
    return {"path": str(path), "bytes": path.stat().st_size,
            "sha256": sha256(path.read_bytes())}


def write_json(path, value):
    with Path(path).open("x", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, allow_nan=False, indent=2)
        stream.write("\n")


def template_kwargs(value):
    kwargs = json.loads(value) if isinstance(value, str) else value
    if (not isinstance(kwargs, dict) or set(kwargs) != {"enable_thinking"}
            or type(kwargs["enable_thinking"]) is not bool):
        raise ValueError('本实验要求显式 {"enable_thinking":true} 或 {"enable_thinking":false}')
    return kwargs


def material_info(root):
    root = Path(root).resolve(strict=True)
    paths = set(root.rglob("*.py")) | set(root.rglob("*.jinja"))
    for path in root.iterdir():
        if path.is_file() and (path.name in ("config.json", "generation_config.json") or
                              path.name.startswith(("token", "vocab", "merges", "added_tokens",
                                                    "special_tokens", "spiece"))):
            if path.suffix not in (".pt", ".bin", ".safetensors"):
                paths.add(path)
    return [file_info(path) for path in sorted(paths)]


def load_tokenizer(root, cache):
    root = Path(root).resolve(strict=True)
    if not root.is_dir():
        raise ValueError("tokenizer 必须是完整的本地模型目录")
    # Set before importing transformers; never put dynamic-code caches in the model directory.
    os.environ["HF_HUB_OFFLINE"] = "1"
    os.environ["TRANSFORMERS_OFFLINE"] = "1"
    os.environ["HF_MODULES_CACHE"] = str(Path(cache).resolve())
    from transformers import AutoTokenizer
    return AutoTokenizer.from_pretrained(str(root), trust_remote_code=True, local_files_only=True)


def render_input(tokenizer, prompt, kwargs):
    if not isinstance(prompt, str) or not prompt.strip():
        raise ValueError("prompt 必须是非空字符串")
    kwargs = template_kwargs(kwargs)
    messages = [{"role": "user", "content": prompt}]
    rendered = tokenizer.apply_chat_template(messages, tools=None, tokenize=False,
                                             add_generation_prompt=True, **kwargs)
    base = tokenizer.apply_chat_template(messages, tools=None, tokenize=False,
                                         add_generation_prompt=False, **kwargs)
    if not isinstance(rendered, str) or not isinstance(base, str) or not rendered.startswith(base):
        raise ValueError("实际模板不能按本实验的单轮输入契约追加生成前缀")
    prefix = rendered[len(base):]
    expected = "<_bot><think>" if kwargs["enable_thinking"] else "<_bot></think>"
    if not prefix.startswith(expected) or prefix[len(expected):].strip():
        raise ValueError(f"实际 Telechat 生成前缀与指定模式不符: {prefix!r}")
    # Match Slime Dataset -> _prepare_prompt_ids, not a second chat-template pass.
    ids = list(tokenizer.encode(rendered, add_special_tokens=False))
    if not ids or any(type(token) is not int or token < 0 for token in ids):
        raise ValueError("tokenizer 未产生有效的完整 input_ids")
    return rendered, ids, prefix


def save_tokenizer_info(tokenizer, root, out, materials):
    import transformers
    module = importlib.import_module(type(tokenizer).__module__)
    loaded_template = tokenizer.get_chat_template()
    if not isinstance(loaded_template, str) or not loaded_template:
        raise ValueError("实际加载对象没有可保存的 chat template")
    out = Path(out)
    with (out / "loaded_template.jinja").open("x", encoding="utf-8") as stream:
        stream.write(loaded_template)
    markers = {text: list(tokenizer.encode(text, add_special_tokens=False))
               for text in ("<_bot>", "<think>", "</think>", "<_end>")}
    result = {"model_directory": str(Path(root).resolve()),
              "class": type(tokenizer).__name__, "module": type(tokenizer).__module__,
              "implementation": file_info(module.__file__) if getattr(module, "__file__", None) else None,
              "transformers_version": transformers.__version__,
              "transformers_path": transformers.__file__,
              "loaded_template": file_info(out / "loaded_template.jinja"),
              "markers": markers, "declared_eos_id": tokenizer.eos_token_id,
              "materials": materials,
              "scope": "本次离线加载对象；不证明 SGLang/Slime 进程实际加载版本或权重相同"}
    write_json(out / "tokenizer-info.json", result)
    return result


def assert_materials_unchanged(root, before):
    if material_info(root) != before:
        raise ValueError("处理期间 tokenizer 配置、实现或词表发生变化；本次输出不完整")
