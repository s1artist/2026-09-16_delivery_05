#!/usr/bin/env bash
# 将明确指定的 Megatron iteration 目录导出为新的 HF 目录；不启动训练或推理。
set -euo pipefail

if [[ "$#" != 2 ]]; then
    echo "usage: $0 CHECKPOINT_ITER_DIR OUTPUT_HF_DIR" >&2
    exit 2
fi

INPUT_DIR="$(realpath -e -- "$1")"
OUTPUT_DIR="$(realpath -m -- "$2")"
SLIME_ROOT=/workspace/slime-ascend
ORIGIN_HF_DIR=/hpfs/huawei/songchunjiang/weights_hf/12.05T_wodsa_256k_gbs8_id11_stage3_1000_hf

# 只检查转换所需输入；不推测轮次、不回退旧权重、不覆盖既有输出。
test -f "${INPUT_DIR}/common.pt"
test -f "${INPUT_DIR}/.metadata"
if [[ -e "${OUTPUT_DIR}" || -L "${OUTPUT_DIR}" ]]; then
    echo "output already exists: ${OUTPUT_DIR}; choose a new HF directory" >&2
    exit 2
fi

export PYTHONPATH=/workspace/slime-ascend:/workspace/Megatron-LM:/workspace/Megatron-Bridge/src:/workspace/mbridge
export PYTHONDONTWRITEBYTECODE=1
python3 -B "${SLIME_ROOT}/tools/convert_torch_dist_to_hf_parallel.py" \
    --input-dir "${INPUT_DIR}" \
    --output-dir "${OUTPUT_DIR}" \
    --origin-hf-dir "${ORIGIN_HF_DIR}" \
    --vocab-size 131072 \
    --load-max-workers 2 \
    --save-max-workers 16 \
    --verify-output

printf 'HF 导出完成：%s -> %s\n后续请使用该 HF 目录执行独立 SGLang 验证。\n' "${INPUT_DIR}" "${OUTPUT_DIR}"
