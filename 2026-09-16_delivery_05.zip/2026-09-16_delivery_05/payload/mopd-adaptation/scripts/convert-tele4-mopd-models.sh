#!/usr/bin/env bash
set -e

# 每次转换一个模型，只修改下面两条路径。
HF_CHECKPOINT=/hpfs/huawei/songchunjiang/weights_hf/12.05T_wodsa_256k_gbs8_id11_stage3_1000_hf
SAVE_DIR=/hpfs/huawei/songchunjiang/mopd-delivery-05/models/mopd-torch-dist/student

MODEL_ARGS_NUM_LAYERS=40
source /workspace/slime-ascend/scripts/models/telechat4-29B-Moe.sh
cd /workspace/slime-ascend/

export MASTER_ADDR=127.0.0.1
export MASTER_PORT=12355

PYTHONPATH=/workspace/Megatron-LM:/workspace/Megatron-Bridge/src:/workspace/mbridge:/workspace/TransformerEngineNPU:/workspace/MegatronAdaptor:${PYTHONPATH:-} \
torchrun --nproc_per_node=16 \
    --master_addr=127.0.0.1 \
    --master_port=12355 \
    /workspace/slime-ascend/tools/convert_hf_to_torch_dist.py \
    "${MODEL_ARGS[@]}" \
    --hf-checkpoint "${HF_CHECKPOINT}" \
    --save "${SAVE_DIR}"
