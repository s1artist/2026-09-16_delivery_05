#!/usr/bin/env bash
# 配置、快照、提交和日志；不检查环境，不执行安装。
set -euo pipefail

# ── 路径 ────────────────────────────────────────────────────────────
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
SCRIPT_PATH="${SCRIPT_DIR}/$(basename -- "${BASH_SOURCE[0]}")"
SLIME_ROOT=/workspace/slime-ascend
STUDENT_HF=/hpfs/huawei/songchunjiang/weights_hf/12.05T_wodsa_256k_gbs8_id11_stage3_1000_hf
STUDENT=/hpfs/huawei/songchunjiang/mopd-delivery-05/models/mopd-torch-dist/student
MATH_TEACHER=/hpfs/huawei/songchunjiang/mopd-delivery-05/models/mopd-torch-dist/math_teacher
CODE_TEACHER=/hpfs/huawei/songchunjiang/mopd-delivery-05/models/mopd-torch-dist/code_teacher
PROMPT_DATA=/hpfs/huawei/songchunjiang/mopd-delivery-05/datasets/mopd-short-prompt-05/train.jsonl
EXPERIMENT_ROOT=/hpfs/huawei/songchunjiang/mopd-delivery-05/experiments
CHECKPOINT_ROOT=/hpfs/huawei/songchunjiang/mopd-delivery-05/models/mopd-short
RAY_ADDRESS="http://${HCCL_IF_IP}:8265"

# ── 实验名称与输出 ──────────────────────────────────────────────────
# 重跑请使用新的日期/序号；已有实验目录会使 mkdir 失败，历史记录不覆盖。
EXPERIMENT_NAME=2026-09-16_short_05
JOB_ID="mopd-${EXPERIMENT_NAME}"
EXPERIMENT_DIR="${EXPERIMENT_ROOT}/${EXPERIMENT_NAME}"
CHECKPOINT_DIR="${CHECKPOINT_ROOT}/${JOB_ID}"
SUBMIT_LOG="${EXPERIMENT_DIR}/submit.log"
TRAIN_LOG="${EXPERIMENT_DIR}/train.log"

# ── 训练与采样参数 ────────────────────────────────────────────
TRAIN_NPU=16
ROLLOUT_NPU=8
TP=4
CP=4
EP=8
NUM_ROLLOUT=300
SAVE_INTERVAL=20
BATCH_SIZE=8
MICRO_BATCH_SIZE=1
CONTEXT_LEN=131072
PROMPT_LEN=98304
RESPONSE_LEN=32768
TEMPERATURE=0.6
TOP_K=1024
LOSS_CHUNK=512
LR=1e-6

# ── 模型：复用原配置，不在启动脚本复制架构参数 ──────────────────────
MODEL_ARGS_NUM_LAYERS=40
source "${SLIME_ROOT}/scripts/models/telechat4-29B-Moe.sh"

# ── Checkpoint ─────────────────────────────────────────────────────
CHECKPOINT_ARGS=(
    --hf-checkpoint "${STUDENT_HF}"
    --load "${STUDENT}"
    --finetune
    --no-load-optim
    --no-load-rng
    --save "${CHECKPOINT_DIR}"
    --save-interval "${SAVE_INTERVAL}"
)

# ── 数据与 rollout：短序列主流程，使用固定数据 ────────────
ROLLOUT_ARGS=(
    --prompt-data "${PROMPT_DATA}"
    --input-key prompt
    --apply-chat-template
    --apply-chat-template-kwargs '{"enable_thinking":true}'
    --rm-type zero
    --start-rollout-id 0
    --num-rollout "${NUM_ROLLOUT}"
    --rollout-batch-size "${BATCH_SIZE}"
    --n-samples-per-prompt 1
    --global-batch-size "${BATCH_SIZE}"
    --micro-batch-size "${MICRO_BATCH_SIZE}"
    --rollout-max-context-len "${CONTEXT_LEN}"
    --rollout-max-prompt-len "${PROMPT_LEN}"
    --rollout-max-response-len "${RESPONSE_LEN}"
    --rollout-temperature "${TEMPERATURE}"
    --rollout-top-p 1.0
    --rollout-top-k -1
    --balance-data
)

# ── MOPD ────────────────────────────────────────────────────────────
MOPD_ARGS=(
    --advantage-estimator grpo
    --use-mopd
    --mopd-teacher-mode megatron
    --mopd-distill-type top_k
    --mopd-teachers '[{"name":"math_teacher","domain":"math"},{"name":"code_teacher","domain":"code"}]'
    --mopd-teacher-loads "${MATH_TEACHER}" "${CODE_TEACHER}"
    --mopd-alpha 0.0
    --mopd-eps-low 0.2
    --mopd-eps-high 5.0
    --mopd-sampling-logprobs-key rollout_log_probs
    --entropy-coef 0.0
    --eps-clip 0.2
    --eps-clip-high 0.28
    --mopd-topk-k "${TOP_K}"
    --mopd-loss-chunk-size "${LOSS_CHUNK}"
)

# ── 并行与重计算 ────────────────────────────────────────────────────
PARALLEL_ARGS=(
    --actor-num-nodes 1
    --actor-num-gpus-per-node "${TRAIN_NPU}"
    --num-gpus-per-node 16
    --rollout-num-gpus "${ROLLOUT_NPU}"
    --rollout-num-gpus-per-engine "${ROLLOUT_NPU}"
    --seq-length "${CONTEXT_LEN}"
    --tensor-model-parallel-size "${TP}"
    --sequence-parallel
    --pipeline-model-parallel-size 1
    --context-parallel-size "${CP}"
    --context-parallel-algo megatron_cp_algo
    --expert-model-parallel-size "${EP}"
    --expert-tensor-parallel-size 1
    --recompute-granularity full
    --recompute-method uniform
    --recompute-num-layers 1
    --use-dynamic-batch-size
    --max-tokens-per-gpu 32768
    --no-gradient-accumulation-fusion
)

# ── 优化器 ──────────────────────────────────────────────────────────
OPTIMIZER_ARGS=(
    --optimizer adam
    --lr "${LR}"
    --lr-decay-style constant
    --weight-decay 0.0
    --adam-beta1 0.9
    --adam-beta2 0.98
    --optimizer-cpu-offload
    --overlap-cpu-optimizer-d2h-h2d
    --use-precision-aware-optimizer
)

# ── SGLang ──────────────────────────────────────────────────────────
SGLANG_ARGS=(
    --sglang-context-length "${CONTEXT_LEN}"
    --sglang-mem-fraction-static 0.65
    --sglang-enable-dp-attention
    --sglang-dp-size 8
    --sglang-enable-dp-lm-head
    --sglang-moe-dense-tp-size 1
    --sglang-cuda-graph-bs 1 2 3 4 8 16
    --sglang-max-running-requests 8
    --sglang-disable-radix-cache
    --sglang-chunked-prefill-size 8192
    --sglang-max-prefill-tokens 8192
    --sglang-device npu
    --sglang-log-level debug
    --sglang-enable-fp32-lm-head
)

# ── 精度与蒸馏设置：在 MODEL_ARGS 之后显式覆盖模型脚本的辅助损失默认值 ─
MISC_ARGS=(
    --moe-router-bias-update-rate 0
    --moe-aux-loss-coeff 0.0
    --attention-dropout 0.0
    --hidden-dropout 0.0
    --bf16
    --accumulate-allreduce-grads-in-fp32
    --attention-softmax-in-fp32
    --no-masked-softmax-fusion
    --no-rope-fusion
    --no-cross-entropy-loss-fusion
    --attention-backend flash
)

TRAIN_COMMAND=(
    python3 -u "${SLIME_ROOT}/train.py"
    "${MODEL_ARGS[@]}"
    "${CHECKPOINT_ARGS[@]}"
    "${ROLLOUT_ARGS[@]}"
    "${MOPD_ARGS[@]}"
    "${PARALLEL_ARGS[@]}"
    "${OPTIMIZER_ARGS[@]}"
    "${SGLANG_ARGS[@]}"
    "${MISC_ARGS[@]}"
)

# ── 作业运行配置：IP/网卡沿用各节点原环境 ────────────────────────────
# 原生 Slime 生成和训练；发布目录不作为自定义模块搜索路径。
RUNTIME_ENV_JSON="$(cat <<JSON
{
  "env_vars": {
    "PYTHONPATH": "/workspace/slime-ascend:/workspace/mbridge:/workspace/Megatron-Bridge/src:/workspace/Megatron-LM:/workspace/MegatronAdaptor:/workspace/sglang/python",
    "PYTHONUNBUFFERED": "1",
    "PYTHONDONTWRITEBYTECODE": "1",
    "PYTHONOPTIMIZE": "0",
    "RAY_DEDUP_LOGS": "0",
    "RAY_EXPERIMENTAL_NOSET_ASCEND_RT_VISIBLE_DEVICES": "1",
    "CUDA_DEVICE_MAX_CONNECTIONS": "1",
    "PYTORCH_NPU_ALLOC_CONF": "expandable_segments:True",
    "HCCL_HOST_SOCKET_PORT_RANGE": "60000-60050",
    "HCCL_NPU_SOCKET_PORT_RANGE": "61000-61050",
    "HCCL_CONNECT_TIMEOUT": "3600",
    "HCCL_EXEC_TIMEOUT": "3600",
    "HYDRA_FULL_ERROR": "1",
    "HF_HOME": "/workspace/mopd-cache/hf",
    "HF_MODULES_CACHE": "/workspace/mopd-cache/hf/modules",
    "TORCHINDUCTOR_CACHE_DIR": "/workspace/mopd-cache/inductor",
    "ASCEND_USE_FIA": "true"
  }
}
JSON
)"

# ── 记录本次配置，交由 Ray 管理训练进程 ──────────────────────────────
mkdir -p "${EXPERIMENT_ROOT}"
mkdir "${EXPERIMENT_DIR}"
cp "${SCRIPT_PATH}" "${EXPERIMENT_DIR}/run.sh"
printf 'JOB_ID=%s\nEXPERIMENT_DIR=%s\nCHECKPOINT_DIR=%s\n训练日志：%s\n' \
    "${JOB_ID}" "${EXPERIMENT_DIR}" "${CHECKPOINT_DIR}" "${TRAIN_LOG}" | tee "${SUBMIT_LOG}"
printf 'TRAIN_COMMAND: ' >> "${SUBMIT_LOG}"
printf '%q ' "${TRAIN_COMMAND[@]}" >> "${SUBMIT_LOG}"
printf '\n' >> "${SUBMIT_LOG}"

cd "${SLIME_ROOT}"
ray job submit \
    --address "${RAY_ADDRESS}" \
    --submission-id "${JOB_ID}" \
    --no-wait \
    --runtime-env-json "${RUNTIME_ENV_JSON}" \
    -- "${TRAIN_COMMAND[@]}" 2>&1 | tee -a "${SUBMIT_LOG}"

# 在后台将 Ray 日志写入文件，关闭日志进程的 Python 输出缓冲。
PYTHONUNBUFFERED=1 nohup ray job logs -f "${JOB_ID}" >> "${TRAIN_LOG}" 2>&1 < /dev/null &
printf '提交成功，JOB_ID=%s（训练由 Ray 管理，可关闭当前终端）\n查看日志：tail -F %s\n' \
    "${JOB_ID}" "${TRAIN_LOG}"
