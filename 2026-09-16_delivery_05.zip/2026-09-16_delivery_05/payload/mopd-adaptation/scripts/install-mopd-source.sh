#!/usr/bin/env bash
# 仅覆盖 MOPD 源码；不运行 git am/commit/reset，不安装依赖，不启动训练。
# 必须由 29b 入口在原有 prepare_env.sh 成功之后调用。
set -euo pipefail
PACKAGE=/workspace/mopd-adaptation
SOURCE=/workspace/mopd-adaptation/source-overlay
TARGET=/workspace/slime-ascend

# 必要检查：所有源文件与目标路径可用后才开始复制。
test -d "${SOURCE}"
test -d "${TARGET}/slime"
test ! -L "${TARGET}"

count=0
while IFS=$'\t' read -r mode path expected; do
    [[ "${mode}" == 100644 || "${mode}" == 100755 ]]
    [[ -n "${path}" && "${path}" != /* && "${path}" != *..* ]]
    test -f "${SOURCE}/${path}"
    test ! -L "${SOURCE}/${path}"
    test ! -d "${TARGET}/${path}"
    [[ "$(realpath -m "${TARGET}/${path}")" == "${TARGET}/${path}" ]]
    count=$((count + 1))
done < "${PACKAGE}/source-overlay-files.tsv"
[[ "${count}" == 23 ]]
mkdir -p "${TARGET}/examples/multi_teacher_on_policy_distillation" "${TARGET}/tests/tests_npu/ut" "${TARGET}/tools"

# 生产源码：源文件 -> 同名目标文件，逐条列出，方便审核。
cp -p "${SOURCE}/slime/backends/megatron_utils/actor.py" "${TARGET}/slime/backends/megatron_utils/actor.py"
cp -p "${SOURCE}/slime/backends/megatron_utils/data.py" "${TARGET}/slime/backends/megatron_utils/data.py"
cp -p "${SOURCE}/slime/backends/megatron_utils/loss.py" "${TARGET}/slime/backends/megatron_utils/loss.py"
cp -p "${SOURCE}/slime/backends/megatron_utils/model.py" "${TARGET}/slime/backends/megatron_utils/model.py"
cp -p "${SOURCE}/slime/ray/placement_group.py" "${TARGET}/slime/ray/placement_group.py"
cp -p "${SOURCE}/slime/ray/rollout.py" "${TARGET}/slime/ray/rollout.py"
cp -p "${SOURCE}/slime/rollout/rm_hub/__init__.py" "${TARGET}/slime/rollout/rm_hub/__init__.py"
cp -p "${SOURCE}/slime/utils/arguments.py" "${TARGET}/slime/utils/arguments.py"
cp -p "${SOURCE}/slime/utils/ppo_utils.py" "${TARGET}/slime/utils/ppo_utils.py"

# 配套示例、测试和工具：仅复制，不在安装时执行。
cp -p "${SOURCE}/tools/convert_torch_dist_to_hf_parallel.py" "${TARGET}/tools/convert_torch_dist_to_hf_parallel.py"
cp -p "${SOURCE}/examples/multi_teacher_on_policy_distillation/run-qwen3-8B-mopd-full-vocab-npu-a3-1node-16npu.sh" "${TARGET}/examples/multi_teacher_on_policy_distillation/run-qwen3-8B-mopd-full-vocab-npu-a3-1node-16npu.sh"
cp -p "${SOURCE}/examples/multi_teacher_on_policy_distillation/run-qwen3-8B-mopd-token-level-npu-a3-1node.sh" "${TARGET}/examples/multi_teacher_on_policy_distillation/run-qwen3-8B-mopd-token-level-npu-a3-1node.sh"
cp -p "${SOURCE}/examples/multi_teacher_on_policy_distillation/run-qwen3-8B-mopd-topk-npu-a3-1node-16npu.sh" "${TARGET}/examples/multi_teacher_on_policy_distillation/run-qwen3-8B-mopd-topk-npu-a3-1node-16npu.sh"
cp -p "${SOURCE}/tests/test_mopd_full_vocab.py" "${TARGET}/tests/test_mopd_full_vocab.py"
cp -p "${SOURCE}/tests/test_mopd_token_level.py" "${TARGET}/tests/test_mopd_token_level.py"
cp -p "${SOURCE}/tests/test_mopd_topk.py" "${TARGET}/tests/test_mopd_topk.py"
cp -p "${SOURCE}/tests/tests_npu/ut/test_mopd_full_vocab_npu.py" "${TARGET}/tests/tests_npu/ut/test_mopd_full_vocab_npu.py"
cp -p "${SOURCE}/tests/tests_npu/ut/test_mopd_tensor_backuper_npu.py" "${TARGET}/tests/tests_npu/ut/test_mopd_tensor_backuper_npu.py"
cp -p "${SOURCE}/tests/tests_npu/ut/test_mopd_topk_npu.py" "${TARGET}/tests/tests_npu/ut/test_mopd_topk_npu.py"
cp -p "${SOURCE}/tools/generate_mopd_smoke_data.py" "${TARGET}/tools/generate_mopd_smoke_data.py"
cp -p "${SOURCE}/tools/validate_mopd_full_vocab_log.py" "${TARGET}/tools/validate_mopd_full_vocab_log.py"
cp -p "${SOURCE}/tools/validate_mopd_token_level_log.py" "${TARGET}/tools/validate_mopd_token_level_log.py"
cp -p "${SOURCE}/tools/validate_mopd_topk_log.py" "${TARGET}/tools/validate_mopd_topk_log.py"
echo "MOPD 源码复制完成：${TARGET}"
