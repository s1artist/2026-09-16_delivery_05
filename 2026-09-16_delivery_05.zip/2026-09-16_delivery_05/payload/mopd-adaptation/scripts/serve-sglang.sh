#!/usr/bin/env bash
# 单一职责：固定独立 SGLang 配置、保存快照、内部后台启动并输出记录位置。
# 在已完成原镜像＋补丁及 Ascend 环境准备的新容器内运行。
set -euo pipefail

# ── 显式路径与本次实验 ───────────────────────────────────────────
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
SCRIPT_PATH="${SCRIPT_DIR}/$(basename -- "${BASH_SOURCE[0]}")"
MODEL=/hpfs/huawei/songchunjiang/mopd-delivery-05/models/mopd-export-hf/short_05-iter_0000299
EXPERIMENT_ROOT=/hpfs/huawei/songchunjiang/mopd-delivery-05/experiments
EXPERIMENT_NAME=2026-09-16_sglang_short_05
RUN="${EXPERIMENT_ROOT}/${EXPERIMENT_NAME}"
SERVER_LOG="${RUN}/server.log"
SERVER_PID_FILE="${RUN}/server.pid"
HOST=0.0.0.0
PORT=30000
# 填该容器实际分配的八张空闲 NPU 编号；不在此探测或选择设备。
VISIBLE_NPUS=0,1,2,3,4,5,6,7

# ── 运行环境：沿用原演练的显式设置；IP/网卡由容器环境准备 ────────
export ASCEND_RT_VISIBLE_DEVICES="${VISIBLE_NPUS}"
export PYTHONPATH=/workspace/slime-ascend:/workspace/mbridge:/workspace/Megatron-Bridge/src:/workspace/Megatron-LM:/workspace/MegatronAdaptor:/workspace/sglang/python
export PYTHONUNBUFFERED=1
export PYTHONDONTWRITEBYTECODE=1
export PYTHONOPTIMIZE=0
export CUDA_DEVICE_MAX_CONNECTIONS=1
export PYTORCH_NPU_ALLOC_CONF=expandable_segments:True
export HCCL_HOST_SOCKET_PORT_RANGE=60000-60050
export HCCL_NPU_SOCKET_PORT_RANGE=61000-61050
export HCCL_CONNECT_TIMEOUT=3600
export HCCL_EXEC_TIMEOUT=3600
export ASCEND_USE_FIA=true
export HF_HOME="${RUN}/cache/hf"
export HF_MODULES_CACHE="${RUN}/cache/hf/modules"
export TORCHINDUCTOR_CACHE_DIR="${RUN}/cache/inductor"

# ── 服务配置：来自原演练的 SGLANG_ARGS，改为原生参数名 ────────────
# trust-remote-code / TP=8 / skip-server-warmup 来自 Slime 的服务构造逻辑。
# 此处加载指定训练 checkpoint 导出的 HF 目录；更换轮次或长序列权重时显式修改 MODEL。
# enable_thinking 是请求构造阶段的模板选项，不是本服务的启动参数。
SERVER_COMMAND=(
    python3 -B -u -m sglang.launch_server
    --model-path "${MODEL}"
    --trust-remote-code
    --host "${HOST}"
    --port "${PORT}"
    --device npu
    --tp-size 8
    --context-length 131072
    --mem-fraction-static 0.65
    --enable-dp-attention
    --dp-size 8
    --enable-dp-lm-head
    --moe-dense-tp-size 1
    --cuda-graph-bs 1 2 3 4 8 16
    --max-running-requests 8
    --disable-radix-cache
    --chunked-prefill-size 8192
    --max-prefill-tokens 8192
    --enable-fp32-lm-head
    --skip-server-warmup
    --log-level debug
)

# ── 本次快照与日志：新目录保留失败记录，重跑更换实验序号 ──────────
mkdir -p "${EXPERIMENT_ROOT}"
mkdir "${RUN}"
cp "${SCRIPT_PATH}" "${RUN}/run.sh"
printf '%q ' "${SERVER_COMMAND[@]}" > "${RUN}/command.txt"
printf '\n' >> "${RUN}/command.txt"

# nohup 直接执行 Python，$! 对应 SGLang 主进程，而不是 Bash/tee 包装进程。
# 父脚本不等待模型加载；进程存在与健康接口就绪在独立步骤中查询。
nohup "${SERVER_COMMAND[@]}" < /dev/null > "${SERVER_LOG}" 2>&1 &
SERVER_PID=$!
printf '%s\n' "${SERVER_PID}" > "${SERVER_PID_FILE}"
printf '已发起后台启动，服务就绪待查询。\nRUN=%s\nPID=%s\nBASE_URL=http://127.0.0.1:%s\n日志：%s\nPID文件：%s\ntail -F %s\n' \
    "${RUN}" "${SERVER_PID}" "${PORT}" "${SERVER_LOG}" "${SERVER_PID_FILE}" "${SERVER_LOG}"
