#!/usr/bin/env bash
# 仅用于新建、无实验在用的容器。原有 prepare_env.sh 不修改。
set -euo pipefail

# 三个目录随安装包预置在同一共享路径；每个新容器执行一次。
for source in \
    /hpfs/huawei/songchunjiang/mopd-delivery-05/workspace-utils \
    /hpfs/huawei/songchunjiang/mopd-delivery-05/Emerging-Optimizers \
    /hpfs/huawei/songchunjiang/mopd-delivery-05/mopd-adaptation; do
    test -d "${source}"
    test ! -e "/workspace/${source##*/}"
    test ! -L "/workspace/${source##*/}"
done

cp -r /hpfs/huawei/songchunjiang/mopd-delivery-05/workspace-utils /workspace
cp -r /hpfs/huawei/songchunjiang/mopd-delivery-05/Emerging-Optimizers /workspace

# 复制本次适配代码及安装器。
cp -r /hpfs/huawei/songchunjiang/mopd-delivery-05/mopd-adaptation /workspace

# 原有 MHC/MUON 等 patch，保持不变。
bash /workspace/workspace-utils/scripts/env/prepare_env.sh

# 覆盖本次 MOPD 修改后的完整源文件。
bash /workspace/mopd-adaptation/scripts/install-mopd-source.sh

# 沿用已提供的 29B 文件覆盖步骤。
bash /workspace/workspace-utils/scripts/env/apply_29b_pr_files.sh
