# 基于  slime-ascend030:a3-0.2 镜像
set -ex

# install Emerging-Optimizers
echo "install Emerging-Optimizers"
cd /workspace/Emerging-Optimizers && pip install -e . --no-build-isolation

echo "install Megatron MHC && MUON patch"
cd /workspace/Megatron-LM && git am --whitespace=fix /workspace/workspace-utils/patch/Megatron/*

echo "install mbridge patch"
cd /workspace/mbridge && git am --whitespace=fix /workspace/workspace-utils/patch/mbridge/*

echo "install sglang patch"
cd /workspace/sglang && git am --whitespace=fix /workspace/workspace-utils/patch/sglang/*

# 临时覆盖
echo "install slime patch"
cd /workspace/slime-ascend && git am --whitespace=fix /workspace/workspace-utils/patch/slime-ascend/*

cd /workspace/slime-ascend