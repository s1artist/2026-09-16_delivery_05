#!/bin/bash
set -e

PATCH_ROOT="/workspace/workspace-utils/patches/29b"

cp "${PATCH_ROOT}/TransformerEngineNPU/transformer_engine/pytorch/ops/basic/rmsnorm.py" \
   /workspace/TransformerEngineNPU/transformer_engine/pytorch/ops/basic/rmsnorm.py

cp "${PATCH_ROOT}/Megatron-LM/megatron/core/models/common/embeddings/rope_utils.py" \
   /workspace/Megatron-LM/megatron/core/models/common/embeddings/rope_utils.py

cp "${PATCH_ROOT}/Megatron-LM/megatron/core/transformer/hyper_connection.py" \
   /workspace/Megatron-LM/megatron/core/transformer/hyper_connection.py

cp "${PATCH_ROOT}/Megatron-LM/megatron/core/transformer/transformer_layer.py" \
   /workspace/Megatron-LM/megatron/core/transformer/transformer_layer.py

cp "${PATCH_ROOT}/sglang/python/sglang/srt/layers/logits_processor.py" \
   /workspace/sglang/python/sglang/srt/layers/logits_processor.py

cp "${PATCH_ROOT}/sglang/python/sglang/srt/layers/mhc_npu_ops.py" \
   /workspace/sglang/python/sglang/srt/layers/mhc_npu_ops.py

cp "${PATCH_ROOT}/sglang/python/sglang/srt/layers/moe/fused_moe_native.py" \
   /workspace/sglang/python/sglang/srt/layers/moe/fused_moe_native.py

cp "${PATCH_ROOT}/sglang/python/sglang/srt/models/deepseek_v2.py" \
   /workspace/sglang/python/sglang/srt/models/deepseek_v2.py

cp "${PATCH_ROOT}/sglang/python/sglang/srt/models/hyper_connection.py" \
   /workspace/sglang/python/sglang/srt/models/hyper_connection.py
