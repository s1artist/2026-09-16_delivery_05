#!/bin/bash

RANK=0
[ "$1" == "--worker" ] && RANK=1

# 杀掉所有可能残留的进程
pkill -9 sglang || true
pkill -9 ray || true  
pkill -9 python || true
pkill -9 redis || true
sleep 5
pkill -9 ray || true
pkill -9 python || true

# 清理 Ray 状态
ray stop --force || true
sleep 3
# will prevent ray from buffering stdout/stderr
export PYTHONBUFFERED=16
# 多机 HCCL 配置
export HCCL_SOCKET_IFNAME=bond1.2200
export GLOO_SOCKET_IFNAME=bond1.2200
export HCCL_CONNECT_TIMEOUT=1200
export HCCL_EXEC_TIMEOUT=1200
export TORCH_DIST_TIMEOUT=1200
export RAY_EXPERIMENTAL_NOSET_ASCEND_RT_VISIBLE_DEVICES=1
export HCCL_HOST_SOCKET_PORT_RANGE=60000-60050
export HCCL_NPU_SOCKET_PORT_RANGE=61000-61050
export HYDRA_FULL_ERROR=1
export ASCEND_RT_VISIBLE_DEVICES=0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15
# 减少显存碎片
export PYTORCH_ALLOC_CONF=expandable_segments:True

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" &>/dev/null && pwd)"
source "/workspace/slime-ascend/scripts/models/telechat3-29B-Moe.sh"

CKPT_ARGS=(
   --hf-checkpoint /workspace/weights/TeleChat4-29B
   --ref-load /workspace/offline/torchdist_weights_8t_test
)

ROLLOUT_ARGS=(
   --prompt-data /workspace/data/dapo-math-17k/dapo-math-17k.jsonl
   --input-key prompt
   --label-key label
   --apply-chat-template
   --rollout-shuffle
   --rm-type deepscaler
   --num-rollout 300
   --rollout-batch-size 4
   --n-samples-per-prompt 4
   --rollout-max-response-len 512
   --rollout-temperature 1
   --global-batch-size 16
   --balance-data
)

PERF_ARGS=(
   #--debug-rollout-only
   #--save-debug-rollout-data /worksapce/rollout/rollout_{rollout_id}.pt
   #  --debug-train-only
   --tensor-model-parallel-size 2
   --pipeline-model-parallel-size 1
   --context-parallel-size 1
   --sequence-parallel
   --expert-model-parallel-size 16
   --expert-tensor-parallel-size 1
   --recompute-granularity full
   --recompute-method uniform
   --recompute-num-layers 1
   --use-dynamic-batch-size
   --max-tokens-per-gpu 4096
   --manual-gc
   --empty-unused-memory-level 2
   # 禁用梯度累计融合
   # --no-gradient-accumulation-fusion
   # --micro-batch-size 1
   # --grad-reduce-in-bf16
)

GRPO_ARGS=(
   --advantage-estimator grpo
   --use-kl-loss
   --kl-loss-coef 0.001
   --kl-loss-type low_var_kl
   --entropy-coef 0.00
   --eps-clip 0.2
   --eps-clip-high 0.28
   # whether enabling TIS
   --use-tis
)

OPTIMIZER_ARGS=(
   --optimizer muon
   --lr 1e-6
   --lr-decay-style constant
   --weight-decay 0.05
   --adam-beta1 0.9
   --adam-beta2 0.98
   --overlap-cpu-optimizer-d2h-h2d
   # 显存优化（只支持adam）
   #--optimizer-cpu-offload
   #--use-precision-aware-optimizer
)

WANDB_ARGS=(
   # --use-wandb
   # --wandb-project slime-dev
   # --wandb-group search_r1_qwen2.5-3B-test
   # --wandb-key ${WANDB_KEY}
)

SGLANG_ARGS=(
   --rollout-num-gpus-per-engine 8
   --sglang-mem-fraction-static 0.8
   --sglang-enable-dp-attention
   --sglang-dp-size 8
   --sglang-enable-dp-lm-head
   --sglang-moe-dense-tp-size 1
   --sglang-dtype bfloat16
   --sglang-disable-cuda-graph
   --sglang-cuda-graph-max-bs 16
   --sglang-max-running-requests 64
   --sglang-disable-radix-cache
   --sglang-chunked-prefill-size -1
   --sglang-device npu
   --sglang-log-level debug
)

MISC_ARGS=(
   # default dropout in megatron is 0.1
   --attention-dropout 0.0
   --hidden-dropout 0.0
   # should be good for model performance
   --accumulate-allreduce-grads-in-fp32
   --attention-softmax-in-fp32
   # need to comment this when using model with MLA
   --attention-backend flash
   --moe-token-dispatcher-type alltoall
)

export WORLD_SIZE=16
export MASTER_ADDR="10.127.10.166"
export RANK=${RANK}

if [ "$RANK" -eq 0 ]; then
    echo "启动主节点..."
    ray start --head \
	--port 6379 \
        --node-ip-address ${MASTER_ADDR} \
        --num-gpus 16 \
        --disable-usage-stats \
        --dashboard-host=0.0.0.0 \
        --dashboard-port=8265 \
	--resources='{"NPU": '16'}'
    RUNTIME_ENV_JSON="{
        \"env_vars\": {
            \"PYTHONPATH\": \"/workspace/mbridge:/workspace/Megatron-Bridge/src:/workspace/Megatron-LM/:/workspace/sglang/python:${SCRIPT_DIR}:$PYTHONPATH\",
            \"CUDA_DEVICE_MAX_CONNECTIONS\": \"1\",
            \"ASCEND_TOOLKIT_HOME\": \"/usr/local/Ascend/cann-9.0.0\",
            \"ASCEND_OPP_PATH\": \"/usr/local/Ascend/cann-9.0.0/opp\",
            \"ASCEND_AICPU_PATH\": \"/usr/local/Ascend/cann-9.0.0/aicpu\",
            \"ASCEND_HOME_PATH\": \"/usr/local/Ascend/cann-9.0.0\"
        }
    }"
    ray job submit --address="http://${MASTER_ADDR}:8265" \
        --runtime-env-json="${RUNTIME_ENV_JSON}" \
        -- python3 train.py \
        --actor-num-nodes 2 \
        --actor-num-gpus-per-node 16 \
	--rollout-num-gpus 8 \
        --use-fault-tolerance \
        ${MODEL_ARGS[@]} \
        ${CKPT_ARGS[@]} \
        ${ROLLOUT_ARGS[@]} \
        ${OPTIMIZER_ARGS[@]} \
        ${GRPO_ARGS[@]} \
        ${WANDB_ARGS[@]} \
        ${PERF_ARGS[@]} \
        ${SGLANG_ARGS[@]} \
        ${MISC_ARGS[@]} \
        2>&1 | tee "train.log"
else
    echo "启动从节点..."
    # ray start --address="${MASTER_ADDR}:6379" --resources='{"NPU": '8'}' --node-ip-address=10.127.10.167 --block
    ray start --address="${MASTER_ADDR}:6379" --resources='{"NPU": '16'}' --node-ip-address=10.127.10.167 --block
fi