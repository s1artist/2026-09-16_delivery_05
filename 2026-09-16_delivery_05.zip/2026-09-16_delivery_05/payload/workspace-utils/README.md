## slime 0.3.0 训练复现（GRPO）

### 镜像 && 容器

```shell
sudo docker run -d -it --ipc=host --network host --name "29B_RL_030" --privileged \
--device /dev/davinci1 \
--device /dev/davinci_manager \
--device /dev/devmm_svm \
--device /dev/hisi_hdc \
-v /usr/local/dcmi:/usr/local/dcmi \
-v /usr/bin/hccn_tool:/usr/bin/hccn_tool \
-v /usr/local/bin/npu-smi:/usr/local/bin/npu-smi \
-v /usr/local/Ascend/driver/:/usr/local/Ascend/driver/ \
-v /usr/local/Ascend/firmware:/usr/local/Ascend/firmware \
-v /usr/local/sbin/:/usr/local/sbin/ \
-v /hpfs/huawei/wanghairui/weights:/workspace/weights \
-v /hpfs/huawei/wanghairui/offline/Emerging-Optimizers:/workspace/Emerging-Optimizers \
-v /hpfs/huawei/wanghairui/workspace-utils:/workspace/workspace-utils \
slime-ascend030:a3-0.2 /bin/bash

sudo docker exec -it {container_id} /bin/bash
```

### 代码适配/patch

```shell
bash /workspace/workspace-utils/scripts/env/prepare_env.sh
```

### 启动

```shell
cd /workspace/slime-ascend && bash ./scripts/run-tele4_29B_with_adam.sh
```

#### 复现精度：

- 基于当前代码适配 && 参数下，rollout\_log\_probs - ref\_log\_probs 稳定在 0.001\~ 0.002
- logprob MAE ( train\_rollout\_logprob\_abs\_diff ) 稳定在 0.014 \~ 0.018
- 开源模型精度参考：
  - 基于该分支 glm 4.7 GPU 基线 train\_rollout\_logprob\_abs\_diff：0.02\~0.04
  - 基于该分支 glm 4.7 NPU 基线 train\_rollout\_logprob\_abs\_diff：0.03\~0.04

### 附0：权重转换

```shell
# 示例，实际转化时修改为实际路径
cd /workspace/slime-ascend && source ./scripts/models/telechat4-29B-Moe.sh
PYTHONPATH=/usr/local/Ascend/cann-9.0.0/python/site-packages:/usr/local/Ascend/cann-9.0.0/opp/built-in/op_impl/ai_core/tbe:/usr/local/Ascend/ascend-toolkit/latest/python/site-packages:/usr/local/Ascend/ascend-toolkit/latest/opp/built-in/op_impl/ai_core/tbe:/workspace/Megatron-Bridge/src:/workspace/Megatron-LM/ torchrun --nproc_per_node 16 tools/convert_hf_to_torch_dist.py \
	${MODEL_ARGS[@]} \
	--hf-checkpoint /workspace/weights/29B_12.05T_256K_hybrid_260703_exp1_step10000_hf \
	--save /workspace/weights/29B_12.05T_256K_hybrid_260703_exp1_step10000_dist1
```

#### 附1：项目目录详述

```
--- dataset       # 常用数据集
--- experiments   # 精度对齐实验记录
--- patch         # 基于计算基线版本的定制patch
--- scripts       # 脚本，如环境初始化，调测脚本等
```

