# Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.

import math
from typing import TYPE_CHECKING, Optional, Tuple

import torch
import torch.nn as nn
from torch import Tensor

from megatron.core.transformer.module import MegatronModule
from megatron.core.transformer.transformer_config import TransformerConfig
from megatron.core.utils import nvtx_decorator, nvtx_range

if TYPE_CHECKING:
    from megatron.core.tensor_parallel.random import CheckpointManager


@torch.compile
def _sinkhorn_iterations(input_logits: Tensor, num_iterations: int, eps: float) -> Tensor:
    row_max = input_logits.max(dim=-1, keepdim=True).values
    M = torch.exp(input_logits - row_max)
    for _ in range(num_iterations):
        # Use sum+eps (not clamp(min=eps)) to match mindformers SinkhornKnopp
        M = M / (M.sum(dim=-1, keepdim=True) + eps)
        M = M / (M.sum(dim=-2, keepdim=True) + eps)
    return M


class SinkhornKnopp(torch.autograd.Function):
    """Sinkhorn-Knopp projection to doubly stochastic matrix.

    This is an autograd.Function because the iterative forward is re-executed
    during backward (under torch.enable_grad) so that PyTorch's autograd can
    differentiate through it without storing all intermediate iteration states.
    """

    @staticmethod
    def forward(ctx, input_logits: Tensor, num_iterations: int, eps: float = 1e-6) -> Tensor:
        """Run Sinkhorn iterations and save inputs for backward recomputation."""
        M = _sinkhorn_iterations(input_logits, num_iterations, eps)
        ctx.save_for_backward(input_logits)
        ctx.num_iterations = num_iterations
        ctx.eps = eps
        return M

    @staticmethod
    def backward(ctx, grad_output: Tensor):
        """Recompute forward under enable_grad and back-propagate."""
        (input_logits,) = ctx.saved_tensors
        with torch.enable_grad():
            logits = input_logits.detach().requires_grad_(True)
            M = _sinkhorn_iterations(logits, ctx.num_iterations, ctx.eps)
            M.backward(grad_output)
        return logits.grad, None, None


def native_sinkhorn(input_logits: Tensor, num_iterations: int, eps: float = 1e-6) -> Tensor:
    """Native Sinkhorn-Knopp (autograd.Function wrapper)."""
    return SinkhornKnopp.apply(input_logits, num_iterations, eps)


@torch.compile
def native_h_aggregate(x: Tensor, h_pre: Tensor) -> Tensor:
    """Native n-stream weighted aggregation: out = sum_j(h_pre_j * x_j).

    Uses BatchMatMul ([s,b,1,n] @ [s,b,n,C]) to match mindformers pre_mm.
    Aligns with mindformers: cast h_pre to x's dtype (bf16) for BatchMatMul,
    matching mindformers construct() which casts h_pre to self.dtype (bf16).
    """
    # h_pre: [s, b, n] fp32, x: [s, b, n, C] bf16
    out = torch.matmul(h_pre.to(x.dtype).unsqueeze(2), x).squeeze(2)  # [s, b, C] bf16
    return out.to(x.dtype)


@torch.compile
def native_h_post_bda(
    h_res: Tensor, original_residual: Tensor, h_post: Tensor, x: Tensor, bias: Optional[Tensor]
) -> Tensor:
    """Native H_res @ residual + H_post * (x [+ bias]).

    Aligns with mindformers HyperConnectionOutputCell:
    - Compute in bf16 (matching mindformers self.dtype)
    - Add bias to x FIRST, then multiply by H_post (matching mindformers order:
      add_bias → dropout → output_cell), not H_post*x + H_post*bias separately.
    - Use BatchMatMul ([s,b,n,n] @ [s,b,n,C], folded to 3D torch.bmm).
      torch_npu maps bmm to aclnnBatchMatMul, matching mindformers' res_mm
      exactly; torch.matmul(4D) may take a different kernel path.
    h_res/h_post are stored as fp32 by compute_mappings (matching mindformers),
    but cast to bf16 here to match mindformers' BatchMatMul/Mul dtype.
    """
    out_dtype = original_residual.dtype  # bf16
    s, b, n, C = original_residual.shape
    # Cast h_res/h_post from fp32 to bf16 to match mindformers computation.
    # Order: cast FIRST, then reshape/unsqueeze — matches mindformers'
    # `cast(original_streams, self.dtype)` → `reshape_streams(...)` sequence
    # in HyperConnectionOutputCell.construct, avoiding boundary ULP drift
    # when the upstream tensor is fp32 (warmup/inference).
    h_res_bf16 = h_res.to(out_dtype)      # [s, b, n, n] bf16
    h_post_bf16 = h_post.to(out_dtype)    # [s, b, n]   bf16
    # Match mindformers: original_streams is [s,b,n*C] bf16 input; mindformers
    # reshapes AFTER cast. Here original_residual is already 4D [s,b,n,C] bf16,
    # so no reshape needed, but we keep the cast-before-reshape contract.
    # 4D BatchMatMul: [s,b,n,n] @ [s,b,n,C] → [s,b,n,C] (matches mindformers res_mm)
    mixed = torch.matmul(h_res_bf16, original_residual)  # bf16  (res_part)
    # Match mindformers order: add bias to x FIRST, then multiply by H_post
    if bias is not None:
        x = x + bias  # bf16 add (bias broadcast to [1,1,C])
    x_expanded = h_post_bf16.unsqueeze(-1) * x.unsqueeze(2)  # [s,b,n,1]*[s,b,1,C] → [s,b,n,C] bf16  (post_part)
    # Align add order with mindformers HyperConnectionOutputCell.construct:
    #   mindformers: output = self.add_output(res_part, post_part)  →  res + post
    # bf16 is non-associative/non-commutative in the last bit; flipping the
    # order introduces a persistent 1-ULP bias that accumulates across
    # layers. Use `mixed + x_expanded` (= res_part + post_part) here.
    out = mixed + x_expanded

    return out.to(out_dtype)


@torch.compile
def native_proj_rms(x: Tensor, weight: Tensor, eps: float = 1e-6) -> Tuple[Tensor, Tensor]:
    """Native fused projection + RMS normalization.

    Keeps original Megatron order (matmul first, then r), but uses the
    mindformers RMSNorm formula: r = rsqrt(mean(x²) + eps) instead of
    r = 1/(sqrt(mean(x²)) + eps). This closes the h_post 1e-3 gap caused
    by the eps placement difference between the two formulas.
    """
    proj = torch.matmul(x, weight.t())  # bf16 (input dtype)
    # Compute r in fp32 with mindformers formula: rsqrt(mean(x²)+eps)
    x_fp32 = x.float()
    mean_sq = x_fp32.pow(2).mean(dim=-1, keepdim=True)
    r = torch.rsqrt(mean_sq + eps)  # fp32
    return proj, r


# ============================================================================
# HyperConnectionModule
# ============================================================================


# TODO: keep hyper connection in fp32 computation
class HyperConnectionModule(MegatronModule):
    """
    Unified mHC (Manifold-Constrained Hyper-Connections) module.

    Implements the complete mHC propagation:
        x_{l+1} = H_res @ x_l + H_post^T @ F(H_pre @ x_l)

    This module handles:
    1. Computing learnable mappings: H_pre, H_post, H_res (with Sinkhorn-Knopp projection)
    2. Aggregation: n-stream → 1-stream (H_pre @ x)
    3. Expansion: 1-stream → n-stream (H_post^T @ output)
    4. Residual merge: H_res @ x + expanded_output
    5. Block-level expand/contract for TransformerBlock boundaries

    Args:
        config: TransformerConfig with hyper-connection fields
        layer_number: Current layer index for initialization
    """

    def __init__(self, config: TransformerConfig, layer_number: int):
        super().__init__(config)
        self.config = config
        self.layer_number = layer_number
        self.n = config.num_residual_streams
        self.hidden_size = config.hidden_size
        self.sinkhorn_iterations = config.mhc_sinkhorn_iterations
        # add h_res clamp
        self.mhc_h_res_clamp_min = config.mhc_h_res_clamp_min
        self.mhc_h_res_clamp_max = config.mhc_h_res_clamp_max


        # Projection weights for dynamic mappings
        # Input: [s, b, n*C] -> Output: n^2 + 2n values per token
        # - H_pre: n values
        # - H_post: n values
        # - H_res: n^2 values (before Sinkhorn projection)
        self.mapping_proj = nn.Linear(
            self.n * self.hidden_size, self.n * self.n + 2 * self.n, bias=False
        )

        init_alpha = config.mhc_init_gating_factor
        # Learnable scaling factors (Eq. 5 in paper)
        self.alpha_pre = nn.Parameter(torch.full((1,), init_alpha))
        self.alpha_post = nn.Parameter(torch.full((1,), init_alpha))
        self.alpha_res = nn.Parameter(torch.full((1,), init_alpha))

        # Static bias terms
        self.bias = nn.Parameter(torch.zeros(self.n * self.n + 2 * self.n))
        self.norm_eps = 1e-6

        # Choose implementation: fused cuTile kernels vs reference modules.
        # Both paths expose the same call signatures so the rest of the code
        # is implementation-agnostic.
        if config.use_fused_mhc:
            from megatron.core.fusions.fused_mhc_kernels import (
                fused_h_aggregate,
                fused_h_post_bda,
                fused_proj_rms,
                fused_sinkhorn,
            )

            self._sinkhorn_op = fused_sinkhorn
            self._h_aggregate_op = fused_h_aggregate
            self._h_post_bda_op = fused_h_post_bda
            self._proj_rms_op = fused_proj_rms
        else:
            self._sinkhorn_op = native_sinkhorn
            self._h_aggregate_op = native_h_aggregate
            self._h_post_bda_op = native_h_post_bda
            self._proj_rms_op = native_proj_rms

        self._init_weights()

    def _init_weights(self) -> None:
        """Initialize weights for stable training."""
        nn.init.xavier_uniform_(self.mapping_proj.weight)

        # Set sequence_parallel attribute on parameters for gradient synchronization
        # across TP ranks when sequence_parallel is enabled.
        # This is required because HyperConnectionModule uses non-TP-aware layers
        # (nn.Linear, nn.RMSNorm) whose gradients need to be all-reduced.
        if self.config.sequence_parallel:
            setattr(self.mapping_proj.weight, 'sequence_parallel', True)
            setattr(self.alpha_pre, 'sequence_parallel', True)
            setattr(self.alpha_post, 'sequence_parallel', True)
            setattr(self.alpha_res, 'sequence_parallel', True)
            setattr(self.bias, 'sequence_parallel', True)

    def _projection_and_get_norm(self, x: Tensor) -> Tuple[Tensor, Tensor]:
        """
        Projection + RMS normalization.

        Args:
            x: [s, b, n*C] - n-stream hidden states
        """
        s, b, nC = x.shape
        x_2d = x.reshape(s * b, nC)
        proj, r = self._proj_rms_op(x_2d, self.mapping_proj.weight, self.norm_eps)
        return proj.view(s, b, -1), r.view(s, b, 1)

    @torch.compile
    def _compute_h(self, proj: Tensor, r: Tensor) -> Tuple[Tensor, Tensor, Tensor]:
        """
        Compute h from projected hidden states and scaling factors.

        Original Megatron formula h = r * proj * alpha + bias, but computed
        in fp32 (mindformers stores h_pre/h_post/h_res as fp32). Returns
        fp32 tensors — compute_mappings leaves them as fp32 to match
        mindformers storage dtype.
        """
        # Upcast to fp32 for stable alpha/bias/sigmoid (matches mindformers)
        proj_fp32 = proj.float()
        r_fp32 = r.float()  # r already fp32 from native_proj_rms
        alpha_ = torch.cat(
            [
                self.alpha_pre.expand(self.n),
                self.alpha_post.expand(self.n),
                self.alpha_res.expand(self.n * self.n),
            ],
            dim=-1,
        ).float()
        h = r_fp32 * proj_fp32 * alpha_ + self.bias.float()
        # H_pre = σ(α_pre * (θ_pre @ x̃) + b_pre)
        h_pre = h[..., : self.n].sigmoid()  # [s, b, n]

        # H_post = 2σ(α_post * (θ_post @ x̃) + b_post)
        h_post = h[..., self.n : 2 * self.n].sigmoid() * 2  # [s, b, n]
        h_res = h[..., 2 * self.n :]
        return h_pre, h_post, h_res

    @nvtx_decorator(message="HyperConnection::compute_mappings")
    def compute_mappings(self, x: Tensor) -> Tuple[Tensor, Tensor, Tensor]:
        """
        Compute mHC mappings from input hidden states.

        Reference: Eq. (5) and (8) in mHC paper

        Args:
            x: [s, b, n*C] - n-stream hidden states

        Returns:
            h_pre: [s, b, n] - aggregation weights (sigmoid activated)
            h_post: [s, b, n] - expansion weights (2*sigmoid activated)
            h_res: [s, b, n, n] - residual mixing matrix (doubly stochastic)
        """
        s, b, _ = x.shape
        with nvtx_range("HyperConnection::projection_and_get_norm"):
            proj, r = self._projection_and_get_norm(x)
        with nvtx_range("HyperConnection::compute_h"):
            h_pre, h_post, h_res = self._compute_h(proj, r)

        # Sinkhorn runs on fp32 h_res (already fp32 from _compute_h)
        h_res = h_res.view(s, b, self.n, self.n)
        h_res = torch.clamp(h_res, self.mhc_h_res_clamp_min, self.mhc_h_res_clamp_max)
        h_res = self._sinkhorn_op(
            h_res, self.sinkhorn_iterations, self.norm_eps
        ) # [s, b, n, n] fp32

        # 对齐 mindformers 非融合路径: h_pre/h_post/h_res 在返回前 cast 到
        # bf16 (对应 MF HyperConnectionModule.forward_func 末尾的
        # cast(..., self.dtype))。下游 aggregate/apply_h_res/apply_h_post
        # 中的 .to(dtype) 变为 no-op, 数值不变; 模块输出 dtype 与 MF 一致,
        # 便于 dump 逐层比对。fused (cuTile) 路径仍保持 fp32 返回。
        if not self.config.use_fused_mhc:
            out_dtype = x.dtype
            h_pre = h_pre.to(out_dtype)
            h_post = h_post.to(out_dtype)
            h_res = h_res.to(out_dtype)

        return h_pre, h_post, h_res

    @torch.compile
    def _apply_h_post(self, x: Tensor, h_post: Tensor) -> Tensor:
        """
        Core implementation of H_post application to a single tensor.

        Computes: H_post^T @ x

        Args:
            x: Input tensor, can be either:
               - [s, b, C] - standard hidden states
               - [C] - bias tensor (will be broadcast)
            h_post: [s, b, n] - expansion weights

        Returns:
            output: [s, b, n*C] - expanded tensor
        """
        n = self.n
        s, b, _ = h_post.shape

        if x.dim() == 1:
            # x is bias with shape [C], need to broadcast to [s, b, 1, C]
            C = x.shape[0]
            x_expanded = x.unsqueeze(0).unsqueeze(0).unsqueeze(0).expand(s, b, 1, C)
        else:
            # x is [s, b, C]
            C = x.shape[-1]
            x_expanded = x.unsqueeze(2)  # [s, b, 1, C]

        # Align with mindformers: cast h_post to x's dtype (bf16) for Mul,
        # matching mindformers HyperConnectionOutputCell computation.
        result = h_post.to(x_expanded.dtype).unsqueeze(-1) * x_expanded
        out_dtype = x.dtype if x.dim() > 1 else x_expanded.dtype
        return result.view(s, b, n * C).to(out_dtype)

    @nvtx_decorator(message="HyperConnection::apply_h_post")
    def apply_h_post(
        self,
        x_with_bias: Tuple[Tensor, Optional[Tensor]],
        h_post: Tensor,
        manager: Optional['CheckpointManager'] = None,
    ) -> Tuple[Tensor, Optional[Tensor]]:
        """
        Apply H_post to x and optionally bias, with optional checkpointing.

        This is the unified entry point that handles both normal execution
        and checkpoint-based execution for memory efficiency.

        Args:
            x_with_bias: Tuple of (x, bias) where:
                - x: [s, b, C] - hidden states
                - bias: [C] or None - optional bias tensor
            h_post: [s, b, n] - expansion weights
            manager: Optional CheckpointManager for checkpoint management.
                When provided, wraps _apply_h_post with CheckpointWithoutOutput.

        Returns:
            Tuple of (x_out, bias_out) where:
                - x_out: [s, b, n*C] - expanded hidden states
                - bias_out: [s, b, n*C] or None - expanded bias if input bias was not None
        """
        x, bias = x_with_bias

        if manager is not None:
            from megatron.core.tensor_parallel.random import CheckpointWithoutOutput

            # Checkpoint _apply_h_post to discard the output
            x_out = CheckpointWithoutOutput(ckpt_manager=manager).checkpoint(
                self._apply_h_post, x, h_post
            )

            # Checkpoint _apply_h_post for bias if not None
            if bias is not None:
                bias_out = CheckpointWithoutOutput(ckpt_manager=manager).checkpoint(
                    self._apply_h_post, bias, h_post
                )
            else:
                bias_out = None
        else:
            # Normal execution without checkpoint
            x_out = self._apply_h_post(x, h_post)
            bias_out = self._apply_h_post(bias, h_post) if bias is not None else None

        return x_out, bias_out

    def aggregate(self, x: Tensor, h_pre: Tensor) -> Tensor:
        """
        Aggregate n-stream to 1-stream.

        Args:
            x: [s, b, n*C] - n-stream hidden states
            h_pre: [s, b, n] - aggregation weights

        Returns:
            aggregated: [s, b, C] - single stream hidden states
        """
        s, b, _ = x.shape
        C = self.hidden_size
        x_streams = x.view(s, b, self.n, C)
        return self._h_aggregate_op(x_streams, h_pre)

    @torch.compile
    def apply_h_res(self, h_res: Tensor, residual: Tensor) -> Tensor:
        """
        Apply H_res to residual using H_res weights.

        Computes: H_res @ residual

        Args:
            h_res: [s, b, n, n] - residual mixing matrix
            residual: [s, b, n*C] - n-stream hidden states
        """
        s, b, _ = residual.shape
        n = self.n
        C = self.hidden_size

        # Align with mindformers: cast h_res to residual's dtype (bf16) and
        # use 4D BatchMatMul ([s,b,n,n] @ [s,b,n,C] → [s,b,n,C]), matching
        # mindformers res_mm (aclnn BatchMatMul). Avoid torch.bmm on 3D views
        # which may take a different NPU kernel path.
        h_res_bf16 = h_res.to(residual.dtype)                       # [s, b, n, n] bf16
        residual_4d = residual.view(s, b, n, C)                     # [s, b, n, C] bf16
        mixed = torch.matmul(h_res_bf16, residual_4d)               # [s, b, n, C] bf16

        return mixed.view(s, b, n * C).to(residual.dtype)

    def forward(
        self, hidden_states: Tensor, mhc_recompute_manager: Optional['CheckpointManager'] = None
    ) -> Tuple[Tensor, Tensor, Tensor]:
        """
        Full mHC forward pass.

        Args:
            hidden_states: [s, b, n*C] - n-stream hidden states
            mhc_recompute_manager: Optional CheckpointManager for checkpoint management.
                When provided, uses _forward_with_checkpoint for memory-efficient execution.

        Returns:
            aggregated: [s, b, C] - aggregated input for layer computation
            h_res: [s, b, n, n] - residual mixing matrix (for fused kernel)
            h_post: [s, b, n] - expansion weights
        """
        if mhc_recompute_manager is not None:
            return self._forward_with_checkpoint(hidden_states, mhc_recompute_manager)
        else:
            return self._forward_normal(hidden_states)

    def _forward_normal(self, hidden_states: Tensor) -> Tuple[Tensor, Tensor, Tensor]:
        """
        Normal forward pass without checkpointing.

        Args:
            hidden_states: [s, b, n*C] - n-stream hidden states

        Returns:
            aggregated: [s, b, C] - aggregated input for layer computation
            h_res: [s, b, n, n] - residual mixing matrix (for fused kernel)
            h_post: [s, b, n] - expansion weights
        """
        # Compute mappings
        h_pre, h_post, h_res = self.compute_mappings(hidden_states)

        # Aggregate for layer input
        with nvtx_range("HyperConnection::aggregate"):
            aggregated = self.aggregate(hidden_states, h_pre)

        return aggregated, h_res, h_post

    def _forward_with_checkpoint(
        self, hidden_states: Tensor, manager: 'CheckpointManager'
    ) -> Tuple[Tensor, Tensor, Tensor]:
        """
        Forward pass with checkpointing for memory efficiency.

        compute_mappings is called directly (not checkpointed) since its outputs
        (h_pre, h_post, h_res) are needed downstream. Only aggregate is wrapped with
        CheckpointWithoutOutput and auto-registered to the manager.
        apply_h_res is deferred to fused_h_res_h_post_bda for kernel fusion.

        Args:
            hidden_states: [s, b, n*C] - n-stream hidden states
            manager: CheckpointManager for unified recomputation

        Returns:
            aggregated: [s, b, C] - aggregated input for layer computation
            h_res: [s, b, n, n] - residual mixing matrix (for fused kernel)
            h_post: [s, b, n] - expansion weights
        """
        from megatron.core.tensor_parallel.random import CheckpointWithoutOutput

        h_pre, h_post, h_res = self.compute_mappings(hidden_states)

        # Checkpoint aggregate - auto-registers to manager
        aggregated = CheckpointWithoutOutput(ckpt_manager=manager).checkpoint(
            self.aggregate, hidden_states, h_pre
        )

        return aggregated, h_res, h_post

    # ==================== Block-level utilities ====================

    @staticmethod
    def input_expand(x: Tensor, n: int) -> Tensor:
        """
        Expand 1-stream to n-stream at TransformerBlock entry.

        Simple replication strategy: each stream initialized as a copy of input.

        Args:
            x: [s, b, C] - single stream hidden states
            n: Number of residual streams

        Returns:
            expanded: [s, b, n*C] - n-stream hidden states
        """
        s, b, C = x.shape
        # Replicate input to n streams
        expanded = x.unsqueeze(2).expand(s, b, n, C).contiguous()
        return expanded.view(s, b, n * C)

    @staticmethod
    def output_contract(x: Tensor, n: int) -> Tensor:
        """
        Contract n-stream to 1-stream at TransformerBlock exit.

        Simple averaging strategy: average all streams.

        Args:
            x: [s, b, n*C] - n-stream hidden states
            n: Number of residual streams

        Returns:
            contracted: [s, b, C] - single stream hidden states
        """
        s, b, nC = x.shape
        C = nC // n
        # Average all streams. PyTorch .mean on bf16 silently uses fp32
        # accumulation then truncates back to bf16, but mindformers MeanExt
        # accumulates in bf16 (pure bf16 reduction). To match mindformers,
        # do a pure bf16 reduction: sum (with bf16 accumulation) then div.
        x_streams = x.view(s, b, n, C)
        contracted = (x_streams.sum(dim=2) / n).to(x.dtype)
        return contracted

    # ==================== Fused kernel placeholder ====================

    @nvtx_decorator(message="HyperConnection::fused_h_res_h_post_bda")
    def fused_h_res_h_post_bda(
        self,
        h_res: Tensor,
        original_residual: Tensor,
        h_post: Tensor,
        layer_output_with_bias: Tuple[Tensor, Optional[Tensor]],
        dropout_prob: float,
        training: bool,
        fused: bool,
        manager: Optional['CheckpointManager'] = None,
    ) -> Tensor:
        """
        Fused kernel combining apply_h_res, apply_h_post and bias-dropout-add.

        This is a placeholder for future kernel fusion optimization.
        Currently implements the operations sequentially using native PyTorch.

        The computation flow is:
            1. mixed = H_res @ original_residual (apply_h_res)
            2. expanded = H_post^T @ layer_output (apply_h_post)
            3. output = dropout(expanded + bias) + mixed (bias-dropout-add)

        Args:
            h_res: [s, b, n, n] - residual mixing matrix
            original_residual: [s, b, n*C] - n-stream hidden states (before H_res applied)
            h_post: [s, b, n] - expansion weights
            layer_output_with_bias: Tuple of (x, bias) where:
                - x: [s, b, C] - layer output (attention or MLP output)
                - bias: [C] or None - optional bias tensor
            dropout_prob: Dropout probability
            training: Whether in training mode
            fused: Whether to use fused BDA implementation
            manager: Optional CheckpointManager for checkpoint management.
                When provided, each operation is wrapped with CheckpointWithoutOutput.

        Returns:
            output: [s, b, n*C] - final output after all operations
        """
        if manager is not None:
            return self._fused_h_res_h_post_bda_with_checkpoint(
                h_res,
                original_residual,
                h_post,
                layer_output_with_bias,
                dropout_prob,
                training,
                fused,
                manager,
            )
        else:
            return self._fused_h_res_h_post_bda_native(
                h_res,
                original_residual,
                h_post,
                layer_output_with_bias,
                dropout_prob,
                training,
                fused,
            )

    def _fused_h_res_h_post_bda_native(
        self,
        h_res: Tensor,
        original_residual: Tensor,
        h_post: Tensor,
        layer_output_with_bias: Tuple[Tensor, Optional[Tensor]],
        dropout_prob: float,
        training: bool,
        fused: bool,
    ) -> Tensor:
        """
        h_res, h_post and bda.

        When dropout is zero (or inference), uses a single fused/reference kernel
        for H_res @ residual + H_post * (x + bias). Falls back to unfused
        implementation when dropout is needed.

        Args:
            h_res: [s, b, n, n] - residual mixing matrix
            original_residual: [s, b, n*C] - n-stream hidden states
            h_post: [s, b, n] - expansion weights
            layer_output_with_bias: Tuple of (x, bias)
            dropout_prob: Dropout probability
            training: Whether in training mode
            fused: Whether to use fused BDA implementation

        Returns:
            output: [s, b, n*C] - final output
        """
        x, bias = layer_output_with_bias

        if dropout_prob == 0.0 or not training:
            s, b, _ = original_residual.shape
            n = self.n
            C = self.hidden_size
            orig_reshaped = original_residual.view(s, b, n, C)
            output = self._h_post_bda_op(h_res, orig_reshaped, h_post, x, bias)
            return output.view(s, b, n * C)

        from megatron.core.fusions.fused_bias_dropout import get_bias_dropout_add

        with nvtx_range("HyperConnection::apply_h_res"):
            mixed = self.apply_h_res(h_res, original_residual)
        with nvtx_range("HyperConnection::apply_h_post"):
            x_expanded = self._apply_h_post(x, h_post)
            bias_expanded = self._apply_h_post(bias, h_post) if bias is not None else None
        bda_func = get_bias_dropout_add(training, fused)
        with nvtx_range("HyperConnection::bda"):
            output = bda_func((x_expanded, bias_expanded), mixed, dropout_prob)
        return output

    @nvtx_decorator(message="HyperConnection::fused_h_res_h_post_bda_with_checkpoint")
    def _fused_h_res_h_post_bda_with_checkpoint(
        self,
        h_res: Tensor,
        original_residual: Tensor,
        h_post: Tensor,
        layer_output_with_bias: Tuple[Tensor, Optional[Tensor]],
        dropout_prob: float,
        training: bool,
        fused: bool,
        manager: 'CheckpointManager',
    ) -> Tensor:
        """
        Checkpointed variant of _fused_h_res_h_post_bda_native.

        Wraps compute in CheckpointWithoutOutput for activation memory savings.
        Cannot reuse _native directly because checkpoint requires all args to be
        positional Tensors; tuple/Optional/scalar args are unpacked or captured
        via closure instead.

        Args:
            h_res: [s, b, n, n] - residual mixing matrix
            original_residual: [s, b, n*C] - n-stream hidden states
            h_post: [s, b, n] - expansion weights
            layer_output_with_bias: Tuple of (x, bias)
            dropout_prob: Dropout probability
            training: Whether in training mode
            fused: Whether to use fused BDA implementation
            manager: CheckpointManager for checkpoint management

        Returns:
            output: [s, b, n*C] - final output
        """
        from megatron.core.tensor_parallel.random import CheckpointWithoutOutput

        x, bias = layer_output_with_bias
        n = self.n
        C = self.hidden_size

        # Fast path: no dropout — use fused/reference h_post_bda kernel (same as _native)
        if dropout_prob == 0.0 or not training:

            def _fused_wrapper(h_res, original_residual, h_post, x, *optional_bias):
                s, b, _ = original_residual.shape
                orig_reshaped = original_residual.view(s, b, n, C)
                b_arg = optional_bias[0] if optional_bias else None
                return self._h_post_bda_op(h_res, orig_reshaped, h_post, x, b_arg).view(s, b, n * C)

            ckpt = CheckpointWithoutOutput(ckpt_manager=manager)
            if bias is not None:
                output = ckpt.checkpoint(_fused_wrapper, h_res, original_residual, h_post, x, bias)
            else:
                output = ckpt.checkpoint(_fused_wrapper, h_res, original_residual, h_post, x)

        # Slow path: dropout required — fused kernel does not support dropout,
        # fall back to sequential apply_h_res + apply_h_post + bda
        else:
            from megatron.core.fusions.fused_bias_dropout import get_bias_dropout_add

            bda_func = get_bias_dropout_add(training, fused)
            has_bias = bias is not None

            def _native_wrapper(h_res, original_residual, h_post, x, *optional_bias):
                with nvtx_range("HyperConnection::apply_h_res"):
                    mixed = self.apply_h_res(h_res, original_residual)
                with nvtx_range("HyperConnection::apply_h_post"):
                    x_expanded = self._apply_h_post(x, h_post)
                    if has_bias:
                        bias_expanded = self._apply_h_post(optional_bias[0], h_post)
                    else:
                        bias_expanded = None
                with nvtx_range("HyperConnection::bda"):
                    output = bda_func((x_expanded, bias_expanded), mixed, dropout_prob)
                return output

            ckpt = CheckpointWithoutOutput(ckpt_manager=manager)
            if has_bias:
                output = ckpt.checkpoint(_native_wrapper, h_res, original_residual, h_post, x, bias)
            else:
                output = ckpt.checkpoint(_native_wrapper, h_res, original_residual, h_post, x)

        return output


# ==================== Checkpoint utilities for mHC ====================


class HyperConnectionCheckpoint:
    """
    Checkpoint utility for mHC intermediate activations.

    Implements the paper's "recomputing strategy" to reduce memory footprint
    by discarding intermediate n-stream activations and recomputing on-the-fly.
    """

    @staticmethod
    def compute_optimal_block_size(num_layers: int, num_streams: int) -> int:
        """
        Compute optimal recomputation block size.

        From paper Eq. (20): L_r^* ≈ sqrt(nL/(n+2))

        Args:
            num_layers: Total number of transformer layers
            num_streams: Number of residual streams (n)

        Returns:
            block_size: Optimal block size for checkpointing
        """
        block_size = int(math.sqrt(num_streams * num_layers / (num_streams + 2)))
        return max(1, block_size)