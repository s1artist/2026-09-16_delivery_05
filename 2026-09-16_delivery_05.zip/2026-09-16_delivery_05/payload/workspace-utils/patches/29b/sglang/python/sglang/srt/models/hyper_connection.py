"""
Manifold-Constrained Hyper-Connection Module (mHC).
"""
import logging
import os
from typing import Optional, Tuple

import torch
from torch import nn
from transformers import PretrainedConfig

logger = logging.getLogger(__name__)

if hasattr(torch, 'npu') and torch.npu.is_available():
    from sglang.srt.layers.mhc_npu_ops import MHCNpuOps as MHCOps
else:
    try:
        from sglang.srt.layers.mhc_cuda_ops import MHCCudaOps as MHCOps
    except ImportError:
        from sglang.srt.layers.mhc_npu_ops import MHCNpuOps as MHCOps


def _is_npu_device():
    return hasattr(torch, 'npu') and torch.npu.is_available()


_mhc_layer_counter = 0


class HyperConnectionModule(nn.Module):
    """
    Manifold-Constrained Hyper-Connection Module (mHC).
    Manages multiple residual streams and their interaction with transformer blocks.
    """
    def __init__(self, config: PretrainedConfig, device: Optional[torch.device] = None):
        super().__init__()
        global _mhc_layer_counter
        self.layer_id = _mhc_layer_counter
        _mhc_layer_counter += 1

        self.hidden_size = config.hidden_size
        self.n = getattr(config, "num_residual_streams", 4)
        self.sinkhorn_iterations = getattr(config, "mhc_sinkhorn_iterations", 20)

        self.output_contract_scaling = getattr(config, "mhc_output_contract_scaling", False)

        self.h_res_clamp_min = getattr(config, "mhc_h_res_clamp_min", -30.0)
        self.h_res_clamp_max = getattr(config, "mhc_h_res_clamp_max", 30.0)

        default_mode = "npu" if _is_npu_device() else "high"
        self.precision_mode = getattr(config, "mhc_precision_mode", default_mode)

        self._is_npu = _is_npu_device()

        if device is None:
            if self._is_npu and torch.npu.is_available():
                device = torch.device(f"npu:{torch.npu.current_device()}")
            else:
                device = torch.device('cpu')
                logger.info(f"[MHC_INIT] Layer {self.layer_id}: Defaulting to CPU, will be moved by model.to()")

        self._device = device

        self.mapping_proj = nn.Linear(
            self.n * self.hidden_size,
            self.n * self.n + 2 * self.n,
            bias=False,
            dtype=torch.float32
        ).to(device)
        init_alpha = getattr(config, "mhc_init_gating_factor", 0.01)
        self.alpha_pre = nn.Parameter(torch.tensor([init_alpha], dtype=torch.float32, device=device))
        self.alpha_post = nn.Parameter(torch.tensor([init_alpha], dtype=torch.float32, device=device))
        self.alpha_res = nn.Parameter(torch.tensor([init_alpha], dtype=torch.float32, device=device))

        self.bias = nn.Parameter(torch.zeros(2 * self.n + self.n * self.n, dtype=torch.float32, device=device))

        for name, param in self.named_parameters():
            logger.debug(f"  {name}: device={param.device}, dtype={param.dtype}")

        for name, param in self.named_parameters():
            if param.device != device:
                logger.warning(f"[MHC_INIT] WARNING: {name} on {param.device}, expected {device}")

        self._init_weights()

        self.cuda_ops = MHCOps()
        self.norm_linear_func = self.cuda_ops.norm_linear
        self.map_sigmoid_func = self.cuda_ops.map_sigmoid
        self.sinkhorn_func = self.cuda_ops.sinkhorn
        self.aggregate_func = self.cuda_ops.aggregate
        self.expand_merge_func = self.cuda_ops.expand_merge

    def _init_weights(self):
        nn.init.xavier_uniform_(self.mapping_proj.weight)
        nn.init.zeros_(self.bias)

    def compute_mappings(
        self,
        x: torch.Tensor
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        Compute mHC mappings from input hidden states using fused operations.

        Args:
            x: [bs, n, d]
        Returns:
            Tuple of (h_pre, h_post, h_res):
                - h_pre: [bs, n] - aggregation weights
                - h_post: [bs, n] - expansion weights
                - h_res: [bs, n, n] - residual mixing weights
        """

        bs, _, _ = x.shape

        if x.dtype != torch.float32:
            x = x.to(torch.float32)

        r, proj = self.norm_linear_func(x, self.mapping_proj.weight)

        h_pre, h_post, h_res = self.map_sigmoid_func(
            r,
            proj,
            self.bias,
            self.alpha_pre,
            self.alpha_post,
            self.alpha_res,
            self.n,
        )

        h_res = torch.clamp(h_res, min=self.h_res_clamp_min, max=self.h_res_clamp_max)
        h_res = self.sinkhorn_func(h_res, n_iters=self.sinkhorn_iterations)
        h_res = h_res.to(torch.bfloat16)

        return h_pre, h_post, h_res

    def forward_in(
        self,
        residuals: torch.Tensor
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        Phase 1: Aggregation (Pre-Mapping) using fused operations

        Args:
            residuals: [bs, n, dim]

        Returns:
            Tuple of (x_in, h_post, h_res):
                - x_in: [bs, dim] - aggregated input for layer
                - h_post: [bs, n] - expansion weights
                - h_res: [bs, n, n] - residual mixing weights
        """

        h_pre, h_post, h_res = self.compute_mappings(residuals)

        x_in = self.aggregate_func(residuals, h_pre, fp32_output=False)

        return x_in, h_post, h_res

    def forward_out(
        self,
        residuals: torch.Tensor,
        layer_output: torch.Tensor,
        h_post: torch.Tensor,
        h_res: torch.Tensor
    ) -> torch.Tensor:
        """
        Phase 2: Update (Post-Mapping & Residual-Mapping) using fused operations

        Args:
            residuals: [bs, n, dim]
            layer_output: [bs, dim]
            h_post: [bs, n] - from forward_in
            h_res: [bs, n, n] - from forward_in

        Returns:
            residuals_new: [bs, n, dim]
        """

        if self.precision_mode in ("high", "npu") and layer_output.dtype != torch.float32:
            layer_output = layer_output.to(torch.float32)

        fp32_output = (self.precision_mode in ("high", "npu"))
        residuals_new = self.expand_merge_func(residuals, layer_output, h_res, h_post, fp32_output=fp32_output)

        if self.precision_mode in ("high", "npu") and residuals_new.dtype != torch.float32:
            residuals_new = residuals_new.to(torch.float32)

        if self.precision_mode == "npu" and residuals_new.dtype == torch.float32:
            residuals_new = residuals_new.to(torch.bfloat16)

        return residuals_new

    @staticmethod
    def input_expand(x: torch.Tensor, n: int) -> torch.Tensor:
        """
        Expand 1-stream to n-stream at TransformerBlock entry.
        """
        bs, d = x.shape
        return x.unsqueeze(1).expand(bs, n, d).contiguous()

    def output_contract(self, x: torch.Tensor, n: int) -> torch.Tensor:
        """
        Contract n-stream to 1-stream at TransformerBlock exit.

        Args:
            x: [bs, n, d] - n-stream hidden states
            n: Number of residual streams

        Returns:
            contracted: [bs, d] - single stream hidden states
        """
        contracted = x.mean(dim=-2)

        if self.output_contract_scaling:
            contracted = contracted * (n ** 0.5)

        return contracted
