"""
MHC NPU Operators - Pure PyTorch Implementation for Ascend NPU

This module provides a pure PyTorch implementation of all MHC operators,
compatible with Huawei Ascend NPU and any PyTorch-supported backend.
"""
import math
import torch
import torch.nn as nn
from typing import Tuple

_HAS_TORCH_NPU = hasattr(torch, 'npu') and torch.npu.is_available()
if _HAS_TORCH_NPU:
    try:
        import torch_npu
        _HAS_NPU_BMM = hasattr(torch_npu, 'npu_bmmV2')
    except ImportError:
        _HAS_NPU_BMM = False
else:
    _HAS_NPU_BMM = False


class MHCNpuOps(nn.Module):
    """
    Pure PyTorch implementation of MHC operators for NPU/CPU/GPU.

    All operations use standard PyTorch functions, making them portable
    across different hardware backends including Huawei Ascend NPU.
    """

    def __init__(self):
        super().__init__()

    def _ensure_contiguous(self, *tensors):
        return [t.contiguous() if not t.is_contiguous() else t for t in tensors]

    def aggregate(
        self,
        residuals: torch.Tensor,
        h_pre: torch.Tensor,
        fp32_output: bool = False
    ) -> torch.Tensor:
        """
        Aggregate multiple residual streams into single output.

        Args:
            residuals: [M, n_streams, D] - residual streams (bf16/fp16/fp32)
            h_pre: [M, n_streams] - aggregation weights (fp32)
            fp32_output: bool - output FP32 tensor (matches vLLM precision)

        Returns:
            output: [M, D] - aggregated output
        """
        residuals, h_pre = self._ensure_contiguous(residuals, h_pre)

        M = residuals.size(0)
        n_streams = residuals.size(1)
        D = residuals.size(2)

        if M == 0:
            dtype = torch.float32 if fp32_output else residuals.dtype
            return torch.empty((0, D), dtype=dtype, device=residuals.device)

        if fp32_output:
            residuals_f = residuals.float()
            h_pre_f = h_pre.float()
            output = torch.einsum('mn,mnd->md', h_pre_f, residuals_f)
            return output
        else:
            residuals_bf16 = residuals.to(torch.bfloat16) if residuals.dtype != torch.bfloat16 else residuals
            h_pre_bf16 = h_pre.to(torch.bfloat16) if h_pre.dtype != torch.bfloat16 else h_pre
            output = torch.einsum('mn,mnd->md', h_pre_bf16, residuals_bf16)
            return output

    def sinkhorn(
        self,
        logits: torch.Tensor,
        n_iters: int = 20
    ) -> torch.Tensor:
        """
        Convert logits to doubly stochastic matrix via Sinkhorn algorithm.

        Args:
            logits: [M, N, N] - input logits (any dtype, converted to FP32)
            n_iters: number of iterations

        Returns:
            matrix: [M, N, N] - doubly stochastic matrix (fp32)
        """
        (logits,) = self._ensure_contiguous(logits)

        M = logits.size(0)
        N = logits.size(1)

        if M == 0:
            return torch.empty((0, N, N), dtype=torch.float32, device=logits.device)

        logits_fp32 = logits.float()

        logits_stable = logits_fp32 - logits_fp32.max(dim=-1, keepdim=True)[0]

        matrix = torch.exp(logits_stable)

        for i in range(n_iters):
            row_sum = matrix.sum(dim=-1, keepdim=True)
            matrix = matrix / row_sum.clamp(min=1e-6)

            col_sum = matrix.sum(dim=-2, keepdim=True)
            matrix = matrix / col_sum.clamp(min=1e-6)

        return matrix

    def expand_merge(
        self,
        residuals: torch.Tensor,
        layer_output: torch.Tensor,
        h_res: torch.Tensor,
        h_post: torch.Tensor,
        fp32_output: bool = False
    ) -> torch.Tensor:
        """
        Expand layer output to multiple streams and merge with residuals.

        Args:
            residuals: [M, n_streams, D] - residual streams
            layer_output: [M, D] - layer output
            h_res: [M, n_streams, n_streams] - residual mixing weights (fp32)
            h_post: [M, n_streams] - expansion weights (fp32)
            fp32_output: bool - output FP32 tensor

        Returns:
            output: [M, n_streams, D] - updated residual streams
        """
        residuals, layer_output, h_res, h_post = self._ensure_contiguous(
            residuals, layer_output, h_res, h_post
        )

        M = residuals.size(0)
        n_streams = residuals.size(1)
        D = residuals.size(2)

        if M == 0:
            dtype = torch.float32 if fp32_output else residuals.dtype
            return torch.empty((M, n_streams, D), dtype=dtype, device=residuals.device)

        residuals_f = residuals.float()
        layer_output_f = layer_output.float()
        h_res_f = h_res.float()
        h_post_f = h_post.float()

        expanded = h_post_f.unsqueeze(-1) * layer_output_f.unsqueeze(1)

        residual_mix = torch.einsum('mij,mjd->mid', h_res_f, residuals_f)

        output = expanded + residual_mix

        if fp32_output:
            result = output
        else:
            result = output.to(residuals.dtype)

        return result

    def map_sigmoid(
        self,
        r: torch.Tensor,
        proj: torch.Tensor,
        bias: torch.Tensor,
        alpha_pre: torch.Tensor,
        alpha_post: torch.Tensor,
        alpha_res: torch.Tensor,
        n_streams: int
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        Apply mapped sigmoid to compute h_pre, h_post, h_res.

        Args:
            r: [M, 1] - normalization factor
            proj: [M, 2*n + n*n] - projection output
            bias: [2*n + n*n] - bias terms
            alpha_pre: scalar or [1] - pre-mapping scale
            alpha_post: scalar or [1] - post-mapping scale
            alpha_res: scalar or [1] - res-mapping scale
            n_streams: number of streams

        Returns:
            h_pre: [M, n_streams] - aggregation weights (fp32)
            h_post: [M, n_streams] - expansion weights (fp32)
            h_res: [M, n_streams, n_streams] - residual mixing weights (fp32)
        """
        alpha_pre_exp = alpha_pre.expand(n_streams)
        alpha_post_exp = alpha_post.expand(n_streams)
        alpha_res_exp = alpha_res.expand(n_streams * n_streams)

        alpha = torch.cat([alpha_pre_exp, alpha_post_exp, alpha_res_exp], dim=-1)
        alpha = alpha.to(r.device).float().contiguous()

        bias = bias.float()
        r = r.float()
        proj = proj.float()

        r, proj, bias, alpha = self._ensure_contiguous(r, proj, bias, alpha)

        M = r.size(0)

        out_pre = torch.empty((M, n_streams), device=r.device, dtype=torch.float32)
        out_post = torch.empty((M, n_streams), device=r.device, dtype=torch.float32)
        out_res = torch.empty((M, n_streams, n_streams), device=r.device, dtype=torch.float32)

        if M == 0:
            return out_pre, out_post, out_res

        h = proj * alpha + bias

        out_pre = torch.sigmoid(h[:, :n_streams])

        out_post = torch.sigmoid(h[:, n_streams:2*n_streams]) * 2.0

        out_res = h[:, 2*n_streams:].view(M, n_streams, n_streams)

        return out_pre, out_post, out_res

    def norm_linear_fp32(
        self,
        x: torch.Tensor,
        weight: torch.Tensor
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Fused normalization and linear projection (FP32 precision).

        Args:
            x: [M, n_streams, D] or [M, D] - input
            weight: [N, D] - projection weight (fp32)

        Returns:
            r: [M, 1] - L2 norm factor (fp32)
            proj: [M, N] - projection output (fp32)
        """
        x, weight = self._ensure_contiguous(x, weight)

        x_flat = x.flatten(1)
        M = x_flat.size(0)
        D = x_flat.size(1)
        N = weight.size(0)

        if M == 0:
            r = torch.empty((0, 1), device=x.device, dtype=torch.float32)
            proj = torch.empty((0, N), device=x.device, dtype=torch.float32)
            return r, proj

        x_fp32 = x_flat.float()

        norm_eps = 1e-6
        variance = x_fp32.pow(2).mean(dim=-1, keepdim=True)
        r = 1.0 / torch.sqrt(variance + norm_eps)

        norm_x = r * x_fp32
        norm_x_bf16 = norm_x.to(torch.bfloat16)
        weight_bf16 = weight.to(torch.bfloat16)
        proj = torch.nn.functional.linear(norm_x_bf16, weight_bf16)
        proj = proj.float()

        return r, proj

    def norm_linear_bf16(
        self,
        x: torch.Tensor,
        weight: torch.Tensor
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Fused normalization and linear projection (BF16 precision).

        Args:
            x: [M, n_streams, D] or [M, D] - input (bf16)
            weight: [N, D] - projection weight (fp32 or bf16)

        Returns:
            r: [M, 1] - L2 norm factor (fp32)
            proj: [M, N] - projection output (fp32)
        """
        x = x.contiguous()
        x_flat = x.flatten(1)

        M = x_flat.size(0)
        D = x_flat.size(1)
        N = weight.size(0)

        if M == 0:
            r = torch.empty((0, 1), device=x.device, dtype=torch.float32)
            proj = torch.empty((0, N), device=x.device, dtype=torch.float32)
            return r, proj

        if weight.dtype == torch.float32:
            weight_fp32 = weight
        else:
            weight_fp32 = weight.float()

        if x_flat.dtype == torch.float32:
            x_fp32 = x_flat
        else:
            x_fp32 = x_flat.float()

        norm_eps = 1e-6
        variance = x_fp32.pow(2).mean(dim=-1, keepdim=True)
        r = 1.0 / torch.sqrt(variance + norm_eps)

        norm_x = r * x_fp32
        norm_x_bf16 = norm_x.to(torch.bfloat16)
        weight_bf16 = weight_fp32.to(torch.bfloat16)
        proj = torch.nn.functional.linear(norm_x_bf16, weight_bf16)
        proj = proj.float()

        return r, proj

    def norm_linear(
        self,
        x: torch.Tensor,
        weight: torch.Tensor
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Unified NormLinear operator.

        Args:
            x: [M, n_streams, D] or [M, D] - input
            weight: [N, D] - projection weight

        Returns:
            r: [M, 1] - L2 norm factor (fp32)
            proj: [M, N] - projection output (fp32)
        """
        r, proj = self.norm_linear_bf16(x, weight)

        return r, proj

    def reduce_finalize(
        self,
        sum_sq_x_split: torch.Tensor,
        K_val: float,
        eps: float = 1e-6
    ) -> torch.Tensor:
        """
        Reduce split-K results and compute final norm factor.

        Args:
            sum_sq_x_split: [num_splits, M] - sum of squares per split (fp32)
            K_val: float - dimension value
            eps: float - epsilon for numerical stability

        Returns:
            r_out: [M] - final norm factor (fp32)
        """
        sum_sq = sum_sq_x_split.sum(dim=0)
        r_out = torch.sqrt(sum_sq / K_val + eps)
        return r_out

    def forward(self, *args, **kwargs):
        raise NotImplementedError(
            "MHCNpuOps is a collection of operators. "
            "Call specific methods like .aggregate(), .sinkhorn(), etc."
        )


_global_ops = None

def _get_ops():
    global _global_ops
    if _global_ops is None:
        _global_ops = MHCNpuOps()
    return _global_ops


def mhc_npu_aggregate(residuals, h_pre, fp32_output=False):
    return _get_ops().aggregate(residuals, h_pre, fp32_output=fp32_output)


def mhc_npu_sinkhorn(logits, n_iters=20):
    return _get_ops().sinkhorn(logits, n_iters)


def mhc_npu_expand_merge(residuals, layer_output, h_res, h_post, fp32_output=False):
    return _get_ops().expand_merge(residuals, layer_output, h_res, h_post, fp32_output=fp32_output)


def mhc_npu_map_sigmoid(r, proj, bias, alpha_pre, alpha_post, alpha_res, n_streams):
    return _get_ops().map_sigmoid(r, proj, bias, alpha_pre, alpha_post, alpha_res, n_streams)


def mhc_npu_norm_linear_fp32(x, weight):
    return _get_ops().norm_linear_fp32(x, weight)


def mhc_npu_norm_linear_bf16(x, weight):
    return _get_ops().norm_linear_bf16(x, weight)


def mhc_npu_norm_linear(x, weight):
    return _get_ops().norm_linear(x, weight)
