#get the master ip
CUR_DIR=$(cd $(dirname $0);pwd)
filename="${CUR_DIR}/masterip-29b.bin"
sleep 5
while true; do
    if [ -f "$filename" ] && [ -s "$filename" ]; then
        MASTER_IP=$(cat "$filename")
        break
    fi
    sleep 1
done


interface=$(ifconfig -a | grep -B1 "$(hostname -i | awk '{print $1}')" | head -1 | awk '{print $1}' | tr -d ':')
export GLOO_SOCKET_IFNAME=$interface
export IP_SOCKET_IFNAME=$interface
export HCCL_SOCKET_IFNAME=$interface


export PYTHONBUFFERED=16
export ASCEND_RT_VISIBLE_DEVICES=0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15
export PYTORCH_NPU_ALLOC_CONF=expandable_segments:True
export CUDA_DEVICE_MAX_CONNECTIONS=1
export RAY_EXPERIMENTAL_NOSET_ASCEND_RT_VISIBLE_DEVICES=1
export HCCL_HOST_SOCKET_PORT_RANGE=60000-60050
export HCCL_NPU_SOCKET_PORT_RANGE=61000-61050
export HCCL_EXEC_TIMEOUT=3600
export HCCL_CONNECT_TIMEOUT=3600
export HYDRA_FULL_ERROR=1
export PYTORCH_NPU_ALLOC_CONF=expandable_segments:True


ulimit -n 65535 || true
unset http_proxy https_proxy HTTP_PROXY HTTPS_PROXY || true
unset LOCAL_RANK || true



ray start --address="${MASTER_IP}:6166" \
  --ray-debugger-external \
  --resources='{"NPU": 16}' \
  --ray-debugger-external \
  --min-worker-port=20000 \
  --max-worker-port=29999