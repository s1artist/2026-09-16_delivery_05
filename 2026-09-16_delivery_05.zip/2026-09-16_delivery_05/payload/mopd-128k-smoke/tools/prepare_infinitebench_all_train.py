#!/usr/bin/env python3
"""Build a balanced epoch from every eligible row of two InfiniteBench tasks.

No task context is generated, concatenated, padded, or truncated. Rows whose
native TeleChat prompt cannot leave the configured minimum response headroom
are recorded as objectively excluded.  The shorter domain and the final
partial balanced block are repeated only in the *sampling schedule* so every
optimizer batch remains domain-balanced; original prompts are never altered.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import math
import sys
from pathlib import Path
from typing import Any, Callable

# Some cluster Python launchers enable safe-path mode, which omits the script's
# directory from sys.path.  Resolve this sibling import explicitly while still
# keeping inherited/user PYTHONPATH disabled in the host wrapper.
TOOLS_DIR = Path(__file__).resolve().parent
if str(TOOLS_DIR) not in sys.path:
    sys.path.insert(0, str(TOOLS_DIR))

from prepare_infinitebench_128k import (
    DATASET_ID,
    DATASET_URL,
    OFFICIAL_PROMPT_COMMIT,
    OFFICIAL_SOURCE,
    attach_response_budget,
    code_debug_prompt,
    code_run_prompt,
    find_file,
    iter_jsonl,
    math_calc_prompt,
    math_find_prompt,
    sha256_file,
    write_jsonl,
)


def stable_order(source_id: str, seed: int) -> str:
    return hashlib.sha256(f"{seed}:{source_id}".encode()).hexdigest()


def collect_eligible(
    *,
    path: Path,
    task: str,
    domain: str,
    formatter: Callable,
    tokenizer,
    max_prompt_tokens: int,
    max_context_tokens: int,
    max_response_tokens: int,
    minimum_response_headroom: int,
    seed: int,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]]]:
    rows: list[dict[str, Any]] = []
    infos: list[dict[str, Any]] = []
    excluded: list[dict[str, Any]] = []
    seen_ids: set[str] = set()
    for raw in iter_jsonl(path):
        source_id = f"{task}:{raw.get('id')}"
        if source_id in seen_ids:
            raise RuntimeError(f"原始数据存在重复source ID：{source_id}")
        seen_ids.add(source_id)
        try:
            prompt, label = formatter(raw)
            # Match Slime Dataset: render once, then tokenize without extra
            # special tokens. The JSONL itself retains the unrendered prompt.
            rendered = tokenizer.apply_chat_template(
                [{"role": "user", "content": prompt}], tools=None,
                tokenize=False, add_generation_prompt=True,
            )
            prompt_tokens = len(tokenizer(rendered, add_special_tokens=False)["input_ids"])
        except Exception as exc:
            excluded.append({"source_id": source_id, "reason": "schema_or_tokenizer_error", "detail": str(exc)})
            continue
        available = max_context_tokens - prompt_tokens
        if prompt_tokens <= 0 or prompt_tokens > max_prompt_tokens or available < minimum_response_headroom:
            excluded.append(
                {
                    "source_id": source_id,
                    "reason": "native_prompt_outside_context_budget",
                    "prompt_tokens": prompt_tokens,
                    "required_max_prompt_tokens": max_prompt_tokens,
                    "available_response_tokens": available,
                    "required_response_headroom_tokens": minimum_response_headroom,
                }
            )
            continue
        prompt_digest = hashlib.sha256(prompt.encode("utf-8")).hexdigest()
        row = {
            "prompt": prompt,
            "label": label,
            "metadata": {
                "domain": domain,
                "mopd_domains": [domain],
                "source": "AI-ModelScope/InfiniteBench",
                "source_id": source_id,
                "task": task,
                "native_prompt_tokens_with_telechat_template": prompt_tokens,
                "prompt_sha256": prompt_digest,
                "official_prompt_template": "InfiniteBench.gpt4_templates",
                "dataset_revision": "v1",
                "benchmark_contaminated": True,
                "no_generated_padding_or_truncation": True,
            },
        }
        info = {
            "source_id": source_id,
            "task": task,
            "domain": domain,
            "prompt_tokens": prompt_tokens,
            "prompt_sha256": prompt_digest,
        }
        attach_response_budget(
            row,
            info,
            max_context_tokens=max_context_tokens,
            max_response_tokens=max_response_tokens,
            minimum_response_headroom=minimum_response_headroom,
        )
        rows.append(row)
        infos.append(info)
    ordered = sorted(zip(rows, infos), key=lambda pair: stable_order(pair[1]["source_id"], seed))
    return [item[0] for item in ordered], [item[1] for item in ordered], excluded


def make_balanced_epoch(
    math_rows: list[dict[str, Any]],
    code_rows: list[dict[str, Any]],
    *,
    batch_size: int,
) -> tuple[list[dict[str, Any]], dict[str, int]]:
    if not math_rows or not code_rows:
        raise RuntimeError(
            f"两领域都必须有合格样本：math={len(math_rows)}, code={len(code_rows)}；未生成训练数据"
        )
    if batch_size <= 0 or batch_size % 2:
        raise ValueError("batch_size必须是正偶数")
    per_domain = batch_size // 2
    target_per_domain = max(len(math_rows), len(code_rows))
    padded_per_domain = int(math.ceil(target_per_domain / per_domain) * per_domain)

    def schedule(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
        values = []
        occurrence: dict[str, int] = {}
        for index in range(padded_per_domain):
            value = copy.deepcopy(rows[index % len(rows)])
            source_id = value["metadata"]["source_id"]
            count = occurrence.get(source_id, 0)
            occurrence[source_id] = count + 1
            value["metadata"]["epoch_schedule_occurrence"] = count
            value["metadata"]["epoch_schedule_repeat"] = count > 0
            values.append(value)
        return values

    math_schedule = schedule(math_rows)
    code_schedule = schedule(code_rows)
    output: list[dict[str, Any]] = []
    for start in range(0, padded_per_domain, per_domain):
        output.extend(math_schedule[start : start + per_domain])
        output.extend(code_schedule[start : start + per_domain])
    return output, {
        "math_unique_rows": len(math_rows),
        "code_unique_rows": len(code_rows),
        "scheduled_rows_per_domain": padded_per_domain,
        "rows_per_epoch": len(output),
        "steps_per_epoch": len(output) // batch_size,
        "math_schedule_repeats": padded_per_domain - len(math_rows),
        "code_schedule_repeats": padded_per_domain - len(code_rows),
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--raw-root", required=True, type=Path)
    parser.add_argument("--output-root", required=True, type=Path)
    parser.add_argument("--tokenizer", required=True, type=Path)
    parser.add_argument("--math-task", choices=("math_find", "math_calc"), default="math_find")
    parser.add_argument("--code-task", choices=("code_run", "code_debug"), default="code_run")
    parser.add_argument("--batch-size", type=int, default=8)
    parser.add_argument("--max-prompt-tokens", type=int, default=126976)
    parser.add_argument("--minimum-response-headroom", type=int, default=4096)
    parser.add_argument("--max-response-tokens", type=int, default=32768)
    parser.add_argument("--max-context-tokens", type=int, default=131072)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()
    if args.batch_size <= 0 or args.batch_size % 2:
        parser.error("--batch-size必须是正偶数")
    if not 0 < args.minimum_response_headroom <= args.max_response_tokens:
        parser.error("response headroom无效")
    if args.max_prompt_tokens + args.minimum_response_headroom > args.max_context_tokens:
        parser.error("prompt上限没有保留要求的response余量")
    if not args.tokenizer.is_dir():
        parser.error(f"tokenizer目录不存在：{args.tokenizer}")
    return args


def main() -> int:
    args = parse_args()
    try:
        from transformers import AutoTokenizer
    except ImportError as exc:
        raise SystemExit("宿主机数据处理环境必须安装 transformers") from exc
    output_path = args.output_root / (
        f"mopd-{args.code_task.replace('_', '-')}-{args.math_task.replace('_', '-')}-all-train.jsonl"
    )
    if output_path.exists() or (args.output_root / "manifest.json").exists():
        raise FileExistsError(f"不覆盖已生成数据，请使用新输出目录：{args.output_root}")
    # Same loading defaults as slime.rollout.data_source.RolloutDataSource.
    tokenizer = AutoTokenizer.from_pretrained(str(args.tokenizer), trust_remote_code=True)
    formatters = {
        "math_find": math_find_prompt, "math_calc": math_calc_prompt,
        "code_run": code_run_prompt, "code_debug": code_debug_prompt,
    }
    source_specs = {
        domain: (find_file(args.raw_root, f"{task}.jsonl"), task, formatters[task])
        for domain, task in (("math", args.math_task), ("code", args.code_task))
    }
    collected: dict[str, list[dict[str, Any]]] = {}
    infos: dict[str, list[dict[str, Any]]] = {}
    excluded: dict[str, list[dict[str, Any]]] = {}
    for domain, (path, task, formatter) in source_specs.items():
        collected[domain], infos[domain], excluded[domain] = collect_eligible(
            path=path,
            task=task,
            domain=domain,
            formatter=formatter,
            tokenizer=tokenizer,
            max_prompt_tokens=args.max_prompt_tokens,
            max_context_tokens=args.max_context_tokens,
            max_response_tokens=args.max_response_tokens,
            minimum_response_headroom=args.minimum_response_headroom,
            seed=args.seed,
        )
    all_ids = [item["source_id"] for domain in ("math", "code") for item in infos[domain]]
    if len(all_ids) != len(set(all_ids)):
        raise RuntimeError("Math/Code合格池之间存在重复source ID")
    epoch_rows, schedule = make_balanced_epoch(
        collected["math"], collected["code"], batch_size=args.batch_size
    )
    args.output_root.mkdir(parents=True, exist_ok=True)
    write_jsonl(output_path, epoch_rows)
    manifest = {
        "schema_version": 1,
        "purpose": f"all_eligible_{args.code_task}_{args.math_task}_multiepoch_training",
        "source": {
            "provider": "ModelScope",
            "dataset_id": DATASET_ID,
            "dataset_url": DATASET_URL,
            "official_project": OFFICIAL_SOURCE,
            "official_prompt_commit": OFFICIAL_PROMPT_COMMIT,
            "revision": "v1",
            "tasks": [args.math_task, args.code_task],
        },
        "processing": {
            "generated_context": False,
            "concatenated_context": False,
            "padded_or_truncated_context": False,
            "all_eligible_rows_used": True,
            "deterministic_order_seed": args.seed,
            "batch_size": args.batch_size,
            "max_prompt_tokens": args.max_prompt_tokens,
            "minimum_response_headroom_tokens": args.minimum_response_headroom,
            "max_response_tokens": args.max_response_tokens,
            "max_context_tokens": args.max_context_tokens,
            "response_budget_policy": "min(global_response_cap, context_minus_prompt)",
            "response_budget_metadata_only": True,
            "tokenization": "Slime defaults: apply_chat_template then add_special_tokens=False",
        },
        "eligible": {
            domain: {
                "count": len(infos[domain]),
                "source_ids": [item["source_id"] for item in infos[domain]],
                "prompt_tokens_min": min(item["prompt_tokens"] for item in infos[domain]),
                "prompt_tokens_max": max(item["prompt_tokens"] for item in infos[domain]),
            }
            for domain in ("math", "code")
        },
        "excluded": {domain: values for domain, values in excluded.items()},
        "schedule": schedule,
        "raw_files": {
            domain: {"path": str(spec[0]), "sha256": sha256_file(spec[0])}
            for domain, spec in source_specs.items()
        },
        "output": {
            "path": str(output_path),
            "sha256": sha256_file(output_path),
            "rows_per_epoch": len(epoch_rows),
        },
        "benchmark_contaminated": True,
        "quality_interpretation": "training_dynamics_only_not_held_out_evaluation",
    }
    rendered = json.dumps(manifest, ensure_ascii=False, indent=2) + "\n"
    (args.output_root / "manifest.json").write_text(rendered, encoding="utf-8")
    # Keep the console summary short; detailed inclusion/exclusion is in manifest.json.
    print(json.dumps({
        "output": str(output_path), "schedule": schedule,
        "eligible": {domain: {k: v for k, v in value.items() if k != "source_ids"}
                     for domain, value in manifest["eligible"].items()},
        "excluded": {domain: len(values) for domain, values in excluded.items()},
    }, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
