#!/usr/bin/env python3
"""筛选原生长度 InfiniteBench 样本并映射为 Slime JSONL。

处理过程不生成、拼接、补齐或截断上下文。Prompt 使用 InfiniteBench 官方 GPT-4
模板，只执行 schema 映射、路由标注和 TeleChat chat template 后的精确长度筛选。
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
from pathlib import Path
from typing import Any, Iterator

DATASET_ID = "AI-ModelScope/InfiniteBench"
DATASET_URL = "https://modelscope.cn/datasets/AI-ModelScope/InfiniteBench"
OFFICIAL_SOURCE = "https://github.com/OpenBMB/InfiniteBench"
OFFICIAL_PROMPT_COMMIT = "51d9b37b0f1790ead936df2243abbf7f0420e439"

CODE_DEBUG_TEMPLATE = """There is ONLY ONE function in the large project that is deliberately made to include an obvious error. Please find the function that contains the most obvious errors. I will give you four options to narrow your scope. You can inspect the options and think. Eventually, tell me the answer using one single letter (A, B, C, or D).

{context}

Which funtion has deliberate error?
A. {OPTION_A}
B. {OPTION_B}
C. {OPTION_C}
D. {OPTION_D}

You should first find the functions in the options. Repeat their content, inspect through code, and at last give me your answer for the function that has the deliberate and obvious error in A, B, C, or D."""
MATH_CALC_TEMPLATE = "Compute the intermediate values in the following long expression.\n\n{context}"
CODE_RUN_TEMPLATE = """Following is a set of Python functions. There is a function called named {func}.

{context}

Please give me the exact number of the return value of {func_call}. Be concise. Your response must end with the final returned value."""
MATH_FIND_TEMPLATE = "{prefix}\n\n{context}\n\n{input}"


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def find_file(root: Path, name: str) -> Path:
    matches = [path for path in root.rglob(name) if path.is_file()]
    if len(matches) != 1:
        raise RuntimeError(f"预期在 {root} 下找到且只找到一个 {name}，实际为 {matches}")
    return matches[0]


def iter_jsonl(path: Path) -> Iterator[dict[str, Any]]:
    with path.open("r", encoding="utf-8") as stream:
        for line_number, line in enumerate(stream, 1):
            if not line.strip():
                continue
            value = json.loads(line)
            if not isinstance(value, dict):
                raise ValueError(f"{path}:{line_number}：预期 JSON object")
            yield value


def code_debug_prompt(row: dict[str, Any]) -> tuple[str, list[Any]]:
    options = row.get("options")
    answers = row.get("answer")
    if not isinstance(options, list) or len(options) != 4:
        raise ValueError(f"code_debug id={row.get('id')}: expected four options")
    if not isinstance(answers, list) or len(answers) != 1 or answers[0] not in options:
        raise ValueError(f"code_debug id={row.get('id')}: invalid answer/options")
    letter = "ABCD"[options.index(answers[0])]
    prompt = CODE_DEBUG_TEMPLATE.format(
        context=row["context"],
        OPTION_A=options[0],
        OPTION_B=options[1],
        OPTION_C=options[2],
        OPTION_D=options[3],
    )
    # Official InfiniteBench Code.Debug scorer expects [function_name, option_letter].
    return prompt, [answers[0], letter]


def math_calc_prompt(row: dict[str, Any]) -> tuple[str, list[Any]]:
    context = row.get("context")
    answers = row.get("answer")
    if not isinstance(context, str) or not context:
        raise ValueError(f"math_calc id={row.get('id')}: invalid context")
    if not isinstance(answers, list) or not answers:
        raise ValueError(f"math_calc id={row.get('id')}: invalid answer")
    return MATH_CALC_TEMPLATE.format(context=context), answers


def code_run_prompt(row: dict[str, Any]) -> tuple[str, list[Any]]:
    context = row.get("context")
    task_input = row.get("input")
    answers = row.get("answer")
    if not isinstance(context, str) or not context:
        raise ValueError(f"code_run id={row.get('id')}: invalid context")
    if not isinstance(task_input, str):
        raise ValueError(f"code_run id={row.get('id')}: invalid input")
    # This mirrors InfiniteBench src/eval_utils.py, including negative args.
    matches = re.findall(r"func_[0-9]+\(\-?[0-9]+\)", task_input)
    if not matches:
        raise ValueError(f"code_run id={row.get('id')}: function call not found")
    if not isinstance(answers, list) or not answers:
        raise ValueError(f"code_run id={row.get('id')}: invalid answer")
    func_call = matches[0]
    return CODE_RUN_TEMPLATE.format(
        func=func_call.split("(", 1)[0],
        func_call=func_call,
        context=context,
    ), answers


def math_find_prompt(row: dict[str, Any]) -> tuple[str, list[Any]]:
    context = row.get("context")
    task_input = row.get("input")
    answers = row.get("answer")
    if not isinstance(context, str) or not context:
        raise ValueError(f"math_find id={row.get('id')}: invalid context")
    if not isinstance(task_input, str):
        raise ValueError(f"math_find id={row.get('id')}: invalid input")
    matches = re.findall(r"The .+ of", task_input)
    if not matches:
        raise ValueError(f"math_find id={row.get('id')}: target number not found")
    if not isinstance(answers, list) or len(answers) != 1:
        raise ValueError(f"math_find id={row.get('id')}: expected one answer")
    target_number = matches[0].lower()[:-3]
    prefix = f"What is {target_number} in the following list?"
    return MATH_FIND_TEMPLATE.format(
        prefix=prefix,
        context=context,
        input=task_input,
    ), answers


def chat_token_count(tokenizer, prompt: str) -> int:
    value = tokenizer.apply_chat_template(
        [{"role": "user", "content": prompt}],
        tokenize=True,
        add_generation_prompt=True,
        return_dict=False,
    )
    if isinstance(value, dict):
        value = value["input_ids"]
    if hasattr(value, "tolist"):
        value = value.tolist()
    if value and isinstance(value[0], list):
        value = value[0]
    return len(value)


def select_native_sample(
    *,
    path: Path,
    task: str,
    domain: str,
    formatter,
    tokenizer,
    minimum: int,
    maximum: int,
    selection_offset: int,
) -> tuple[dict[str, Any], dict[str, Any]]:
    qualifying_seen = 0
    inspected = 0
    observed_min = None
    observed_max = None
    for row in iter_jsonl(path):
        inspected += 1
        prompt, label = formatter(row)
        token_count = chat_token_count(tokenizer, prompt)
        observed_min = token_count if observed_min is None else min(observed_min, token_count)
        observed_max = token_count if observed_max is None else max(observed_max, token_count)
        if not minimum <= token_count <= maximum:
            continue
        if qualifying_seen < selection_offset:
            qualifying_seen += 1
            continue
        source_id = f"{task}:{row.get('id')}"
        output = {
            "prompt": prompt,
            "label": label,
            "metadata": {
                "domain": domain,
                "mopd_domains": [domain],
                "source": "AI-ModelScope/InfiniteBench",
                "source_id": source_id,
                "task": task,
                "native_prompt_tokens_with_telechat_template": token_count,
                "official_prompt_template": "InfiniteBench.gpt4_templates",
                "dataset_revision": "v1",
                "benchmark_contaminated": True,
                "no_generated_padding_or_truncation": True,
            },
        }
        info = {
            "source_id": source_id,
            "task": task,
            "domain": domain,
            "prompt_tokens": token_count,
            "prompt_characters": len(prompt),
            "selection_offset": selection_offset,
            "inspected_rows": inspected,
        }
        return output, info
    raise RuntimeError(
        f"在 token 区间 [{minimum}, {maximum}] 中找不到 selection_offset={selection_offset} "
        f"对应的原生 {task} 样本；已检查={inspected}，实际范围=[{observed_min}, {observed_max}]。"
        "禁止补齐或截断；请调整允许的原生区间或选择其他公开任务。"
    )


def attach_response_budget(
    row: dict[str, Any],
    info: dict[str, Any],
    *,
    max_context_tokens: int,
    max_response_tokens: int,
    minimum_response_headroom: int,
) -> None:
    """记录单样本动态 response 上限，不修改 prompt 或答案。"""

    prompt_tokens = int(info["prompt_tokens"])
    available = max_context_tokens - prompt_tokens
    response_budget = min(max_response_tokens, available)
    if response_budget < minimum_response_headroom:
        raise RuntimeError(
            f"{info['source_id']} 的实际 prompt={prompt_tokens} 只剩 "
            f"{available} response tokens，小于要求的最小余量 "
            f"{minimum_response_headroom}；禁止截断 prompt。"
        )
    budget_fields = {
        "max_context_tokens": max_context_tokens,
        "global_max_response_tokens": max_response_tokens,
        "minimum_response_headroom_tokens": minimum_response_headroom,
        "max_response_tokens_with_context_budget": response_budget,
        "response_budget_policy": "min(global_response_cap, context_minus_prompt)",
    }
    row["metadata"].update(budget_fields)
    info.update(budget_fields)


def write_jsonl(path: Path, rows: list[dict[str, Any]]) -> None:
    temporary = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    with temporary.open("w", encoding="utf-8") as stream:
        for row in rows:
            stream.write(json.dumps(row, ensure_ascii=False) + "\n")
    os.replace(temporary, path)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--raw-root", required=True, type=Path)
    parser.add_argument("--output-root", required=True, type=Path)
    parser.add_argument("--tokenizer", required=True, type=Path)
    parser.add_argument("--min-code-prompt-tokens", type=int, default=93184)
    parser.add_argument("--min-math-prompt-tokens", type=int, default=53248)
    parser.add_argument(
        "--min-learning-prompt-tokens",
        type=int,
        default=1,
        help="Code.Run/Math.Find 学习和 probe 样本的最小原生 TeleChat prompt 长度。",
    )
    parser.add_argument(
        "--max-learning-prompt-tokens",
        type=int,
        default=126976,
        help="正常学习/probe prompt 上限；默认至少给 response 留出 4,096 tokens。",
    )
    parser.add_argument(
        "--learning-response-budget",
        type=int,
        default=4096,
        help="兼容参数：正常样本必须保留的最小 response 余量，不再是固定生成上限。",
    )
    parser.add_argument(
        "--max-response-tokens",
        type=int,
        default=32768,
        help="全局 response 上限；每条样本实际预算还会受 context-prompt 动态限制。",
    )
    parser.add_argument("--max-context-tokens", type=int, default=131072)
    parser.add_argument("--max-prompt-tokens", type=int, default=98304)
    parser.add_argument("--selection-offset", type=int, default=0)
    parser.add_argument(
        "--learning-pairs",
        type=int,
        default=0,
        help="额外生成指定数量且互不重复的 Math+Code 学习 pair。",
    )
    parser.add_argument(
        "--probe-pairs",
        type=int,
        default=0,
        help="额外生成指定数量且与学习集不重叠的固定 KL probe pair。",
    )
    parser.add_argument("--profile", choices=("grpo", "mopd", "all"), default="all")
    args = parser.parse_args()
    if not 0 < args.min_code_prompt_tokens <= args.max_prompt_tokens:
        parser.error("Code.Debug prompt token 区间无效")
    if not 0 < args.min_math_prompt_tokens <= args.max_prompt_tokens:
        parser.error("Math.Calc prompt token 区间无效")
    if not 0 < args.min_learning_prompt_tokens <= args.max_learning_prompt_tokens:
        parser.error("Code.Run/Math.Find prompt token 区间无效")
    if not 0 < args.learning_response_budget <= args.max_context_tokens:
        parser.error("正常学习/probe 的最小 response 余量无效")
    if not 0 < args.max_response_tokens <= args.max_context_tokens:
        parser.error("全局 response 上限无效")
    if args.max_prompt_tokens + args.max_response_tokens > args.max_context_tokens:
        parser.error("压力 profile 的 prompt 上限与 response 上限之和超过 context 上限")
    if args.max_learning_prompt_tokens + args.learning_response_budget > args.max_context_tokens:
        parser.error("正常学习/probe 的 prompt 上限未保留要求的最小 response 余量")
    if args.selection_offset < 0:
        parser.error("--selection-offset 不能为负数")
    if args.learning_pairs < 0 or args.probe_pairs < 0:
        parser.error("--learning-pairs 和 --probe-pairs 不能为负数")
    if args.profile == "grpo" and (args.learning_pairs or args.probe_pairs):
        parser.error("生成 learning/probe pair 时 --profile 必须为 mopd 或 all")
    if not args.tokenizer.is_dir():
        parser.error(f"tokenizer 目录不存在：{args.tokenizer}")

    try:
        from transformers import AutoTokenizer
    except ImportError as exc:
        raise SystemExit("宿主机数据处理环境必须安装 transformers") from exc
    tokenizer = AutoTokenizer.from_pretrained(
        str(args.tokenizer),
        trust_remote_code=True,
        use_fast=False,
    )

    code_path = find_file(args.raw_root, "code_debug.jsonl")
    code_row, code_info = select_native_sample(
        path=code_path,
        task="code_debug",
        domain="code",
        formatter=code_debug_prompt,
        tokenizer=tokenizer,
        minimum=args.min_code_prompt_tokens,
        maximum=args.max_prompt_tokens,
        selection_offset=args.selection_offset,
    )
    attach_response_budget(
        code_row,
        code_info,
        max_context_tokens=args.max_context_tokens,
        max_response_tokens=args.max_response_tokens,
        minimum_response_headroom=args.max_response_tokens,
    )
    math_path = None
    code_run_path = None
    math_find_path = None
    math_row = None
    math_info = None
    learning_rows: list[dict[str, Any]] = []
    learning_info: list[dict[str, Any]] = []
    probe_rows: list[dict[str, Any]] = []
    probe_info: list[dict[str, Any]] = []
    if args.profile in {"mopd", "all"}:
        math_path = find_file(args.raw_root, "math_calc.jsonl")
        math_row, math_info = select_native_sample(
            path=math_path,
            task="math_calc",
            domain="math",
            formatter=math_calc_prompt,
            tokenizer=tokenizer,
            minimum=args.min_math_prompt_tokens,
            maximum=args.max_prompt_tokens,
            selection_offset=args.selection_offset,
        )
        attach_response_budget(
            math_row,
            math_info,
            max_context_tokens=args.max_context_tokens,
            max_response_tokens=args.max_response_tokens,
            minimum_response_headroom=args.max_response_tokens,
        )

        # Code.Debug+Math.Calc are capacity/plumbing stress rows. The normal
        # short-answer learning/probe rows deliberately use Code.Run+Math.Find.
        # Different task IDs make stress disjoint; consecutive qualifying
        # offsets keep learning and probe mutually disjoint.
        if args.learning_pairs or args.probe_pairs:
            code_run_path = find_file(args.raw_root, "code_run.jsonl")
            math_find_path = find_file(args.raw_root, "math_find.jsonl")
        for destination_rows, destination_info, count, offset_start in (
            (
                learning_rows,
                learning_info,
                args.learning_pairs,
                args.selection_offset,
            ),
            (
                probe_rows,
                probe_info,
                args.probe_pairs,
                args.selection_offset + args.learning_pairs,
            ),
        ):
            for offset in range(offset_start, offset_start + count):
                assert math_find_path is not None and code_run_path is not None
                selected_math, selected_math_info = select_native_sample(
                    path=math_find_path,
                    task="math_find",
                    domain="math",
                    formatter=math_find_prompt,
                    tokenizer=tokenizer,
                    minimum=args.min_learning_prompt_tokens,
                    maximum=args.max_learning_prompt_tokens,
                    selection_offset=offset,
                )
                selected_code, selected_code_info = select_native_sample(
                    path=code_run_path,
                    task="code_run",
                    domain="code",
                    formatter=code_run_prompt,
                    tokenizer=tokenizer,
                    minimum=args.min_learning_prompt_tokens,
                    maximum=args.max_learning_prompt_tokens,
                    selection_offset=offset,
                )
                for selected_row, selected_info in (
                    (selected_math, selected_math_info),
                    (selected_code, selected_code_info),
                ):
                    attach_response_budget(
                        selected_row,
                        selected_info,
                        max_context_tokens=args.max_context_tokens,
                        max_response_tokens=args.max_response_tokens,
                        minimum_response_headroom=args.learning_response_budget,
                    )
                destination_rows.extend([selected_math, selected_code])
                destination_info.extend([selected_math_info, selected_code_info])

    all_infos = [value for value in [math_info, code_info, *learning_info, *probe_info] if value is not None]
    all_source_ids = [value["source_id"] for value in all_infos]
    if len(all_source_ids) != len(set(all_source_ids)):
        raise RuntimeError(f"stress、learning、probe 之间存在重复 source ID：{all_source_ids}")

    args.output_root.mkdir(parents=True, exist_ok=True)
    rl_path = args.output_root / "rl-code-debug-1.jsonl"
    mopd_path = args.output_root / "mopd-math-code-2.jsonl"
    learning_path = args.output_root / f"mopd-learning-{len(learning_rows)}.jsonl"
    probe_path = args.output_root / f"mopd-kl-probe-{len(probe_rows)}.jsonl"
    if args.profile in {"grpo", "all"}:
        write_jsonl(rl_path, [code_row])
    if args.profile in {"mopd", "all"}:
        assert math_row is not None
        write_jsonl(mopd_path, [math_row, code_row])
        if learning_rows:
            write_jsonl(learning_path, learning_rows)
        if probe_rows:
            write_jsonl(probe_path, probe_rows)
    manifest = {
        "schema_version": 3,
        "purpose": "native_open_source_128k_plumbing_smoke",
        "profile": args.profile,
        "source": {
            "provider": "ModelScope",
            "dataset_id": DATASET_ID,
            "dataset_url": DATASET_URL,
            "official_project": OFFICIAL_SOURCE,
            "official_prompt_commit": OFFICIAL_PROMPT_COMMIT,
            "revision": "v1",
            "license": "apache-2.0",
        },
        "processing": {
            "generated_context": False,
            "concatenated_context": False,
            "padded_context": False,
            "truncated_context": False,
            "schema_mapping_only": True,
            "official_prompt_template": "InfiniteBench.gpt4_templates",
            "tokenizer": str(args.tokenizer),
            "min_code_prompt_tokens": args.min_code_prompt_tokens,
            "min_math_prompt_tokens": args.min_math_prompt_tokens,
            "min_learning_prompt_tokens": args.min_learning_prompt_tokens,
            "max_learning_prompt_tokens": args.max_learning_prompt_tokens,
            "minimum_learning_response_headroom": args.learning_response_budget,
            "learning_response_budget": args.learning_response_budget,
            "global_max_response_tokens": args.max_response_tokens,
            "response_budget_policy": "min(global_response_cap, context_minus_prompt)",
            "max_context_tokens": args.max_context_tokens,
            "max_prompt_tokens": args.max_prompt_tokens,
            "selection_offset": args.selection_offset,
            "learning_pairs": args.learning_pairs,
            "probe_pairs": args.probe_pairs,
            "note": (
                "压力通道使用近 96K Code.Debug 和原生 Math.Calc，并允许最多 32K response。"
                f"正常 learning/probe 使用 Code.Run+Math.Find，prompt 上限 "
                f"{args.max_learning_prompt_tokens:,}，至少保留 "
                f"{args.learning_response_budget:,} response tokens；每条实际上限为 "
                f"min({args.max_response_tokens:,}, {args.max_context_tokens:,}-实际prompt)。"
                "模型可通过 EOS 提前结束；没有生成、拼接、补齐或截断任何任务上下文。"
            ),
        },
        "selected": {"rl": code_info} if args.profile == "grpo" else {
            "stress": {"math": math_info, "code": code_info},
            "learning": learning_info,
            "kl_probe": probe_info,
            **({"rl": code_info} if args.profile == "all" else {}),
        },
        "split_source_ids": {
            "stress": [value["source_id"] for value in [math_info, code_info] if value is not None],
            "learning": [value["source_id"] for value in learning_info],
            "kl_probe": [value["source_id"] for value in probe_info],
        },
        "raw_files": {
            "code_debug": {"path": str(code_path), "sha256": sha256_file(code_path)},
            **(
                {"math_calc": {"path": str(math_path), "sha256": sha256_file(math_path)}}
                if math_path is not None
                else {}
            ),
            **(
                {"code_run": {"path": str(code_run_path), "sha256": sha256_file(code_run_path)}}
                if code_run_path is not None
                else {}
            ),
            **(
                {"math_find": {"path": str(math_find_path), "sha256": sha256_file(math_find_path)}}
                if math_find_path is not None
                else {}
            ),
        },
        "outputs": {
            **(
                {"rl": {"path": str(rl_path), "sha256": sha256_file(rl_path), "rows": 1}}
                if args.profile in {"grpo", "all"}
                else {}
            ),
            **(
                {"mopd": {"path": str(mopd_path), "sha256": sha256_file(mopd_path), "rows": 2}}
                if args.profile in {"mopd", "all"}
                else {}
            ),
            **(
                {"learning": {"path": str(learning_path), "sha256": sha256_file(learning_path), "rows": len(learning_rows)}}
                if learning_rows
                else {}
            ),
            **(
                {"kl_probe": {"path": str(probe_path), "sha256": sha256_file(probe_path), "rows": len(probe_rows)}}
                if probe_rows
                else {}
            ),
        },
        "benchmark_contaminated": True,
        "formal_training_checkpoint_eligible": False,
    }
    manifest_path = args.output_root / f"manifest-{args.profile}.json"
    rendered_manifest = json.dumps(manifest, ensure_ascii=False, indent=2) + "\n"
    manifest_path.write_text(rendered_manifest, encoding="utf-8")
    (args.output_root / "manifest.json").write_text(rendered_manifest, encoding="utf-8")
    print(json.dumps(manifest, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
