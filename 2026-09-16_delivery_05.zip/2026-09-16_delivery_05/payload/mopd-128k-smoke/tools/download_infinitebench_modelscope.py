#!/usr/bin/env python3
"""从 ModelScope 下载 128K 压力和学习流程使用的四个 InfiniteBench 任务。"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
import time
from pathlib import Path

DATASET_ID = "AI-ModelScope/InfiniteBench"
FILES = (
    "code_debug.jsonl",
    "math_calc.jsonl",
    "code_run.jsonl",
    "math_find.jsonl",
)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def patch_python310_hub_config() -> None:
    try:
        from modelscope_hub.config import HubConfig
    except ImportError:
        return
    if getattr(HubConfig, "_mopd_128k_slots_compat", False):
        return
    original = HubConfig.__post_init__

    def wrapped(self):
        for name, value in (("_logged_out", False), ("_endpoint_overridden", False)):
            try:
                getattr(self, name)
            except AttributeError:
                object.__setattr__(self, name, value)
        return original(self)

    HubConfig.__post_init__ = wrapped
    HubConfig._mopd_128k_slots_compat = True


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-root", required=True, type=Path)
    parser.add_argument("--revision", default="v1")
    parser.add_argument("--retries", type=int, default=3)
    parser.add_argument("--files", nargs="+", choices=FILES, default=list(FILES))
    parser.add_argument("--token", default=os.environ.get("MODELSCOPE_API_TOKEN"))
    args = parser.parse_args()
    if args.retries < 1:
        parser.error("--retries must be positive")

    patch_python310_hub_config()
    try:
        from modelscope.hub.file_download import dataset_file_download
    except ImportError as exc:
        raise SystemExit(
            "找不到 ModelScope SDK。请使用宿主机专用的数据处理 uv Python。"
        ) from exc

    args.output_root.mkdir(parents=True, exist_ok=True)
    records = []
    for file_name in args.files:
        last_error = None
        downloaded = None
        for attempt in range(1, args.retries + 1):
            try:
                downloaded = dataset_file_download(
                    DATASET_ID,
                    file_name,
                    revision=args.revision,
                    local_dir=str(args.output_root),
                    token=args.token,
                )
                last_error = None
                break
            except Exception as exc:  # ModelScope transports expose several exception types.
                last_error = exc
                print(f"[下载] {file_name} 第 {attempt}/{args.retries} 次尝试失败：{exc}", file=sys.stderr)
                if attempt < args.retries:
                    time.sleep(10 * attempt)
        if last_error is not None or downloaded is None:
            raise RuntimeError(f"无法从 ModelScope 下载 {file_name}") from last_error
        path = Path(downloaded)
        if not path.is_file():
            candidate = args.output_root / file_name
            if candidate.is_file():
                path = candidate
            else:
                raise FileNotFoundError(f"ModelScope 返回的路径不存在：{downloaded}")
        with path.open("rb") as stream:
            head = stream.read(80)
        if head.startswith(b"version https://git-lfs.github.com/spec"):
            raise RuntimeError(f"下载结果是 LFS 指针而不是真实数据：{path}")
        record = {
            "path": str(path.resolve()),
            "size": path.stat().st_size,
            "sha256": sha256_file(path),
        }
        records.append(record)
        print(f"[下载] PASS {file_name}：{record['size']} 字节")

    manifest = {
        "schema_version": 1,
        "source": "modelscope",
        "dataset_id": DATASET_ID,
        "dataset_url": "https://modelscope.cn/datasets/AI-ModelScope/InfiniteBench",
        "revision": args.revision,
        "license": "apache-2.0",
        "created_at_unix": int(time.time()),
        "python_executable": sys.executable,
        "files": records,
    }
    manifest_path = args.output_root / "download-manifest.json"
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"[下载] manifest：{manifest_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
