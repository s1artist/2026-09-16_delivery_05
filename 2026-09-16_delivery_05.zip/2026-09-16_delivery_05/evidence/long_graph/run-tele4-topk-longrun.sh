#!/usr/bin/env bash
# 配置、快照、提交和日志；不检查环境，不执行安装。
set -euo pipefail

# ── 路径 ────────────────────────────────────────────────────────────
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
SCRIPT_PATH="${SCRIPT_DIR}/$(basename -- "${BASH_SOURCE[0]}")"
SLIME_ROOT=/workspace/slime-ascend
STUDENT_HF=/hpfs/huawei/songchunjiang/weights_hf/12.05T_wodsa_256k_gbs8_id11_stage3_1000_hf
STUDENT=/hpfs/huawei/songchunjiang/models/mopd-torch-dist/student
MATH_TEACHER=/hpfs/huawei/songchunjiang/models/mopd-torch-dist/math_teacher
CODE_TEACHER=/hpfs/huawei/songchunjiang/models/mopd-torch-dist/code_teacher
PROMPT_DATA=/hpfs/huawei/songchunjiang/datasets/mopd-all-code-math-train/mopd-code-run-math-find-all-train.jsonl
DATA_MANIFEST=/hpfs/huawei/songchunjiang/datasets/mopd-all-code-math-train/manifest.json
EXPERIMENT_ROOT=/hpfs/huawei/songchunjiang/experiments
CHECKPOINT_ROOT=/hpfs/huawei/songchunjiang/models/mopd-longrun
RAY_ADDRESS="http://${HCCL_IF_IP}:8265"

# ── 实验名称与输出 ──────────────────────────────────────────────────
DAY=$(date +%F)
STAMP=$(date +%H%M%S)
JOB_ID="mopd-topk-${DAY}-${STAMP}"
EXPERIMENT_DIR="${EXPERIMENT_ROOT}/${DAY}_topk_longrun_${STAMP}"
CHECKPOINT_DIR="${CHECKPOINT_ROOT}/${JOB_ID}"
SUBMIT_LOG="${EXPERIMENT_DIR}/submit.log"
TRAIN_LOG="${EXPERIMENT_DIR}/train.log"

# ── 训练、采样与诊断参数 ────────────────────────────────────────────
TRAIN_NPU=16
ROLLOUT_NPU=8
TP=4
CP=4
EP=8
NUM_ROLLOUT=300
SAVE_INTERVAL=100
KL_INTERVAL=10                         # 第 1、2 次更新也记录同批 KL
BATCH_SIZE=8
MICRO_BATCH_SIZE=1
CONTEXT_LEN=131072
PROMPT_LEN=126976
RESPONSE_LEN=32768
TEMPERATURE=0.6
TOP_K=1024
LOSS_CHUNK=512
LR=1e-6

# ── 模型：复用原配置，不在启动脚本复制架构参数 ──────────────────────
MODEL_ARGS_NUM_LAYERS=40
source "${SLIME_ROOT}/scripts/models/telechat4-29B-Moe.sh"

# ── Checkpoint ─────────────────────────────────────────────────────
CHECKPOINT_ARGS=(
    --hf-checkpoint "${STUDENT_HF}"
    --load "${STUDENT}"
    --finetune
    --no-load-optim
    --no-load-rng
    --save "${CHECKPOINT_DIR}"
    --save-interval "${SAVE_INTERVAL}"
)

# ── 数据与 rollout：使用固定数据，保存每轮样本供内容核查 ────────────
ROLLOUT_ARGS=(
    --prompt-data "${PROMPT_DATA}"
    --input-key prompt
    --apply-chat-template
    --rm-type zero
    --start-rollout-id 0
    --num-rollout "${NUM_ROLLOUT}"
    --rollout-batch-size "${BATCH_SIZE}"
    --n-samples-per-prompt 1
    --global-batch-size "${BATCH_SIZE}"
    --micro-batch-size "${MICRO_BATCH_SIZE}"
    --rollout-max-context-len "${CONTEXT_LEN}"
    --rollout-max-prompt-len "${PROMPT_LEN}"
    --rollout-max-response-len "${RESPONSE_LEN}"
    --rollout-temperature "${TEMPERATURE}"
    --balance-data
    --custom-generate-function-path mopd_longrun_runtime.generate_with_context_budget
    --save-debug-rollout-data "${EXPERIMENT_DIR}/rollout-dumps/rollout-{rollout_id}.pt"
)

# ── MOPD ────────────────────────────────────────────────────────────
MOPD_ARGS=(
    --advantage-estimator grpo
    --use-mopd
    --mopd-teacher-mode megatron
    --mopd-distill-type top_k
    --mopd-teachers '[{"name":"math_teacher","domain":"math"},{"name":"code_teacher","domain":"code"}]'
    --mopd-teacher-loads "${MATH_TEACHER}" "${CODE_TEACHER}"
    --mopd-alpha 0.0
    --mopd-eps-low 0.2
    --mopd-eps-high 5.0
    --mopd-sampling-logprobs-key rollout_log_probs
    --entropy-coef 0.0
    --eps-clip 0.2
    --eps-clip-high 0.28
    --mopd-topk-k "${TOP_K}"
    --mopd-loss-chunk-size "${LOSS_CHUNK}"
)

# ── 并行与重计算 ────────────────────────────────────────────────────
PARALLEL_ARGS=(
    --actor-num-nodes 1
    --actor-num-gpus-per-node "${TRAIN_NPU}"
    --num-gpus-per-node 16
    --rollout-num-gpus "${ROLLOUT_NPU}"
    --rollout-num-gpus-per-engine "${ROLLOUT_NPU}"
    --seq-length "${CONTEXT_LEN}"
    --tensor-model-parallel-size "${TP}"
    --sequence-parallel
    --pipeline-model-parallel-size 1
    --context-parallel-size "${CP}"
    --context-parallel-algo megatron_cp_algo
    --expert-model-parallel-size "${EP}"
    --expert-tensor-parallel-size 1
    --recompute-granularity full
    --recompute-method uniform
    --recompute-num-layers 1
    --use-dynamic-batch-size
    --max-tokens-per-gpu 32768
    --no-gradient-accumulation-fusion
)

# ── 优化器 ──────────────────────────────────────────────────────────
OPTIMIZER_ARGS=(
    --optimizer adam
    --lr "${LR}"
    --lr-decay-style constant
    --weight-decay 0.0
    --adam-beta1 0.9
    --adam-beta2 0.98
    --optimizer-cpu-offload
    --overlap-cpu-optimizer-d2h-h2d
    --use-precision-aware-optimizer
)

# ── SGLang ──────────────────────────────────────────────────────────
SGLANG_ARGS=(
    --sglang-context-length "${CONTEXT_LEN}"
    --sglang-mem-fraction-static 0.65
    --sglang-enable-dp-attention
    --sglang-dp-size 8
    --sglang-enable-dp-lm-head
    --sglang-moe-dense-tp-size 1
    --sglang-cuda-graph-bs 1 2 3 4 8 16
    --sglang-max-running-requests 8
    --sglang-disable-radix-cache
    --sglang-chunked-prefill-size 8192
    --sglang-max-prefill-tokens 8192
    --sglang-device npu
    --sglang-log-level debug
    --sglang-enable-fp32-lm-head
)

# ── 精度与蒸馏设置：在 MODEL_ARGS 之后显式覆盖模型脚本的辅助损失默认值 ─
MISC_ARGS=(
    --moe-router-bias-update-rate 0
    --moe-aux-loss-coeff 0.0
    --attention-dropout 0.0
    --hidden-dropout 0.0
    --bf16
    --accumulate-allreduce-grads-in-fp32
    --attention-softmax-in-fp32
    --no-masked-softmax-fusion
    --no-rope-fusion
    --no-cross-entropy-loss-fusion
    --attention-backend flash
    --custom-megatron-init-path mopd_longrun_runtime.init_actor
)

TRAIN_COMMAND=(
    python3 -u "${SLIME_ROOT}/train.py"
    "${MODEL_ARGS[@]}"
    "${CHECKPOINT_ARGS[@]}"
    "${ROLLOUT_ARGS[@]}"
    "${MOPD_ARGS[@]}"
    "${PARALLEL_ARGS[@]}"
    "${OPTIMIZER_ARGS[@]}"
    "${SGLANG_ARGS[@]}"
    "${MISC_ARGS[@]}"
)

# ── 作业运行配置：IP/网卡沿用各节点原环境 ────────────────────────────
# 采样模块从本次独立发布目录导入；已用于实验的发布目录不可覆盖。
RUNTIME_ENV_JSON="$(cat <<JSON
{
  "env_vars": {
    "PYTHONPATH": "${SCRIPT_DIR}:/workspace/slime-ascend:/workspace/mbridge:/workspace/Megatron-Bridge/src:/workspace/Megatron-LM:/workspace/MegatronAdaptor:/workspace/sglang/python",
    "MOPD_EXP_DIR": "${EXPERIMENT_DIR}",
    "MOPD_KL_INTERVAL": "${KL_INTERVAL}",
    "PYTHONUNBUFFERED": "1",
    "PYTHONDONTWRITEBYTECODE": "1",
    "PYTHONOPTIMIZE": "0",
    "RAY_DEDUP_LOGS": "0",
    "RAY_EXPERIMENTAL_NOSET_ASCEND_RT_VISIBLE_DEVICES": "1",
    "CUDA_DEVICE_MAX_CONNECTIONS": "1",
    "PYTORCH_NPU_ALLOC_CONF": "expandable_segments:True",
    "HCCL_HOST_SOCKET_PORT_RANGE": "60000-60050",
    "HCCL_NPU_SOCKET_PORT_RANGE": "61000-61050",
    "HCCL_CONNECT_TIMEOUT": "3600",
    "HCCL_EXEC_TIMEOUT": "3600",
    "HYDRA_FULL_ERROR": "1",
    "HF_HOME": "/workspace/mopd-cache/hf",
    "HF_MODULES_CACHE": "/workspace/mopd-cache/hf/modules",
    "TORCHINDUCTOR_CACHE_DIR": "/workspace/mopd-cache/inductor",
    "ASCEND_USE_FIA": "true"
  }
}
JSON
)"

# ── 实验记录：主脚本、两份日志、复现包及 rollout 样本 ────────────────
mkdir -p "${EXPERIMENT_ROOT}"
mkdir "${EXPERIMENT_DIR}"
cp "${SCRIPT_PATH}" "${EXPERIMENT_DIR}/run.sh"
printf 'JOB_ID=%s\nEXPERIMENT_DIR=%s\nCHECKPOINT_DIR=%s\n训练日志：%s\n' \
    "${JOB_ID}" "${EXPERIMENT_DIR}" "${CHECKPOINT_DIR}" "${TRAIN_LOG}" | tee "${SUBMIT_LOG}"
printf 'TRAIN_COMMAND: ' >> "${SUBMIT_LOG}"
printf '%q ' "${TRAIN_COMMAND[@]}" >> "${SUBMIT_LOG}"
printf '\nRUNTIME_ENV: %s\n' "${RUNTIME_ENV_JSON}" >> "${SUBMIT_LOG}"

# 仅打包必要版本材料，不复制整个安装包/大数据；不是安装或环境检查。
INSTALL_LOG_DIR="$(</workspace/mopd-install-log-dir.txt)"
tar -czf "${EXPERIMENT_DIR}/reproduce.tar.gz" \
    -C "${SCRIPT_DIR}" mopd_longrun_runtime.py \
    -C "${SLIME_ROOT}" scripts/models/telechat4-29B-Moe.sh \
    -C /workspace/mopd-adaptation BUNDLE.json CANDIDATE_MANIFEST.json source-overlay-files.tsv source-overlay deployment/environment-patches \
    -C "$(dirname -- "${DATA_MANIFEST}")" "$(basename -- "${DATA_MANIFEST}")" \
    -C "$(dirname -- "${INSTALL_LOG_DIR}")" "$(basename -- "${INSTALL_LOG_DIR}")"

cd "${SLIME_ROOT}"
ray job submit \
    --address "${RAY_ADDRESS}" \
    --submission-id "${JOB_ID}" \
    --no-wait \
    --runtime-env-json "${RUNTIME_ENV_JSON}" \
    -- "${TRAIN_COMMAND[@]}" 2>&1 | tee -a "${SUBMIT_LOG}"
nohup ray job logs \
    --address "${RAY_ADDRESS}" \
    -f \
    "${JOB_ID}" >> "${TRAIN_LOG}" 2>&1 < /dev/null &
printf '提交成功，JOB_ID=%s\ntail -F %s\n' "${JOB_ID}" "${TRAIN_LOG}"
