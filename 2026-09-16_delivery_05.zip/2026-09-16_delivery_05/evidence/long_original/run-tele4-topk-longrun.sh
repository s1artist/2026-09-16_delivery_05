#!/usr/bin/env bash
# 已安装 MOPD 的当前容器直接运行；不检查环境，不执行安装或 Git 操作。
set -euo pipefail

# ── 路径 ────────────────────────────────────────────────────────────
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
SCRIPT_PATH="${SCRIPT_DIR}/$(basename -- "${BASH_SOURCE[0]}")"
SLIME_ROOT=/workspace/slime-ascend
STUDENT_HF=/hpfs/huawei/songchunjiang/weights_hf/12.05T_wodsa_256k_gbs8_id11_stage3_1000_hf
STUDENT=/hpfs/huawei/songchunjiang/models/mopd-torch-dist/student
MATH_TEACHER=/hpfs/huawei/songchunjiang/models/mopd-torch-dist/math_teacher
CODE_TEACHER=/hpfs/huawei/songchunjiang/models/mopd-torch-dist/code_teacher
PROMPT_DATA=/hpfs/huawei/songchunjiang/datasets/mopd-all-code-math-train/mopd-code-run-math-find-all-train.jsonl
DATA_MANIFEST=/hpfs/huawei/songchunjiang/datasets/mopd-all-code-math-train/manifest.json
EXPERIMENT_ROOT=/hpfs/huawei/songchunjiang/experiments
RAY_ADDRESS="http://${HCCL_IF_IP}:8265"

# ── 实验名称与日志 ──────────────────────────────────────────────────
DAY=$(date +%F)
STAMP=$(date +%H%M%S)
EXPERIMENT_DIR="${EXPERIMENT_ROOT}/${DAY}_topk_longrun_${STAMP}"
JOB_ID="mopd-topk-${DAY}-${STAMP}"
SUBMIT_LOG="${EXPERIMENT_DIR}/ray-submit.log"
TRAIN_LOG="${EXPERIMENT_DIR}/train.log"

# ── 训练、采样与诊断参数 ────────────────────────────────────────────
TRAIN_NPU=16
ROLLOUT_NPU=8
TP=4
CP=4
EP=8
NUM_ROLLOUT=300
SAVE_INTERVAL=100
KL_INTERVAL=10                         # 同一次长跑，第 1、2 次更新也记录同批 KL
BATCH_SIZE=8
MICRO_BATCH_SIZE=1
CONTEXT_LEN=131072
PROMPT_LEN=126976
RESPONSE_LEN=32768
TEMPERATURE=0.6
TOP_K=1024
LOSS_CHUNK=512
LR=1e-6

# ── TeleChat-29B：40 层，前 2 层 Dense，后 38 层 MoE ────────────────
MODEL_ARGS=(
    --disable-bias-linear --num-layers 40 --hidden-size 3584 --ffn-hidden-size 9216
    --num-attention-heads 32 --num-query-groups 32 --max-position-embeddings 262144
    --use-rotary-position-embeddings --rotary-scaling-factor 64 --mscale-all-dim 1.0
    --rotary-base 10000 --rotary-percent 1.0 --vocab-size 131072
    --qk-head-dim 128 --v-head-dim 128 --qk-pos-emb-head-dim 64
    --normalization RMSNorm --norm-epsilon 1e-6 --swiglu --untie-embeddings-and-output-weights
    --multi-latent-attention --q-lora-rank 768 --kv-lora-rank 512 --qk-layernorm
    --num-experts 64
    --moe-layer-freq '[0,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]'
    --moe-ffn-hidden-size 1024 --moe-router-topk 4 --moe-router-pre-softmax
    --moe-router-score-function sigmoid --moe-router-group-topk 1 --moe-router-num-groups 1
    --moe-router-topk-scaling-factor 2.0 --moe-router-enable-expert-bias
    --moe-router-bias-update-rate 0 --moe-router-dtype fp32
    --moe-router-load-balancing-type seq_aux_loss --moe-aux-loss-coeff 0.0
    --moe-shared-expert-intermediate-size 1024 --moe-grouped-gemm --moe-token-dispatcher-type alltoall
    --enable-hyper-connections --num-residual-streams 4 --mhc-sinkhorn-iterations 20
)

# ── Student / Teacher checkpoint ──────────────────────────────────
CHECKPOINT_ARGS=(
    --hf-checkpoint "${STUDENT_HF}" --load "${STUDENT}"
    --finetune --no-load-optim --no-load-rng
    --save "${EXPERIMENT_DIR}/checkpoints" --save-interval "${SAVE_INTERVAL}"
)

# ── 数据与 rollout ─────────────────────────────────────────────────
ROLLOUT_ARGS=(
    --prompt-data "${EXPERIMENT_DIR}/prompt-data.jsonl" --input-key prompt --apply-chat-template --rm-type zero
    --start-rollout-id 0 --num-rollout "${NUM_ROLLOUT}" --rollout-batch-size "${BATCH_SIZE}"
    --n-samples-per-prompt 1 --global-batch-size "${BATCH_SIZE}" --micro-batch-size "${MICRO_BATCH_SIZE}"
    --rollout-max-context-len "${CONTEXT_LEN}" --rollout-max-prompt-len "${PROMPT_LEN}"
    --rollout-max-response-len "${RESPONSE_LEN}" --rollout-temperature "${TEMPERATURE}" --balance-data
    --custom-generate-function-path mopd_longrun_runtime.generate_with_context_budget
    --save-debug-rollout-data "${EXPERIMENT_DIR}/rollout-dumps/rollout-{rollout_id}.pt"
)

# ── MOPD：纯蒸馏，保持原 Top-k / IS / tail 口径 ─────────────────────
MOPD_ARGS=(
    --advantage-estimator grpo --use-mopd --mopd-teacher-mode megatron --mopd-distill-type top_k
    --mopd-teachers '[{"name":"math_teacher","domain":"math"},{"name":"code_teacher","domain":"code"}]'
    --mopd-teacher-loads "${MATH_TEACHER}" "${CODE_TEACHER}"
    --mopd-alpha 0.0 --mopd-eps-low 0.2 --mopd-eps-high 5.0
    --mopd-sampling-logprobs-key rollout_log_probs --entropy-coef 0.0 --eps-clip 0.2 --eps-clip-high 0.28
    --mopd-topk-k "${TOP_K}" --mopd-loss-chunk-size "${LOSS_CHUNK}"
)

# ── 并行与重计算 ────────────────────────────────────────────────────
PARALLEL_ARGS=(
    --actor-num-nodes 1 --actor-num-gpus-per-node "${TRAIN_NPU}" --num-gpus-per-node 16
    --rollout-num-gpus "${ROLLOUT_NPU}" --rollout-num-gpus-per-engine "${ROLLOUT_NPU}"
    --seq-length "${CONTEXT_LEN}" --tensor-model-parallel-size "${TP}" --sequence-parallel
    --pipeline-model-parallel-size 1 --context-parallel-size "${CP}" --context-parallel-algo megatron_cp_algo
    --expert-model-parallel-size "${EP}" --expert-tensor-parallel-size 1
    --recompute-granularity full --recompute-method uniform --recompute-num-layers 1
    --use-dynamic-batch-size --max-tokens-per-gpu 32768 --no-gradient-accumulation-fusion
)

# ── 优化器 ──────────────────────────────────────────────────────────
OPTIMIZER_ARGS=(
    --optimizer adam --lr "${LR}" --lr-decay-style constant --weight-decay 0.0
    --adam-beta1 0.9 --adam-beta2 0.98
    --optimizer-cpu-offload --overlap-cpu-optimizer-d2h-h2d --use-precision-aware-optimizer
)

# ── SGLang：8 卡、单引擎 ────────────────────────────────────────────
SGLANG_ARGS=(
    --sglang-context-length "${CONTEXT_LEN}" --sglang-mem-fraction-static 0.65
    --sglang-enable-dp-attention --sglang-dp-size 8 --sglang-enable-dp-lm-head --sglang-moe-dense-tp-size 1
    --sglang-disable-cuda-graph --sglang-cuda-graph-max-bs 16 --sglang-max-running-requests 8
    --sglang-disable-radix-cache --sglang-chunked-prefill-size 8192 --sglang-max-prefill-tokens 8192
    --sglang-device npu --sglang-log-level debug --sglang-enable-fp32-lm-head
)

# ── 精度及运行时 KL/显存记录（不是环境预检）──────────────────────────
MISC_ARGS=(
    --attention-dropout 0.0 --hidden-dropout 0.0 --bf16 --accumulate-allreduce-grads-in-fp32
    --attention-softmax-in-fp32 --no-masked-softmax-fusion --no-rope-fusion --no-cross-entropy-loss-fusion
    --attention-backend flash --custom-megatron-init-path mopd_longrun_runtime.init_actor
)

TRAIN_COMMAND=(
    python3 -u "${SLIME_ROOT}/train.py"
    "${MODEL_ARGS[@]}" "${CHECKPOINT_ARGS[@]}" "${ROLLOUT_ARGS[@]}" "${MOPD_ARGS[@]}"
    "${PARALLEL_ARGS[@]}" "${OPTIMIZER_ARGS[@]}" "${SGLANG_ARGS[@]}" "${MISC_ARGS[@]}"
)

# ── 作业运行配置：节点 IP/网卡沿用原 Ray 环境，不广播主节点网卡 ──────
RUNTIME_ENV_JSON="$(cat <<JSON
{
  "env_vars": {
    "PYTHONPATH": "${EXPERIMENT_DIR}/runtime:/workspace/slime-ascend:/workspace/mbridge:/workspace/Megatron-Bridge/src:/workspace/Megatron-LM:/workspace/MegatronAdaptor:/workspace/sglang/python",
    "MOPD_EXP_DIR": "${EXPERIMENT_DIR}", "MOPD_KL_INTERVAL": "${KL_INTERVAL}",
    "PYTHONUNBUFFERED": "1", "PYTHONDONTWRITEBYTECODE": "1", "PYTHONOPTIMIZE": "0",
    "RAY_DEDUP_LOGS": "0", "RAY_EXPERIMENTAL_NOSET_ASCEND_RT_VISIBLE_DEVICES": "1",
    "CUDA_DEVICE_MAX_CONNECTIONS": "1", "PYTORCH_NPU_ALLOC_CONF": "expandable_segments:True",
    "HCCL_HOST_SOCKET_PORT_RANGE": "60000-60050", "HCCL_NPU_SOCKET_PORT_RANGE": "61000-61050",
    "HCCL_CONNECT_TIMEOUT": "3600", "HCCL_EXEC_TIMEOUT": "3600", "HYDRA_FULL_ERROR": "1",
    "HF_HOME": "/workspace/mopd-cache/hf", "HF_MODULES_CACHE": "/workspace/mopd-cache/hf/modules",
    "TORCHINDUCTOR_CACHE_DIR": "/workspace/mopd-cache/inductor"
  }
}
JSON
)"

# ── 保存快照、直接提交、记录日志 ────────────────────────────────────
mkdir -p "${EXPERIMENT_ROOT}"
mkdir "${EXPERIMENT_DIR}"
mkdir "${EXPERIMENT_DIR}/runtime" "${EXPERIMENT_DIR}/ranks" "${EXPERIMENT_DIR}/rollout-dumps"
cp "${SCRIPT_PATH}" "${EXPERIMENT_DIR}/run-tele4-topk-longrun.sh"
cp "${SCRIPT_DIR}/mopd_longrun_runtime.py" "${EXPERIMENT_DIR}/runtime/mopd_longrun_runtime.py"
cp "${PROMPT_DATA}" "${EXPERIMENT_DIR}/prompt-data.jsonl"
cp "${DATA_MANIFEST}" "${EXPERIMENT_DIR}/dataset-manifest.json"
cp -r /workspace/mopd-adaptation "${EXPERIMENT_DIR}/installed-package-snapshot"
printf '%s\n' "${RUNTIME_ENV_JSON}" > "${EXPERIMENT_DIR}/runtime-env.json"
printf '%q ' "${TRAIN_COMMAND[@]}" > "${EXPERIMENT_DIR}/command.sh"
printf '\n' >> "${EXPERIMENT_DIR}/command.sh"
printf 'JOB_ID=%s\nRAY_ADDRESS=%s\nEXPERIMENT_DIR=%s\n' "${JOB_ID}" "${RAY_ADDRESS}" "${EXPERIMENT_DIR}" > "${EXPERIMENT_DIR}/job.txt"

printf 'EXPERIMENT_DIR=%s\n提交日志：%s\n训练日志：%s\n' "${EXPERIMENT_DIR}" "${SUBMIT_LOG}" "${TRAIN_LOG}"
cd "${SLIME_ROOT}"
ray job submit --address "${RAY_ADDRESS}" --submission-id "${JOB_ID}" --no-wait \
    --runtime-env-json "${RUNTIME_ENV_JSON}" -- "${TRAIN_COMMAND[@]}" > "${SUBMIT_LOG}" 2>&1
nohup ray job logs --address "${RAY_ADDRESS}" -f "${JOB_ID}" > "${TRAIN_LOG}" 2>&1 < /dev/null &
printf '已提交：%s\ntail -F %s\n' "${JOB_ID}" "${TRAIN_LOG}"