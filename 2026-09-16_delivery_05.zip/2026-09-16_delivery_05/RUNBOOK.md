**Telechat 29B 多教师 top-k MOPD 端到端运行流程**

版本：delivery_05，2026-09-16。按首次执行顺序：**解压 → 数据准备 → 容器/Ray → 三份 HF 转 Megatron → 短训练 → 长训练 → checkpoint 转 HF → 流式推理 → 绘图**。两个训练入口独立，均为 **300 步、每 20 步保存**；历史实测见 [TEST_REPORT.md](TEST_REPORT.md)。

本次共享目录是 `/hpfs/huawei/songchunjiang/mopd-delivery-05`，使用新容器作业名。三份初始 HF 权重直接读取原目录。基础镜像、集群权限、共享挂载及私有 HF 权重需已就绪；安装包包含原环境补丁、9 个框架覆盖文件、Emerging-Optimizers、适配源码和既有运行工具。

**1. 宿主机：放置材料**

```bash
BASE=/hpfs/huawei/songchunjiang/mopd-delivery-05
mkdir -p "$BASE/packages"
```

将 `mopd-delivery-05.tar.gz` 上传到上述 `packages/`，首次执行：

```bash
tar -xzf "$BASE/packages/mopd-delivery-05.tar.gz" -C "$BASE/packages"
DELIVERY="$BASE/packages/mopd-delivery-05"
cp -r "$DELIVERY/payload/." "$BASE/"
```

```text
mopd-delivery-05/
  packages/                 # 安装包、RUNBOOK.md、TEST_REPORT.md
  scripts/29b-patch/         # 容器安装入口
  workspace-utils/          # 原环境准备和框架补丁
  Emerging-Optimizers/       # 原环境准备需要的优化器源码
  mopd-adaptation/           # 适配源码、独立脚本、短数据工具和流式请求
  mopd-128k-smoke/tools/     # 沿用的长数据下载、转换工具
  k8s_job/29b-grpo-mult-nodes/ # 指定 YAML 和 Ray 启动脚本
  datasets/                 # 原始数据与训练 JSONL
  venvs/                    # 宿主机数据环境
  models/                   # Megatron 模型、checkpoint、导出 HF
  experiments/              # 训练和推理输出
```

以下步骤在首次准备的新目录执行；已运行的实验不覆盖。重跑只改对应脚本顶部的 `EXPERIMENT_NAME`，失败的转换也使用新输出目录。

**2. 宿主机：数据环境和短数据**

没有 uv 时先按 [uv 官方安装方式](https://docs.astral.sh/uv/getting-started/installation/) 安装一次：

```bash
curl -LsSf https://astral.sh/uv/install.sh | sh
source "$HOME/.local/bin/env"
```

建立独立数据环境。宿主机需要访问 Python、依赖和数据下载源；训练容器继续使用镜像内环境。[uv 环境说明](https://docs.astral.sh/uv/pip/environments/)

```bash
BASE=/hpfs/huawei/songchunjiang/mopd-delivery-05
PKG="$BASE/mopd-adaptation"
DATA_ENV="$BASE/venvs/mopd-data-05"
uv venv --python 3.11 "$DATA_ENV"
uv pip install --index-url https://pypi.tuna.tsinghua.edu.cn/simple --python "$DATA_ENV/bin/python" -r "$PKG/requirements-host-data.txt"
uv pip install --index-url https://pypi.tuna.tsinghua.edu.cn/simple --python "$DATA_ENV/bin/python" jinja2
DATA_PY="$DATA_ENV/bin/python"
STUDENT_HF=/hpfs/huawei/songchunjiang/weights_hf/12.05T_wodsa_256k_gbs8_id11_stage3_1000_hf
```

沿用历史实验的固定提交：GSM8K train 和 MBPP train（ID 601–974）。GitHub 是此次使用的发布方来源；换成 HF/ModelScope 时要核对版本、划分及字段，不能只换地址就当作同一数据集。

```bash
RAW="$BASE/datasets/mopd-short-raw-05"
mkdir -p "$BASE/datasets"
mkdir "$RAW"
cp "$PKG/data/short-sources/"* "$RAW/"
curl --fail --location --output "$RAW/gsm8k-train.jsonl" \
  https://raw.githubusercontent.com/openai/grade-school-math/3101c7d5072418e28b9008a6636bde82a006892c/grade_school_math/data/train.jsonl
curl --fail --location --output "$RAW/mbpp.jsonl" \
  https://raw.githubusercontent.com/google-research/google-research/f46ca8374b4cddef97ca4208ad986049d74d296a/mbpp/mbpp.jsonl

"$DATA_PY" -B "$PKG/tools/short_prompt/prepare_data.py" \
  --raw-dir "$RAW" --tokenizer "$STUDENT_HF" \
  --out "$BASE/datasets/mopd-short-prompt-05" \
  --template-kwargs '{"enable_thinking":true}' \
  --max-prompt-tokens 98304 --max-response-tokens 32768 \
  --context-tokens 131072 --num-rollouts 100 --seed 42
```

成品为 `datasets/mopd-short-prompt-05/train.jsonl`：每批 4 math＋4 code，共 800 行。`--num-rollouts 100` 只让这个数据工具生成 100 组输入，**不限制训练步数**。本次仍使用该数据计划，300 步训练循环使用 3 个数据 epoch；代码题存在组批重复，800 行不代表 800 道独立题。

`--template-kwargs` 用于按训练模板测量输入长度，工具同时测量开/关思考并按较长者过滤。JSONL 中仍保存原始 prompt；训练时只应用一次模板。短训练脚本保留 `enable_thinking=true`。参考答案、参考代码放在 `label`，不加入输入；MBPP 的三条测试属于题目内容。

**3. 宿主机：全量合格长数据**

使用已跑通的 **InfiniteBench Math.Calc＋Code.Debug**。扫描两份原始文件的全部题目，保留模板后输入 ≤98304 tokens 的完整原题；不裁剪、填充或拼接题目。旧 Math.Find＋Code.Run 的 800 行在同一 96K 过滤下全部被排除，本流程不使用那份成品。

```bash
BASE=/hpfs/huawei/songchunjiang/mopd-delivery-05
DATA_PY="$BASE/venvs/mopd-data-05/bin/python"
STUDENT_HF=/hpfs/huawei/songchunjiang/weights_hf/12.05T_wodsa_256k_gbs8_id11_stage3_1000_hf
LONG_TOOLS="$BASE/mopd-128k-smoke/tools"
LONG_RAW="$BASE/datasets/infinitebench-capacity-raw-01"
LONG_DATA="$BASE/datasets/mopd-math-calc-code-debug-all-01"

"$DATA_PY" -B "$LONG_TOOLS/download_infinitebench_modelscope.py" \
  --output-root "$LONG_RAW" --revision v1 \
  --files math_calc.jsonl code_debug.jsonl

"$DATA_PY" -B "$LONG_TOOLS/prepare_infinitebench_all_train.py" \
  --raw-root "$LONG_RAW" --output-root "$LONG_DATA" \
  --tokenizer "$STUDENT_HF" \
  --math-task math_calc --code-task code_debug --batch-size 8 \
  --max-prompt-tokens 98304 --minimum-response-headroom 32768 \
  --max-response-tokens 32768 --max-context-tokens 131072 --seed 42
```

9 月 16 日按上述配置得到的结果如下；新执行以自己的转换摘要为准：

| 领域 | 合格独立题 | 模板后输入 tokens | 组批行数 | 组批重复行 | 排除题数 |
|---|---:|---:|---:|---:|---:|
| math | 50 | 54016–54295 | 52 | 2 | 0 |
| code | 17 | 96214–97747 | 52 | 35 | 377 |
| 合计 | **67** | — | **104** | **37** | **377** |

每批 4 math＋4 code，104 行构成 13 步的数据 epoch。较少领域循环使用以保持组批比例；所有合格独立题都进入成品。训练脚本直接指向下列文件，300 步继续循环该数据：

```bash
wc -l "$LONG_DATA/mopd-code-debug-math-calc-all-train.jsonl"
```

已测相同来源和 tokenizer 的输出为 104 行，且运行者确认已完成两步全量长跑。任一领域筛选为空时转换器直接报错，不会生成可用训练文件。

`--minimum-response-headroom 32768` 检查上下文是否还容得下 32K 输出；`--max-response-tokens 32768` 用于数据预算记录。它们不要求模型必须输出 32K，也不在数据处理中生成答案。实际生成上限由训练脚本的 `--rollout-max-response-len 32768` 控制。输入 96K＋输出 32K＝128K，沿用已运行配置，无自动调整输出预算的钩子。看到“没有 PyTorch/TensorFlow/Flax，只能使用 tokenizer”的提示可继续，此步骤不加载模型做推理。

成品字段示例：

```json
{"prompt":"原始题目文本","label":"参考答案","metadata":{"domain":"math","mopd_domains":["math"]}}
```

`domain` 供数据分类和统计；`mopd_domains` 指定参与蒸馏的教师。当前训练路由读取后者，缺失时会选择全部教师，不会从 `domain` 自动推导，因此沿用两个字段。`mopd-128k-smoke/tools` 只是现有工具位置，不另启 smoke 作业。

**4. 执行机：启动容器；Master：确认 Ray 资源**

沿用指定的 `mopd-128k-new-pr-3epoch.yaml`，本版仅更新共享路径和作业名，镜像及硬件配置保持不变：

```bash
sudo kubectl apply -f /hpfs/huawei/songchunjiang/mopd-delivery-05/k8s_job/29b-grpo-mult-nodes/mopd-128k-new-pr-3epoch.yaml
sudo kubectl exec -it schj-mopd-acceptance-05-master-0 -n lql -- bash
```

镜像为 `harbor.telecom-ai.com.cn/library/slime-ascend:v0.3.0-0818-nettools`。Master、Worker 各 16 张 NPU，进入 Master 后执行：

```bash
ray status
```

应有 **2 个 Active 节点、总计 32 NPU**，无 Pending 节点和 Recent failures；首次空闲时显示 `0.0/32.0 NPU`。数量与配置一致、资源空闲后再转换或训练；Worker 未加入时先等待。

**5. Master 容器：初始 HF 转 Megatron**

三份初始 HF 直接使用原共享路径，不复制。转换脚本沿用原 `convert-student-29b.sh` 的简短写法，一次转换一份模型。编辑 `/workspace/mopd-adaptation/scripts/convert-tele4-mopd-models.sh` 顶部的 `HF_CHECKPOINT` 和 `SAVE_DIR`：

| 模型 | `HF_CHECKPOINT` | `SAVE_DIR` |
|---|---|---|
| Student，脚本默认值 | `/hpfs/huawei/songchunjiang/weights_hf/12.05T_wodsa_256k_gbs8_id11_stage3_1000_hf` | `/hpfs/huawei/songchunjiang/mopd-delivery-05/models/mopd-torch-dist/student` |
| Math teacher | `/hpfs/huawei/songchunjiang/weights_hf/12.05T_wodsa_128K_16_xiongss260806_exp2_260807_5000_hf_math` | `/hpfs/huawei/songchunjiang/mopd-delivery-05/models/mopd-torch-dist/math_teacher` |
| Code teacher | `/hpfs/huawei/songchunjiang/weights_hf/12.05T_128K_zhangyh260729_group2_260730_1000_hf` | `/hpfs/huawei/songchunjiang/mopd-delivery-05/models/mopd-torch-dist/code_teacher` |

每次填好两行后执行，三份依次完成，不同时转换：

```bash
bash /workspace/mopd-adaptation/scripts/convert-tele4-mopd-models.sh
```

命令正常结束后，用实际 `SAVE_DIR` 检查标记。以下以 code teacher 为例，Student 和 math teacher 同样检查：

```bash
MODEL_DIR=/hpfs/huawei/songchunjiang/mopd-delivery-05/models/mopd-torch-dist/code_teacher
grep -nx 'release' "$MODEL_DIR/latest_checkpointed_iteration.txt"
```

预期 `1:release`；文件不存在或没有该行时不按转换完成使用。此检查只确认标记，模型完整加载由随后训练验证。训练脚本指向模型根目录，不指向 `release/`。三份转换均完成后再提交训练。

**6. Master 容器：短序列正式训练**

```bash
bash /workspace/mopd-adaptation/scripts/run-tele4-topk-customer.sh
```

脚本内部提交 Ray 作业并后台写日志，返回后可关闭终端，不需要外层 `nohup`。配置直接写在脚本里：

| 项目 | 配置 |
|---|---|
| 步数、保存 | **300 rollout；save interval=20** |
| 数据、批量 | GSM8K＋MBPP；batch=8，n-samples-per-prompt=1，global batch=8，micro batch=1 |
| 长度、采样 | 输入 ≤98304、响应 ≤32768、上下文 131072；temperature=0.6、top_p=1.0、top_k=-1 |
| 模板 | `enable_thinking=true` |
| MOPD | math/code 两教师，top-k=1024，alpha=0，loss chunk=512 |
| 训练 | 16 NPU，TP4/CP4/EP8/PP1，Adam lr=1e-6 |
| rollout | 8 NPU，DP8，Graph/FIA，FP32 LM head，最多 8 并发 |

`--rm-type zero` 提供零任务奖励，`--mopd-alpha 0.0` 关闭其对应策略损失；模型仍通过教师 top-k 蒸馏损失更新。因此 reward 为 0 不代表不训练，KL 下降也不等于答案准确率提升。训练从初始 Student 开始，保留 `--finetune --no-load-optim --no-load-rng`。

状态和实时日志：

```bash
ray job status mopd-2026-09-16_short_05
ray job logs -f mopd-2026-09-16_short_05
```

脚本同时将日志写入 `/hpfs/huawei/songchunjiang/mopd-delivery-05/experiments/2026-09-16_short_05/train.log`，已关闭日志进程的 Python 输出缓冲；退出日志查看不停止训练。正常完成应显示 `SUCCEEDED`。失败重跑修改脚本中的实验名，不覆盖原目录。

**7. Master 容器：长序列正式训练**

短训练结束并释放资源后，确认 `ray status` 的节点、卡数及空闲状态，再运行独立长脚本：

```bash
ray status
bash /workspace/mopd-adaptation/scripts/run-tele4-topk-longrun.sh
```

长脚本使用第 3 节的全量合格 JSONL，**300 步、每 20 步保存**。保留默认 chat template、96K 输入限制、32K 输出上限、128K 上下文及原并行/Graph/FIA 配置；每步 8 条是批量，不是题池总数。两项训练各自从初始 Student 开始，长训练不继承短训练产物。

```bash
ray job status mopd-2026-09-16_long_05
ray job logs -f mopd-2026-09-16_long_05
```

日志：`/hpfs/huawei/songchunjiang/mopd-delivery-05/experiments/2026-09-16_long_05/train.log`。两个训练作业不要同时占用同一组资源。

300 步是本次正式运行配置，报告没有宣称已跑满。历史容量批约 43.6 分钟/步；若耗时相近，300 步约 218 小时，仅供排期。检查保存和导出可先使用已完整保存的第 20 步 checkpoint，不必等待第 300 步；独立 SGLang 仍需空闲 NPU。

**8. Master 容器：checkpoint 导出 HF**

checkpoint 根目录分别为：

```text
/hpfs/huawei/songchunjiang/mopd-delivery-05/models/mopd-short/mopd-2026-09-16_short_05
/hpfs/huawei/songchunjiang/mopd-delivery-05/models/mopd-longrun/mopd-2026-09-16_long_05
```

当前保存使用从 0 开始的 rollout ID：

| 已完成步数 | 子目录 |
|---:|---|
| 20 | `iter_0000019` |
| 40 | `iter_0000039` |
| 100 | `iter_0000099` |
| 300 | `iter_0000299` |

原生代码在数据 epoch 边界及最后一轮也会保存，所以长数据每 13 步还可能出现额外 checkpoint。保留实际产物，仅转换已经完整写入的 iteration。

下面按完成 300 步填写。若先检查第 20 步，将输入、输出路径中的 `0000299` 都改为 `0000019`，并同步修改第 9 节服务脚本的 `MODEL`。

短序列导出：

```bash
CHECKPOINT_ITER_DIR=/hpfs/huawei/songchunjiang/mopd-delivery-05/models/mopd-short/mopd-2026-09-16_short_05/iter_0000299
OUTPUT_HF_DIR=/hpfs/huawei/songchunjiang/mopd-delivery-05/models/mopd-export-hf/short_05-iter_0000299
bash /workspace/mopd-adaptation/scripts/export-tele4-checkpoint-to-hf.sh \
  "$CHECKPOINT_ITER_DIR" "$OUTPUT_HF_DIR"
```

长序列导出：

```bash
CHECKPOINT_ITER_DIR=/hpfs/huawei/songchunjiang/mopd-delivery-05/models/mopd-longrun/mopd-2026-09-16_long_05/iter_0000299
OUTPUT_HF_DIR=/hpfs/huawei/songchunjiang/mopd-delivery-05/models/mopd-export-hf/long_05-iter_0000299
bash /workspace/mopd-adaptation/scripts/export-tele4-checkpoint-to-hf.sh \
  "$CHECKPOINT_ITER_DIR" "$OUTPUT_HF_DIR"
```

输出目录必须不存在。脚本调用现有 `convert_torch_dist_to_hf_parallel.py`，使用 `--verify-output` 逐张量读回核对。正常结束显示 `Model converted and saved. All saved tensors verified.` 和 `HF 导出完成`。HF 配置、tokenizer 和模型代码来自初始 Student，权重来自指定训练 checkpoint，不用初始参数补齐。

输出分片数量可以改变：原 HF 40 片、已测导出 12 片，来自 5 GiB 的分片设置，加载依据 `model.safetensors.index.json`。保存读回不能替代下一步服务推理。[HF 分片说明](https://huggingface.co/docs/transformers/main/en/big_models#sharded-checkpoints)

增减训练/推理机器数本身不要求分片数随之改变；`load/save-max-workers` 是导出进程并发，不是训练节点数。初始转换仍可用单机 16 NPU。若改变 TP/PP/EP、模型结构或 checkpoint 格式，需要验证新的组合；当前报告不覆盖 8 台训练＋4 台推理。

**9. 空闲容器：部署短序列导出 HF**

使用相同镜像及补丁准备好的容器内 8 张空闲 NPU，也可在训练和其 rollout 服务退出、资源释放后使用原 Worker。进入 Worker 的执行机命令：

```bash
sudo kubectl exec -it schj-mopd-acceptance-05-worker-0 -n lql -- bash
```

`/workspace/mopd-adaptation/scripts/serve-sglang.sh` 顶部默认配置如下；模型路径应与第 8 节实际导出目录一致，卡号填写实际空闲的 8 张卡：

```bash
MODEL=/hpfs/huawei/songchunjiang/mopd-delivery-05/models/mopd-export-hf/short_05-iter_0000299
EXPERIMENT_NAME=2026-09-16_sglang_short_05
VISIBLE_NPUS=0,1,2,3,4,5,6,7
```

这三行是**脚本内配置**，需要修改时编辑该脚本；不是在外层终端设置覆盖变量。启动：

```bash
bash /workspace/mopd-adaptation/scripts/serve-sglang.sh
```

脚本内部后台运行并输出服务 PID 和日志路径，关闭终端不停止服务。等待加载后查询，应返回 HTTP 200：

```bash
BASE_URL=http://127.0.0.1:30000
curl --fail --silent --show-error --noproxy '*' "$BASE_URL/health"
```

刚启动尚未加载完成时稍后再查询，然后执行真实请求。

**10. 服务容器：三道固定题流式推理**

三份请求均为原生 `/generate` 的 `stream:true`，使用已渲染的 Telechat thinking 输入，temperature=0.6、输出上限 32768。不再次应用模板。题目是 GSM8K train 第 1 题、MBPP-904 和原截断题 MBPP-689。[SGLang 原生接口](https://docs.sglang.io/docs/basic_usage/native_api)

```bash
BASE_URL=http://127.0.0.1:30000
REQUESTS=/workspace/mopd-adaptation/requests
VIEW=/hpfs/huawei/songchunjiang/mopd-delivery-05/experiments/2026-09-16_hf_short_05
mkdir "$VIEW"
curl --fail --silent --show-error --noproxy '*' "$BASE_URL/server_info" > "$VIEW/server-info.json"
set -o pipefail
```

`server_info` 供现有查看器选择累计流/增量流的显示方式。以下三个请求依次执行，内容直接打屏：

```bash
curl --fail --no-buffer --silent --show-error --noproxy '*' \
  --header 'Content-Type: application/json' \
  --data-binary @"$REQUESTS/gsm8k-train-1-stream.json" "$BASE_URL/generate" |
  python3 -B -u /workspace/mopd-adaptation/tools/stream_text.py \
    --server-info "$VIEW/server-info.json" --out "$VIEW/gsm8k-train-1"

curl --fail --no-buffer --silent --show-error --noproxy '*' \
  --header 'Content-Type: application/json' \
  --data-binary @"$REQUESTS/mbpp-904-stream.json" "$BASE_URL/generate" |
  python3 -B -u /workspace/mopd-adaptation/tools/stream_text.py \
    --server-info "$VIEW/server-info.json" --out "$VIEW/mbpp-904"

curl --fail --no-buffer --silent --show-error --noproxy '*' \
  --header 'Content-Type: application/json' \
  --data-binary @"$REQUESTS/mbpp-689-stream.json" "$BASE_URL/generate" |
  python3 -B -u /workspace/mopd-adaptation/tools/stream_text.py \
    --server-info "$VIEW/server-info.json" --out "$VIEW/mbpp-689"
```

结束时查看器打印停止原因、token 数和流式状态，并保存回答。GSM8K 最终答案为 **72**；两道代码题按输入中的三条 assert 检查，参考见 `requests/CASES.json`。需要执行代码测试时，将最终 Python 解及该题三条 assert 放进同一个文件，再用容器内 `python3` 执行；训练的零奖励配置不会替我们测试答案。

正常停止、回答完整和答案正确分别判断；只看到思考开头不能算回答完成。若仍重复或 length 截断，保留实际结果：初始模型已有相同现象，不能仅凭它认定导出损坏。三题检查也不代表整体准确率或截断率。

**11. 同一服务容器：改用长序列导出 HF 再测**

结束短模型的测试后，停止该服务：

```bash
kill "$(cat /hpfs/huawei/songchunjiang/mopd-delivery-05/experiments/2026-09-16_sglang_short_05/server.pid)"
```

待服务退出、对应卡释放后，编辑同一 `serve-sglang.sh` 的两行：

```bash
MODEL=/hpfs/huawei/songchunjiang/mopd-delivery-05/models/mopd-export-hf/long_05-iter_0000299
EXPERIMENT_NAME=2026-09-16_sglang_long_05
```

仍执行 `bash /workspace/mopd-adaptation/scripts/serve-sglang.sh`，健康接口就绪后设置新的结果目录：

```bash
BASE_URL=http://127.0.0.1:30000
REQUESTS=/workspace/mopd-adaptation/requests
VIEW=/hpfs/huawei/songchunjiang/mopd-delivery-05/experiments/2026-09-16_hf_long_05
mkdir "$VIEW"
curl --fail --silent --show-error --noproxy '*' "$BASE_URL/server_info" > "$VIEW/server-info.json"
set -o pipefail
```

用这个 `VIEW` 重复第 10 节的三个流式请求。短、长结果分别保留；重复请求时使用新结果目录。

**12. 用 TrainingLogParser 展示曲线**

使用脚本已经写出的两份日志：

```text
/hpfs/huawei/songchunjiang/mopd-delivery-05/experiments/2026-09-16_short_05/train.log
/hpfs/huawei/songchunjiang/mopd-delivery-05/experiments/2026-09-16_long_05/train.log
```

在 [TrainingLogParser](https://curryrice233.github.io/TrainingLogParser/) 上传日志，Key 设置保留原 9 项并补充响应长度及训练耗时：

![画图设置](figures/pic_show_config.png)

```json
["'train/loss':","'train/grad_norm':","'train/train_rollout_logprob_abs_diff':","'rollout/truncated_ratio':","'perf/step_time':","'perf/rollout_time':","'train/mopd_topk_kl':","'train/mopd_topk_kl/math':","'train/mopd_topk_kl/code':","'rollout/response_len/mean':","'rollout/response_len/max':","'perf/train_time':","'perf/longest_sample_tokens_per_sec':"]
```

`Comparison step=1`、Regex 关闭、移除零值和负值关闭。先分别显示完整记录，再按双方都有的步数区间对比；确实完成 300 步后可用 `0:300`。横轴是匹配值序号，缺项时不一定等于原始 rollout ID。[解析实现](https://github.com/CurryRice233/TrainingLogParser/blob/main/js/log-parser/parser-data.js)

截断率 0.05 表示 5%，耗时单位秒。总体截断率按截断响应数/全部响应数统计，KL 展示完整曲线及相同窗口均值；领域 KL 是总损失贡献。最长样本吞吐是最大响应长度/rollout 总耗时，不是纯 decode 速度。报告保留原有实测结果，本次重验结果待实际执行后补充。
